 
 /*******************************************************************************************/
 /* Pr�requis pour utiliser cet utilitaire :												*/
 /* La varibale MODE_EXPRESSION_PRESTATION_DEFAUT et isExterne � d�finir dans la jsp 		*/
 /* Associer les class prestation, valeur et modeExpression aux elements HTML correspondant */
 /*******************************************************************************************/ 
  
/*
 * NOTE : ces m�thodes ne servent pas � valoriser le HTML : la liste des prestations est �crite dans la JSP via les taglib front
 * LE but de ces m�thodes est de g�rer les mises � jour de champ hidden lorsque l'utilisateur choisit une valeur dans un select
 * 
 */

/**
 *
 *	maj 2012/05, jQuery version.
 *
 **/
var initControlsPrestations = function(){
  // on recupere les liste des select.prestation & on bind ce qu'il faut...
  jQuery('select.prestation').each(function(){
	jQuery(this).change(function(){
	  majFieldsPrestation(this);
	});
	jQuery(this).parent().find('.valeur').blur(function(){
	  validerValeurPrestation(this);
	})
	jQuery(this).parent().find('.modeExpression').change(function(){
	  validerValeurPrestation(this);
	});
	disableFieldsPrestation(this);
  });
  
};
  
  function disableFieldsPrestation(selectPrestation){
  
    
	var valeur = jQuery(selectPrestation).closest('.line').find('.valeur')[0];
  	
	var modeExpression = jQuery(selectPrestation).closest('.line').find('.modeExpression')[0];
	var mejq = jQuery(selectPrestation).closest('.line').find('.modeExpression');
  	
  
    if(selectPrestation.value != ''){

  	 	var prestation = listPrestations[selectPrestation.value];
  
	  	if(prestation.valeurDefaut!=BEAN_PRESENTATION_NULL 
		&& prestation.valeurDefaut==prestation.valeurMin 
		&& prestation.valeurDefaut==prestation.valeurMax
		&& isExterne){
				valeur.disable();
		}
	  
	  	 if(prestation.modeExpression!=BEAN_PRESENTATION_NULL && isExterne){
			modeExpression.disable();
			mejq.parent().find('.xh-select').addClass('one');
		 }
	 		
  	}
  
  }

/* ancienne version sous prototype */
  
  function majFieldsPrestation(selectPrestation){

    var divParent = jQuery(selectPrestation).parent().parent();
    var valeur = divParent.find('.valeur')[0];
    var valeurHidden = divParent.find('.valeurHidden')[0];
  	var modeExpression = divParent.find('.modeExpression')[0];
    var modeExpressionHidden = divParent.find('.modeExpressionHidden')[0];
	var libelleModeExpression = jQuery(modeExpression).find('option[value='+modeExpression.value+']').html();
        
    
 	jQuery(valeur).removeAttr('disabled');
 	jQuery(modeExpression).removeAttr('disabled');
	jQuery(modeExpression).parent().find('.xh-select').removeClass('one');
 	
  	if(selectPrestation.value != ''){

  	 	var prestation = listPrestations[selectPrestation.value];

		if(prestation.valeurDefaut!=BEAN_PRESENTATION_NULL){
			valeur.value = prestation.valeurDefaut;	
		} else {
			valeur.value ='';
		}

		if(prestation.modeExpression!=BEAN_PRESENTATION_NULL){  
	 		modeExpression.value=prestation.modeExpression;
	 	} else {
	 		modeExpression.value=MODE_EXPRESSION_PRESTATION_DEFAUT;
	 	}
		//On r�cup�re l'�l�ment de la surcouche qui correspond et on d�clenche l'�v�nement click
		jQuery("#xh-ul-"+jQuery(modeExpression).attr('id')).find('a[value='+modeExpression.value+']').click();
	 
	 
	   	if(typeof ageMaterielPrincipal!='undefined' && parseInt(prestation.ageMaxMateriel)<ageMaterielPrincipal){
			var messageAlert = "Prestation "+prestation.libelle.replace("&#146;","'")+" non applicable pour ce mat�riel d'occasion.";
			if(!isExterne && !confirm(messageAlert+"\nMerci de confirmer la d�rogation.")){
					valeur.value ='';
					modeExpression.value=MODE_EXPRESSION_PRESTATION_DEFAUT;
					selectPrestation.value = '';
			}
		}	 
	 
 	} else {
 		valeur.value='';
 		modeExpression.value=MODE_EXPRESSION_PRESTATION_DEFAUT;
 	}

	valeurHidden.value=valeur.value;
	modeExpressionHidden.value=modeExpression.value;

	disableFieldsPrestation(selectPrestation);


  }
  
	function validerValeurPrestation(elem){
	
//	   	event.stop();
// 		var elem = Event.element(event);
		var divParent = jQuery(elem).parent();
 		var valeur = divParent.find('.valeur')[0];
 		var selectPrestation = divParent.find('.prestation')[0];
 		var selectModeExpression = divParent.find('.modeExpression')[0];
 		var valeurHidden = divParent.find('.valeurHidden')[0];
 		var modeExpressionHidden = divParent.find('.modeExpressionHidden')[0];

 		valeurHidden.value=valeur.value;
 		modeExpressionHidden.value=selectModeExpression.value;
 	
	 	if(selectPrestation.value != '' && valeur.value.trim() != '' && !isNaN(valeur.value))
	 	{
  	 		var prestation = listPrestations[selectPrestation.value];	
 	
  	 		if(prestation.modeExpression!=BEAN_PRESENTATION_NULL && prestation.modeExpression==selectModeExpression.value)
  	 		{
  	 			if((prestation.valeurMin!=BEAN_PRESENTATION_NULL && valeur.value<parseFloat(prestation.valeurMin)) || (prestation.valeurMax !=BEAN_PRESENTATION_NULL && valeur.value>parseFloat(prestation.valeurMax)))
  	 			{
	  	 			var messageAlert = "La valeur de la prestation "+prestation.libelle.replace("&#146;","'")+" n'est pas comprise dans l'intervalle param�tr� de "+prestation.valeurMin+" � "+prestation.valeurMax+".";
	  	 			
	  	 			if(isExterne)
	  	 			{
	  	 				alert(messageAlert);
	  	 				valeur.value=prestation.valeurDefaut;
	  	 				valeur.activate();
	  	 			}
	 	 			else 
	 	 			{
	  	 				if(!confirm(messageAlert+"\nMerci de confirmer la d�rogation."))
	  	 				{
	  	 					valeur.value=prestation.valeurDefaut;
	  	 					valeur.activate();
	  	 				}
	  	 			}
  	 			}
  	 		}
  	 		
  	 		
  	 	}
	}