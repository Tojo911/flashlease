(function($){
    $(document).ready(function() {
    	$('input[name=pjForm\\.numeroDossier]').eq(0).val($('#input_numeroDossier').val());
    	$("input[name=pjForm\\.fileName]").eq(0).val("");
    	$("input[name=pjForm\\.fileType]").eq(0).val("");
    	$("input[name=pjForm\\.fileAction]").eq(0).val("");
    	
    	//ajout du fichier
    	$(".btnUploadFile").click(function() {
    		
    		if ($("input[name=pjForm\\.fileUpload]").length > 0) {
    			$("input[name=pjForm\\.fileUpload]").remove();
    		}
    		
    		var fileTag = $('<input>').attr({
    		    type: 'file',
    		    name: 'pjForm.fileUpload',
    		    accept : ".pdf, .png, .jpg, .jpeg, .docx, .doc, .xlsx, .xls"
    		}).css({"display":"none"});
    		
    		$("input[name=pjForm\\.fileName]").eq(0).before($(fileTag));
    		
    		$(fileTag).on('change',function(){
        		$('<div class="overlayed-cover"><img src="../img/overlay-loader.gif" /></div>').appendTo('body');
        		$(this).closest("form").attr("enctype", "multipart/form-data");
        		$(this).closest("form").submit();
            });
    		
    		
    		$("input[name=pjForm\\.fileName]").eq(0).val($(this).attr("fileName"));
    		$("input[name=pjForm\\.fileType]").eq(0).val($(this).attr("fileType"));
    		$("input[name=pjForm\\.fileAction]").eq(0).val($(this).attr("fileAction"));
    		$(fileTag).click();
    		
    	});
    	
    	
    	//suppression du fichier
    	$('.btnDeleteFile').on('click',function(){
    		$('<div class="overlayed-cover"><img src="../img/overlay-loader.gif" /></div>').appendTo('body');
    		$("input[name=pjForm\\.fileName]").eq(0).val($(this).attr("fileName"));
    		$("input[name=pjForm\\.fileType]").eq(0).val($(this).attr("fileType"));
    		$("input[name=pjForm\\.fileAction]").eq(0).val($(this).attr("fileAction"));
    		$(this).closest("form").submit();
        });
    	
    	//t�l�chargement du fichier
    	$(".btnDownloadFile").on('click',function(){
    		$("input[name=pjForm\\.fileName]").eq(0).val($(this).attr("fileName"));
    		$("input[name=pjForm\\.fileType]").eq(0).val($(this).attr("fileType"));
    		$("input[name=pjForm\\.fileAction]").eq(0).val($(this).attr("fileAction"));
    		$(this).closest("form").submit();
    		$("input[name=pjForm\\.fileName]").eq(0).val("");
	    	$("input[name=pjForm\\.fileType]").eq(0).val("");
	    	$("input[name=pjForm\\.fileAction]").eq(0).val("");
        });
    	
    });
})(jQuery);