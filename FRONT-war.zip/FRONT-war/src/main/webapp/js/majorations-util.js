 
 /*******************************************************************************************/
 /* Pr�requis pour utiliser cet utilitaire :												*/
 /* La varibale MODE_EXPRESSION_MAJORATION_DEFAUT � d�finir dans la jsp 					*/
 /* Associer les class majoration, valeur et modeExpression aux elements HTML correspondant */
 /*******************************************************************************************/ 
 
 /**
 *
 *	maj 2012/06, jQuery version.
 *
 **/
var initControlsMajorations = function(){
  // on recupere les liste des select.majoration & on bind ce qu'il faut...
  jQuery('select.majoration').each(function(){
	jQuery(this).change(function(){
	  majMajoration(this);
	});
	jQuery(this).parent().find('.valeur').blur(function(){
	  validerValeurMajoration(this);
	})
	jQuery(this).parent().find('.modeExpression').change(function(){
	  validerValeurMajoration(this);
	});
  });
};
 
 
  
  function disableFieldsMajoration(selectMajoration){
  
   
  	var valeur = jQuery(selectMajoration).closest('.line').find('.valeur')[0];
  	
  	var modeExpression = jQuery(selectMajoration).closest('.line').find('.modeExpression')[0];
	var mejq = jQuery(selectMajoration).closest('.line').find('.modeExpression');
  
    if(selectMajoration.value != ''){

  	 	var majoration = listMajorations[selectMajoration.value];
  
  
  		if(majoration){
  		
		  	if(majoration.valeurDefaut!=BEAN_PRESENTATION_NULL 
			&& majoration.valeurDefaut==majoration.valeurMin 
			&& majoration.valeurDefaut==majoration.valeurMax
			&& isExterne){
					valeur.disable();
			}
		  
		  	 if(majoration.modeExpression!=BEAN_PRESENTATION_NULL && isExterne){
				modeExpression.disable();
				mejq.parent().find('.xh-select').addClass('one');
			 }
		 
		 }
  	}
  
  }
  
  

  function majFieldsMajoration(selectMajoration){
    
	var divParent = jQuery(selectMajoration).parent().parent();
    var valeur = divParent.find('.valeur')[0];
    var valeurHidden = divParent.find('.valeurHidden')[0];
  	var modeExpression = divParent.find('.modeExpression')[0];
    var modeExpressionHidden = divParent.find('.modeExpressionHidden')[0];
  	
 	jQuery(valeur).removeAttr('disabled');
 	jQuery(modeExpression).removeAttr('disabled');
 	jQuery(modeExpression).parent().find('.xh-select').removeClass('one');
 	
  	if(selectMajoration.value != ''){

  	 	var majoration = listMajorations[selectMajoration.value];
		
		if(majoration){
		
			if(majoration.valeurDefaut!=BEAN_PRESENTATION_NULL){
				valeur.value = majoration.valeurDefaut;	
			} else {
				valeur.value ='';
			}
	
			if(majoration.modeExpression!=BEAN_PRESENTATION_NULL){  
		 		modeExpression.value=majoration.modeExpression;
		 	} else {
		 		modeExpression.value=MODE_EXPRESSION_MAJORATION_DEFAUT;
		 	}
	 	
	 	}
	 
 	} else {
 		valeur.value='';
 		modeExpression.value=MODE_EXPRESSION_MAJORATION_DEFAUT;
 	}
 	
 	valeurHidden.value=valeur.value;
	modeExpressionHidden.value=modeExpression.value;

	disableFieldsMajoration(selectMajoration);

  }
  
  function majMajoration(selectMajoration) {
//   	event.stop();
// 	var selectMajoration = Event.findElement(event, 'select');
	majFieldsMajoration(selectMajoration);
  }
  
	function validerValeurMajoration(valeur){
	
	   	// event.stop();
 		// var valeur = Event.element(event);
		var divParent = jQuery(valeur).parent();
 		//var selectMajoration = valeur.up().getElementsByClassName('majoration')[0];
 		//var selectModeExpression = valeur.up().getElementsByClassName('modeExpression')[0];
 		var selectMajoration = divParent.find('.majoration')[0];
 		var selectModeExpression = divParent.find('.modeExpression')[0];
 		
 		if(selectMajoration.value != '' && valeur.value.trim()!='' && !isNaN(valeur.value)){
  	 		var majoration = listMajorations[selectMajoration.value];	
  	 		if(majoration.modeExpression!=BEAN_PRESENTATION_NULL && majoration.modeExpression==selectModeExpression.value){
  	 		
  	 			if((majoration.valeurMin!=BEAN_PRESENTATION_NULL && valeur.value<parseFloat(majoration.valeurMin)) ||(majoration.valeurMax!=BEAN_PRESENTATION_NULL &&  valeur.value>parseFloat(majoration.valeurMax))){
	  	 			var messageAlert = "La valeur de la majoration "+majoration.libelle.replace("&#146;","'")+" n'est pas comprise dans l'intervalle param�tr� de "+majoration.valeurMin+" � "+majoration.valeurMax+".";
	  	 			
	  	 			if(isExterne){
	  	 				alert(messageAlert);
	  	 				valeur.value=majoration.valeurDefaut;
	  	 				valeur.activate();
	  	 			} else {
	  	 				if(!confirm(messageAlert+"\nMerci de confirmer la d�rogation.")){
	  	 					valeur.value=majoration.valeurDefaut;
	  	 					valeur.activate();
	  	 				}
	  	 			}
  	 			}
  	 		} 
  	 	}
	}