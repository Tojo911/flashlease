//chercher la raison sociale
function chercherSociete(formName, sirenName, flagName) {
	var form = document.getElementsByName(formName);
	var input_siren = document.getElementsByName(sirenName);
	var input_flag = document.getElementsByName(flagName);
	
	if (form != undefined && form.length > 0 && input_siren != undefined && input_siren.length > 0 && input_flag != undefined && input_flag.length > 0) {
		if (input_siren[0].value) {
			input_flag[0].value = true;
			form[0].submit();
		} else {
			input_flag[0].value = false;
		}
	}
}
