/**
 * Shared js between simulation and ratification operations.
 * 
 */
var montantGlobal = 0;
var dateEcheance = "";
// On suppose que la date entr�e a �t� valid�e auparavant au format dd/mm/yyyy
function getDate(strDate) {
	day = strDate.substring(0, 2);
	month = strDate.substring(3, 5);
	year = strDate.substring(6, 10);
	d = new Date();
	d.setDate(day);
	d.setMonth(month - 1);
	d.setFullYear(year);
	return d;
}

// Retourne:
// 0 si date_1 = date_2
// 1 si date_1 > date_2
// -1 si date_1 < date_2
function compare(date_1, date_2) {
	diff = date_1.getTime() - date_2.getTime();
	return (diff == 0 ? diff : diff / Math.abs(diff));
}

function gestionMontantGlobal(ele, formName) {
	id = ele.value;
	selection = Math.floor(parseFloat(document.getElementById("montantGlobal_"
			+ id).innerHTML) * 100 + 0.5) / 100;
	if (ele.checked) {
		if(!isExpiredValidityOffreRachatSelection(ele))	{	
		   montantGlobal = Math.floor((montantGlobal + selection) * 100 + 0.5) / 100;
		}
	} else {
		montantGlobal = Math.floor((montantGlobal - selection) * 100 + 0.5) / 100;
	}

	if (montantGlobal != 0) {
		document.getElementById("montantGlobalLabel").innerHTML = "&nbsp;"
				+ montantGlobal + "&nbsp;&euro;";
		document.forms[formName].montantTopUp.value = montantGlobal;
	} else {
		document.getElementById("montantGlobalLabel").innerHTML = "";
		document.forms[formName].montantTopUp.value = "";
	}
}

function gestionDateEcheance(ele, formName) {
	id = ele.value;
	selection = document.getElementById("dateEcheance_" + id).innerHTML;
	
	// On coche un element
	if (ele.checked) {
		if (dateEcheance == "") {
			dateEcheance = selection;
		} else {
			date_1 = getDate(selection);
			date_2 = getDate(dateEcheance);

			if (compare(date_1, date_2) < 0) {
				dateEcheance = selection;
			}
		}

		// On decoche un element
	} else {
		// On d�termine le nombre d'elements selectionnes
		nbreEleCoches = 0;
		for (i = 0; i < document.forms[formName].rachatIds.length; i++) {
			if (document.forms[formName].rachatIds[i].checked) {
				nbreEleCoches++;
			}
		}

		if (nbreEleCoches == 0) {
			dateEcheance = "";
		} else {
			isFirstElement = true;
			for (i = 0; i < document.forms[formName].rachatIds.length; i++) {
				if (document.forms[formName].rachatIds[i].checked) {
					id = document.forms[formName].rachatIds[i].value;

					// On selectionne la date du premier element de la liste des
					// elements coch�s
					if (isFirstElement) {
						dateEcheance = document.getElementById("dateEcheance_"
								+ id).innerHTML;
						isFirstElement = false;
					} else {
						date_1 = getDate(dateEcheance);
						date_2 = getDate(document
								.getElementById("dateEcheance_" + id).innerHTML);

						if (compare(date_1, date_2) > 0) {
							dateEcheance = document
									.getElementById("dateEcheance_" + id).innerHTML;
						}
					}
				}
			}
		}
	}
	document.forms[formName].dateMontantTopUp.value = dateEcheance;
	document.getElementById("dateEcheanceLabel").innerHTML = dateEcheance;
}

/**
 * Init global fields.
 * @param formName the form content to input
 */
function initInputText(formName) {
	if (document.forms[formName].montantTopUp.value != "") {
		document.getElementById("montantGlobalLabel").innerHTML = document.forms[formName].montantTopUp.value
				+ "&nbsp;&euro;";
		montantGlobal = parseFloat(document.forms[formName].montantTopUp.value);

	}
	if (document.forms[formName].dateMontantTopUp.value != "") {
		document.getElementById("dateEcheanceLabel").innerHTML = document.forms[formName].dateMontantTopUp.value;
		dateEcheance = document.forms[formName].dateMontantTopUp.value;
	}
}
// --------------------------------------------------------------------------------------//
/**
 * Make uncheckable expired validity offre rachat. Indeed, we could still dissociate them.
 */
function isExpiredValidityOffreRachatSelection(ele) {
	id = ele.value;
	// selection = document.getElementById("dateEcheance_" + id).innerHTML;
	
	// avoid conflict with prototype.js
	var $jq = jQuery.noConflict();
	selectedOffreValidityDateElt = document.getElementById("OffreDateValidte_"
			+ id);
	// Manage creation case where there is no defined OffreDateValidte ..
	// element
	if (selectedOffreValidityDateElt != null) {
		selectedOffreValidityDate = selectedOffreValidityDateElt.innerHTML;
		// Manage case with wrapped offer validity date older than today
		if (compare(new Date(), getDate(selectedOffreValidityDate)) > 0) {
			// offre validity date older than today
			// set checking property to false
			$jq(ele).prop('checked', false);
			// get the wrapper tag <td>
			// find the tag <a href="#"> which corresponds to the last element
			// and remove checked img from its class definition
			var wrapperParent = $jq(ele).parent().closest("td");
			try {
				// work for IE
				var wrapperTagHref = $jq(wrapperParent[0].children.tags("a"));
				$jq(wrapperTagHref).prop("class", "xh xh-checkbox");

			} catch (e) {
				// others browsers including CHROME
				$jq(wrapperParent[0].lastElementChild).prop("class",
						"xh xh-checkbox");
			}

			// finally alert the user
			// TODO REVIEW
			alert("Cette offre de rachat a expir� le "+selectedOffreValidityDate);
			return true;
		}
	}
	return false;

}