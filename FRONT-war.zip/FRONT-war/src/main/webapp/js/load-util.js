function _Entry(_fn, _args) {
       this.key = _fn;
       this.value = _args;
}

var LoadBodyExecuter = {
  
  _functions : new Array(),  
  
  addFunction : function()   {
        var args = this.toArray(arguments);
        var entree = new _Entry(args.shift(), args);
        this._functions.push(entree);
  },
  
  execute : function() {
    var taille = this._functions.length;
    for (var index = 0; index < this._functions.length; index++) {
      var entree = this._functions[index];         
      entree.key.apply(entree.key,entree.value);
    }
  },
  
  toArray : function(iterable) {
      var results = [];
      for (var i = 0, length = iterable.length; i < length; i++)
        results.push(iterable[i]);
      return results;
  }  
  
}

function onLoadBody(){
	LoadBodyExecuter.execute();
}

addListener(window,"load",onLoadBody);
