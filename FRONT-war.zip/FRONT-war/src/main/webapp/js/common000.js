/***********************************************************
*                                                          *   
*       Commun � toutes les fonctionnalit�s                *
*                                                          *
************************************************************/

/***********************************************************/
/**     		Variables globales                        **/
/***********************************************************/

var CODE_KEY_ENTREE = 13;
var CODE_KEY_BACKSPACE = 8


var BEAN_PRESENTATION_NULL = "--";


/***************************************************************************/
/**      Calsse � �tendre : permet detecter le type de nvigateur utilis�  **/
/***************************************************************************/
function NavDectecteur() {

  this.name = navigator.appName;
  this.codeName = navigator.appCodeName;
  this.version = navigator.appVersion;
  this.platform = navigator.platform;
  this.javaEnabled = navigator.javaEnabled();
  this.screenWidth = screen.width;
  this.screenHeight = screen.height;

  sUserAgent = navigator.userAgent;
  this.isMoz = sUserAgent.indexOf("Gecko") > -1;
  this.isIE = sUserAgent.indexOf("compatible") > -1 && sUserAgent.indexOf("MSIE") > -1;  
  this.numeroVersion = function() {
		  					var numeroVersion = null;
		 					if(this.isIE){
		  						var identifiantIE = "MSIE";
		  						var indexDeb = this.version.indexOf(identifiantIE)+identifiantIE.length+1;
		  						numeroVersion = this.version.substring(indexDeb,indexDeb+1);
		  					} else if (this.isMoz){
		  						var indexDeb = 0;
		  						numeroVersion = this.version.substring(indexDeb,indexDeb+1);
		  					}
		  
		  					return numeroVersion;
 						};
}

var navDectecteur = new NavDectecteur();


function positionnerAncrePage(sAncreToUse) {
   location.hash = "#"+sAncreToUse;
}

function initGarantie(selectEelement) {
  
   var index = selectEelement.selectedIndex;
  
   if(index != 0) {   
     var valeur = selectEelement.options[index].text;
     var code = selectEelement.options[index].value;
     var tableGaranties =  document.getElementById("tableGaranties");
     var listChampsGaranties = tableGaranties.getElementsByTagName("textarea");
     for(var i= 0; i<listChampsGaranties.length; i++){
       var elem = listChampsGaranties[i];
       var valeurElem = elem.value;
       var inputSuivant = jQuery(elem).nextAll('input:hidden')[0];
      
       if(valeurElem == "") {    
         
         /*** alert(inputSuivant.nodeName.toLowerCase()); **/
         elem.value = valeur;
         inputSuivant.value = code;
         break;
       }    
     }
   }   
}


function affecterGarantie(nomCodeGarantie,nomLibelleGarantie){
  var codeGarantie = document.ratificationAvanceeForm.elements[nomCodeGarantie];
  var libelleGarantie = document.ratificationAvanceeForm.elements[nomLibelleGarantie];

  var selectElement =  document.getElementById("codegarantie");
  var index = selectElement.selectedIndex;
  if(index == 0) {
     codeGarantie = "";
     libelleGarantie = "";
  }
  else {
     var selectElementOption = selectElement.options[index];
     codeGarantie.value = selectElement.options[index].value;
     libelleGarantie.value = selectElement.options[index].text;
  }
}

function affecterGarantieSimu(nomCodeGarantie,nomLibelleGarantie){
	  var codeGarantie = document.simulationFormEtapeSimu.elements[nomCodeGarantie];
	  var libelleGarantie = document.simulationFormEtapeSimu.elements[nomLibelleGarantie];
	  var selectElement =  document.getElementById("codegarantie");
	  var index = selectElement.selectedIndex;
	  if(index == 0) {
	     codeGarantie = "";
	     libelleGarantie = "";
	  }
	  else {
	     var selectElementOption = selectElement.options[index];
	     codeGarantie.value = selectElement.options[index].value;
	     libelleGarantie.value = selectElement.options[index].text;
	  }
	}

function openPopup(url, width, height)
{
  var win = window.open(url, "", "scrollbars=yes,status=no,toolbar=no,directories=no,menubar=no,location=no,resizable=yes,width="+width+",height="+height);
  win.location.reload();
  win.focus();
}

function openPrintPopup(url)
{
  var win = window.open(url, "", "scrollbars=yes,status=no,toolbar=no,directories=no,menubar=no,location=no,resizable=false,width=800,height=600");
  win.location.reload();
  win.focus();
}

function redirect(url)
{
  window.location.href=url;
  return false;
}

function onLoadBody(){
}

function submitForm()
{
	document.forms[0].submit();
}

function raffraichitPage(elem,url){

	elem.form.action=url; 
    elem.form.submit();
    afficherLoder(elem);
}

function limiterSaisie(input, max) {
    var evenement = (window.event || arguments[0]);
	var txt = input.value;
	var nb=txt.length;
	if (nb>=max) {
		alert("Cette zone est limit� � "+max+" caract�res.");
		input.value=txt.substring(0,max);
		evenement.returnValue = false;
	} else {
		evenement.returnValue = true;
	}

}



 
function afficherLoder(elem) {
	var loader = jQuery('#loader');

	if(loader.length) {
	    loderDiv = document.getElementById("loader");     
	    elem.parentNode.replaceChild(loderDiv, elem);    
	    loderDiv.insertBefore(elem, loderDiv.firstChild);
	    loderDiv.style.display = "block";
	}
}

function trim(chaine) 
{ 
  var retour = null;
  if(chaine != null){
 	retour = chaine.replace(/(^\s*)|(\s*$)/g,'');
  }
  
  return retour; 
} 

function mettreAZero(elem) {
  elem.value= "0";
}

function updateFormAction(elem) {  
  elem.form.action = elem.value;  
}


var w=null;
function debug(obj,filter){
    var debug="";
    if (w==null) {
       w=window.open();
    }

    var l=filter.length;
    for (i in obj) {
      if (i.substring(1,l)==filter || l==0 ) {
          debug=debug+'obj['+i+']='+obj[i]+'<br>';
      }
    }
    w.document.write(debug);
    w.document.close();
}

 



function desactiveRadioBouton(element){
     var sizeTaxe = element.length;

      for (var index = 0;index < sizeTaxe;index++){
        var choix = element[index];
        choix.disabled=true;
     }
}

function activeRadioBouton(element){
     var sizeTaxe = element.length;
      for (var index = 0;index < sizeTaxe;index++){
        var choix = element[index];
        choix.disabled=false;
     }
}

function aucunElementSelectionneRadioBouton(element){
   var sizeTaxe = element.length;
   for (var index = 0;index < sizeTaxe;index++){
      var choix = element[index];
      if (choix.checked == true){
         return false;
      }
   }
   return true;
}

function scrollOnElement(idElem){
	
	var elem = document.getElementById(idElem);

	if(elem == null){
	  elem.document.all(idElem);
	}
	
	if(elem != null && !elem.length){
		elem.scrollIntoView();
	}
}

function focusInFirstEmptyElement(myFormIndex) {
  
   var inputs_ = document.forms[myFormIndex].elements;
   var taille = inputs_.length;    
       for(i=0; i<taille; i++) {   
        if(inputs_[i].value == "" && inputs_[i].type != "hidden"){          
           inputs_[i].focus();
           break;
        }          
       }
}

function positionne(p_id, p_posX, p_pos_Y){
  var actions = document.getElementById(p_id);
  var actionsX =  p_posX - actions.offsetWidth;
  var actionsY = p_pos_Y;
  if(isIE()){
	actions.style.left = actionsX;
	actions.style.top = actionsY;
  } else {
	actions.style.left = actionsX +"px";
	actions.style.top = actionsY+"px";		
  }
}


/***********************************************************
*                                                          *   
*       Fonctionnalit� sp�cifique Front                    *
*                                                          *
************************************************************/


function submitFormFrontWithOnglet(numeroForm,nomItem){
   document.forms[numeroForm].nextItemCode.value = nomItem;
   document.forms[numeroForm].submit();
}

/***********************************************************
*                                                          *   
*       Fonctionnalit� Etude                               *
*                                                          *
************************************************************/

//JSP FRT_ETU_SAI002.jsp
function modifieVisibiliteAnneeMiseService(){
    var size = document.materielForm.neuf.length;
    for (var index = 0;index < size;index++){
       var choix = document.materielForm.neuf[index];
       
       if ((choix.checked) && (choix.value == "false")){
         document.materielForm.annee.disabled = false;
      }
      
      if ((choix.checked) && (choix.value == "true")){
        document.materielForm.annee.value = "";
        document.materielForm.annee.disabled = true;
      }
    }
}

//JSP FRT_ETU_SAI001.jsp
function modifieVisibiliteAnneeMiseServiceMateriel(){
    var size = document.donneesGeneraleForm.neuf.length;
    var idDivAnnee = document.getElementById("anneeMiseSer");
    for (var index = 0;index < size;index++){
       var choix = document.donneesGeneraleForm.neuf[index];
       if ((choix.checked) && (choix.value == "false")){
         document.donneesGeneraleForm.annee.disabled = false;
         document.donneesGeneraleForm.annee.style.display = 'block';
         idDivAnnee.style.display = "block";
      }
      
      if ((choix.checked) && (choix.value == "true")){
    	  document.donneesGeneraleForm.annee.style.display = 'none';
    	  idDivAnnee.style.display = "none";
        document.donneesGeneraleForm.annee.disabled = true;
      }
    }
}



//JSP FRT_ETU_SAI003.jsp
function miseAJourTauxVRAPartirMontant(){
   var montant = document.planFinancementForm.montant.value;
   
   var valeurResiduelle = document.planFinancementForm.valeurResiduelle.value;
   var formatValeurResiduelle = /^\d\d?\d?\d?\d?\d?\d?((((\.|\,)\d)?)|(((\.|\,)\d\d)?))$/;
   
   if (!formatValeurResiduelle.test(valeurResiduelle)){
     alert("Valeur incorrecte.");
     document.planFinancementForm.valeurResiduelleTaux.value = 0;
     document.planFinancementForm.valeurResiduelle.value = 0;
     document.planFinancementForm.valeurResiduelle.focus();
     return false;
   }
   
   var calcul = (valeurResiduelle * 100)/montant;
   
   //Arrondi 6 chiffre apres la virgule
   calcul=(Math.round(calcul*1000000))/1000000;  
   
   
   document.planFinancementForm.valeurResiduelleTaux.value = calcul;  
}

function miseAJourMontantVRAPartirTaux(){
   var tauxVR = document.planFinancementForm.valeurResiduelleTaux.value;   
   var montant = document.planFinancementForm.montant.value;
   var formatTauxVR = /^\d\d?((((\.|\,)\d)?)|(((\.|\,)\d{2})?)|(((\.|\,)\d{3})?)|(((\.|\,)\d{4})?)|(((\.|\,)\d{5})?)|(((\.|\,)\d{6})?))$/;  
   
    //Test format tauxPremierLoyer
   if (!formatTauxVR.test(tauxVR)){
     alert("Valeur incorrecte.");
     document.planFinancementForm.valeurResiduelleTaux.value = 0;
     document.planFinancementForm.valeurResiduelle.value = 0;
     document.planFinancementForm.valeurResiduelleTaux.focus();
     return false;
   }
   
   var tauxVR_ = tauxVR.replace(",", ".");
   var montant_ = montant.replace(",", ".");
   var calcul = (montant_ * tauxVR_) / 100;
   
   //Arrondi 2 chiffre apres la virgule
   calcul=(Math.round(calcul*100))/100; 
   document.planFinancementForm.valeurResiduelle.value =calcul;

}

function miseAJourTauxAPartirPremierLoyer(){
   var premierLoyer = document.planFinancementForm.premierLoyer.value;
   
   var montant = document.planFinancementForm.montant.value;
   
   var formatPremierLoyer = /^\d\d?\d?\d?\d?\d?\d?((((\.|\,)\d)?)|(((\.|\,)\d\d)?))$/;
   
   if (!formatPremierLoyer.test(premierLoyer)){
      alert("Valeur incorrecte.");
      document.planFinancementForm.premierLoyerTaux.value = 0;
      document.planFinancementForm.premierLoyer.value = 0;
      document.planFinancementForm.premierLoyer.focus();
      return false;
   }
   
   var calcul = (premierLoyer*100)/montant;
   
   //Arrondi 6 chiffre apres la virgule
   calcul=(Math.round(calcul*1000000))/1000000;
   document.planFinancementForm.premierLoyerTaux.value = calcul; 
}

function miseAJourPremierLoyerAPartirTaux(){

   var tauxPremierLoyer = document.planFinancementForm.premierLoyerTaux.value;
   tauxPremierLoyer = tauxPremierLoyer.replace(",", ".");   
   var montant = document.planFinancementForm.montant.value;   
   var formatTauxPremierLoyer = /^\d\d?((((\.|\,)\d)?)|(((\.|\,)\d{2})?)|(((\.|\,)\d{3})?)|(((\.|\,)\d{4})?)|(((\.|\,)\d{5})?)|(((\.|\,)\d{6})?))$/;
   
   //Test format tauxPremierLoyer
   if (!formatTauxPremierLoyer.test(tauxPremierLoyer)){
     alert("Valeur incorrecte.");
     document.planFinancementForm.premierLoyerTaux.value = 0;
     document.planFinancementForm.premierLoyer.value = 0;
     document.planFinancementForm.premierLoyerTaux.focus();
     return false;
   }
   
   
   var calcul = (tauxPremierLoyer * montant) / 100;
   //Arrondi 2 chiffre apres la virgule
   calcul=(Math.round(calcul*100))/100;
   document.planFinancementForm.premierLoyer.value=calcul;
}

/***********************************************************
*                                                          *   
*       Fonctionnalit� Simulation                          *
*                                                          *
************************************************************/

//JSP FRT_SIM_TRS001.jsp
function modifieVisibiliteAnneeMiseServiceTRS(){
   if((typeof document.transmissionSimulationForm.saisieMateriel != "undefined")
      && document.transmissionSimulationForm.saisieMateriel.value == "true")
   {
    var size = document.transmissionSimulationForm.materielNeuf.length;
    for (var index = 0;index < size;index++){
       var choix = document.transmissionSimulationForm.materielNeuf[index];
       
       if ((choix.checked) && (choix.value == "false")){
         document.transmissionSimulationForm.anneeMateriel.disabled = false;
      }
      
      if ((choix.checked) && (choix.value == "true")){
        document.transmissionSimulationForm.anneeMateriel.value = "";
        document.transmissionSimulationForm.anneeMateriel.disabled = true;
      }
    }
    
    }
}

//JSP FRT_SIM_GER012.jsp
function modifieVisibiliteAnneeMiseServiceExterne(){
	    var size = document.materielSimulationForm.materielNeufExterne.length;
	    for (var index = 0;index < size;index++){
	       var choix = document.materielSimulationForm.materielNeufExterne[index];
	       
	       if ((choix.checked) && (choix.value == "false")){
	         document.materielSimulationForm.anneeMaterielExterne.disabled = false;
	      }
	      
	      if ((choix.checked) && (choix.value == "true")){
	        document.materielSimulationForm.anneeMaterielExterne.value = "";
	        document.materielSimulationForm.anneeMaterielExterne.disabled = true;
	      }
	      
	    }
	    
	    if(!document.materielSimulationForm.materielNeufExterne[0].checked && !document.materielSimulationForm.materielNeufExterne[1].checked){
	    	document.materielSimulationForm.materielNeufExterne[0].checked = true;
	    }
	}

//FRT_SIM_GER002.jsp
function afficheOuCacheBlocPlanFinancierSimulation(listProduit,methodeCalculMontantSaisi){
   

   
	var duree = document.simulationFormEtapeSimu.duree.value;
    var montant = document.simulationFormEtapeSimu.montantSaisi.value;
    var nature = document.simulationFormEtapeSimu.codeProduitFinancier.value;
    var typeLoyerMontant = document.simulationFormEtapeSimu.methodeCalcul.value;
    
    /** Remplace les , par les .  **/
    montant = montant.replace(",",".");
    var dureeEntier = parseInt(duree);
    var montantEntier = parseFloat(montant);
    var typeSimulation = document.simulationFormEtapeSimu.typeSimulation.value;
    /********************************************************************/
    /** Il manque un des parametres pour trouver le produit FlashLease **/ 
    /********************************************************************/
    if (((trim(nature) == "") || (trim(montant) == "") || (trim(duree) == "")) && typeSimulation == "SS"){
      cacheSimuBlocPlanFinancier();
      return this;
    } else if (typeSimulation == "SF"){
    	afficheSimuBlocPlanFinancier();
    }
    /************************************************/
    /** Si Cr�dit bail bail ou Location financiere **/
    /************************************************/
    if ((nature == "LF") || (nature == "CB")){
    /**************************/
    /** Si simulation simple **/
    /**************************/    
    if (typeSimulation == "SS"){ 
     /*******************************/
     /** Si methodeCalcul = Loyer  **/
     /*******************************/
     if (typeLoyerMontant != methodeCalculMontantSaisi){      
       for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++){
         var produit = listProduit[indxlistproduit];
         var affichePlanFinancier = produit[6];
   
         if ((affichePlanFinancier == "true") && (produit[0] == nature)){
               afficheSimuBlocPlanFinancier();
         }  
       }
     }
     /******************************/
     /** Si methodeCalcul=Montant **/
     /******************************/
     else{     
        //Test pour verifier que tous les champs sont renseignes
       if ((nature == "") || isNaN(dureeEntier) || (isNaN(montantEntier))){
           return this;
       }
       
       for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++){
       var produit = listProduit[indxlistproduit];
       //On teste si le code nature correspond au code nature recherche
       if (produit[0] == nature){
          var dureeMin = parseInt(produit[1]);
          var dureeMax = parseInt(produit[2]);
          //Test sur la duree
          if ((dureeMin < dureeEntier) && (dureeEntier <= dureeMax)){
             //Test sur le montant
              var montantMin = parseFloat(produit[3]);
              var montantMax = parseFloat(produit[4]);
            
              if ((montantMin < montantEntier) && (montantEntier <= montantMax)){
                  var affichePlanFinancier = produit[6];                 
                  if (affichePlanFinancier == "true"){
                  /** Si le produit correspond, on affiche le bloc financier et on sort de la fonction **/
                    afficheSimuBlocPlanFinancier();
                    return this;
                  }
              }
          }
         }      
        }
        cacheSimuBlocPlanFinancier();
       }
      }
      /******************************/
      /** Si simulation non simple **/
      /******************************/
      else
      {
        afficheSimuBlocPlanFinancier();
      }
     }
     /********************************************/
     /** Si nature est differente de e CB et LF **/
     /********************************************/
     else
     {
    	if(typeSimulation == "SS"){
    		cacheSimuBlocPlanFinancier();
    	} else {
    		afficheSimuBlocPlanFinancier();
    	}
        
     }
}

function afficheSimuBlocPlanFinancier(){
    document.simulationFormEtapeSimu.vr.disabled= false;
    if(document.simulationFormEtapeSimu.premierLoyerMajore){
    	document.simulationFormEtapeSimu.premierLoyerMajore.disabled=false;
    }
    document.getElementById("complementPlanFinancier").style.display='block';
    document.simulationFormEtapeSimu.affichePlanFinancement.value = "true";
    if (trim(document.simulationFormEtapeSimu.vr.value) == ""){
       mettreAZero(document.simulationFormEtapeSimu.vr);
    }
    
    if (document.simulationFormEtapeSimu.premierLoyerMajore && trim(document.simulationFormEtapeSimu.premierLoyerMajore.value) == ""){
       mettreAZero(document.simulationFormEtapeSimu.premierLoyerMajore);
    }
    
    
}


function cacheSimuBlocPlanFinancier(){
    document.simulationFormEtapeSimu.vr.value= "";
    document.simulationFormEtapeSimu.premierLoyerMajore.value="";
    document.simulationFormEtapeSimu.vr.disabled= true;
    document.simulationFormEtapeSimu.premierLoyerMajore.disabled=true;
    document.simulationFormEtapeSimu.affichePlanFinancement.value = "false"; 
    document.getElementById("complementPlanFinancier").style.display='none';
}

function modifieProduitFinancier(listProduit,methodeCalculMontantLoyer,creationPage){
  var nature = document.simulationFormEtapeSimu.codeProduitFinancier.value;
  
  afficheOuCacheBlocPlanFinancierSimulation(listProduit,methodeCalculMontantLoyer);       
  
   //test vidage vr et premier loyer
  
  if ((nature == "LF") || (nature == "CB")){
     document.simulationFormEtapeSimu.vr.disabled= false;
     if(document.simulationFormEtapeSimu.premierLoyerMajore){
    	 document.simulationFormEtapeSimu.premierLoyerMajore.disabled=false;
     }    
     
     if (document.simulationFormEtapeSimu.affichePlanFinancement.value == "true"){
        document.simulationFormEtapeSimu.affichePlanFinancement.value = "true";
     }else{
        document.simulationFormEtapeSimu.vr.value= "";
        document.simulationFormEtapeSimu.premierLoyerMajore.value="";
        document.simulationFormEtapeSimu.vr.disabled= true;
        document.simulationFormEtapeSimu.premierLoyerMajore.disabled=true;
     }

  }else{      
     if (document.simulationFormEtapeSimu.affichePlanFinancement.value == "true"){
       document.simulationFormEtapeSimu.affichePlanFinancement.value = "false";
     }else{
        document.simulationFormEtapeSimu.vr.value= "";
        document.simulationFormEtapeSimu.premierLoyerMajore.value="";
        document.simulationFormEtapeSimu.vr.disabled= true;
        document.simulationFormEtapeSimu.premierLoyerMajore.disabled=true;
     }
  }
  // Affichage ou non du champ "Pourcentage de financement"
  if ((nature == "CC") || (nature == "CN")){
	  document.simulationFormEtapeSimu.prctFinancement.disabled = false;
	  if((document.simulationFormEtapeSimu.prctFinancement.value == null || document.simulationFormEtapeSimu.prctFinancement.value == "") && creationPage=="false"){
		  document.simulationFormEtapeSimu.prctFinancement.value = "100";
	  }
	  
	  document.getElementById("affichePrctFinancement").style.display = ""; 
  } else {
	  
	  document.simulationFormEtapeSimu.prctFinancement.value = "";
	  document.getElementById("affichePrctFinancement").style.display ="none";
	  document.simulationFormEtapeSimu.prctFinancement.disabled = true;	  
  }
	  
}


/*
* Utilis� uniquement pour les simus
*/
function modifieMethodeCalcul(listProduit,methodeCalculMontantLoyer){
   
   var methodeCalcul = document.simulationFormEtapeSimu.methodeCalcul.value;
   
   //Si Montant
   if (methodeCalcul == methodeCalculMontantLoyer){
      document.simulationFormEtapeSimu.methodeCalculCache.value = "loyer financier";
      if ((parseInt(document.simulationFormEtapeSimu.montant.value) || 0) > 0) {
    	  document.simulationFormEtapeSimu.montantSaisi.value = document.simulationFormEtapeSimu.montant.value;
      }
      document.simulationFormEtapeSimu.montantSaisiCache.value = document.simulationFormEtapeSimu.loyerFinancier.value;           
   }else{
      document.simulationFormEtapeSimu.methodeCalculCache.value = "montant";
      if ((parseInt(document.simulationFormEtapeSimu.loyerFinancier.value) || 0 ) > 0) {
    	  document.simulationFormEtapeSimu.montantSaisi.value = document.simulationFormEtapeSimu.loyerFinancier.value;
      }
      document.simulationFormEtapeSimu.montantSaisiCache.value =  document.simulationFormEtapeSimu.montant.value;
   }
   /** On valorise les champs effectivement affich� sur la page **/   
   document.getElementById("methodeCalculCacheSpan").innerHTML = document.simulationFormEtapeSimu.methodeCalculCache.value;                                 
   document.getElementById("montantSaisiCacheSpan").innerHTML = document.simulationFormEtapeSimu.montantSaisiCache.value;
   
   afficheOuCacheBlocPlanFinancierSimulation(listProduit,methodeCalculMontantLoyer);
}





function modifieCalage(){
   if (document.simulationFormEtapeSimu.topCalage != null){
     var size = document.simulationFormEtapeSimu.topCalage.length;
     for (var index = 0;index < size;index++){
        var choix = document.simulationFormEtapeSimu.topCalage[index];   
        if ((choix.checked) && (choix.value == "true")){
          document.simulationFormEtapeSimu.nbJoursCalage.disabled = false;
        }
      
        if ((choix.checked) && (choix.value == "false")){
          document.simulationFormEtapeSimu.nbJoursCalage.value = "";
          document.simulationFormEtapeSimu.nbJoursCalage.disabled = true;
        }
      }
    }
}

function modifieDerogation(){
   if (document.simulationFormEtapeSimu.topDerogation != null){
     var topDerogation = document.simulationFormEtapeSimu.topDerogation.checked;
   
     if (topDerogation){
      document.getElementById("afficheMotifDerogation").style.visibility='visible';
      document.getElementById("afficheMotifDerogation").style.display='block';
      document.simulationFormEtapeSimu.codeMotifDerogation.disabled=false;
     
     }else{
      document.getElementById("afficheMotifDerogation").style.visibility='hidden';
      document.getElementById("afficheMotifDerogation").style.display='none';
      document.simulationFormEtapeSimu.codeMotifDerogation.value="";
      document.simulationFormEtapeSimu.codeMotifDerogation.disabled=true;
   }
  }
}

function modifieDerogationSimuForcee(){
	   if (document.simulationFormEtapeSimu.topDerogation != null){
	     var topDerogation = document.simulationFormEtapeSimu.topDerogation.checked;
	   
	     if (topDerogation){
	      
	      document.getElementById("afficheMotifDerogation").style.visibility='visible';
	      document.getElementById("afficheMotifDerogation").style.display='block';
	      document.simulationFormEtapeSimu.codeMotifDerogation.disabled=false;
	     
	     }else{
	      document.getElementById("afficheMotifDerogation").style.visibility='hidden';
	      document.getElementById("afficheMotifDerogation").style.display='none';
	      document.simulationFormEtapeSimu.codeMotifDerogation.value="";
	      document.simulationFormEtapeSimu.codeMotifDerogation.disabled=true;
	   }
	  }
	   
	   if (document.simulationFormEtapeSimu.taux.value != null && document.simulationFormEtapeSimu.taux.value != ""){
			document.getElementById("visutaux").innerHTML = document.simulationFormEtapeSimu.taux.value;
		}
	}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_RAT_GER001.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

 

function afficheLiensPalier(elem,listChampPalierJs){
      var position = calculerPositionAbsolue(elem);
	  var actionsCalcul = document.getElementById('actionsCalcul');
		
	  var oUlElement = document.createElement("ul");
	  for(indxPal = 0; indxPal < listChampPalierJs.length;indxPal++) {	
	    var elementChampPalierJs =  listChampPalierJs[indxPal];
	    var oLiElement = document.createElement("li");
	    var oAElement = document.createElement("a");
	    var aActionLabel = elementChampPalierJs.libelle;
	    addListener(oAElement,'click',function(){clickLienMultiPalier(document.ratificationAvanceeForm,elementChampPalierJs.url);});
	    oAElement.href = '#';		 
	    remplacerTexte(oAElement, aActionLabel)	 
	    oUlElement.appendChild(oLiElement);
	    oLiElement.appendChild(oAElement);		
  	  }
	  if(actionsCalcul.hasChildNodes()) {		
	    actionsCalcul.replaceChild(oUlElement,actionsCalcul.firstChild);
	  } else {
	    actionsCalcul.appendChild(oUlElement);
	  }  
	
       //alert(actionsCalcul.innerHTML)
		
	  positionne ('actionsCalcul',position['X'],position['Y']);
	  actionsCalcul.style.display='block';
		
	  isActionActive = true;
}

function afficheLiensPalierSimulation(elem,listChampPalierJs){
    var position = calculerPositionAbsolue(elem);
	  var actionsCalcul = document.getElementById('actionsCalcul');
	  var oUlElement = document.createElement("ul");
	  for(indxPal = 0; indxPal < listChampPalierJs.length;indxPal++) {	
	    var elementChampPalierJs =  listChampPalierJs[indxPal];
	    var oLiElement = document.createElement("li");
	    var oAElement = document.createElement("a");
	    var aActionLabel = elementChampPalierJs.libelle;
	    addListener(oAElement,'click',function(){clickLienMultiPalierSimulation(document.simulationFormEtapeSimu,elementChampPalierJs.url);});
	    oAElement.href = '#';	
	    remplacerTexte(oAElement, aActionLabel)
	    oUlElement.appendChild(oLiElement);
	    oLiElement.appendChild(oAElement);	
	  }
	  if(actionsCalcul.hasChildNodes()) {		
	    actionsCalcul.replaceChild(oUlElement,actionsCalcul.firstChild);
	  } else {
	    actionsCalcul.appendChild(oUlElement);
	  }
	  positionne ('actionsCalcul',position['X'],position['Y']);
	  actionsCalcul.style.display='block';
	  isActionActive = true;
}

function clickLienMultiPalierSimulation(formulaire,nouvelleUrl){
	formulaire.montant.value = formulaire.montantSaisi.value;
	formulaire.loyerFinancier.value = formulaire.montantSaisiCache.value;
    formulaire.action=nouvelleUrl; 
    formulaire.submit();
}

function clickLienMultiPalier(formulaire,nouvelleUrl){
      formulaire.action=nouvelleUrl; 
      formulaire.submit();
}


function cacheLiensPalier(){
	  var evenement = (arguments[0] || window.event); 
	  setIsActionActive(evenement);
	  window.setTimeout("hideActionsCalcul()", 500);
}

function hideActionsCalcul(){
     if(!isActionActive){
       var actionsCalcul = document.getElementById('actionsCalcul');
       actionsCalcul.style.display='none';
     }
}

function modifieCalageRatification(){
   if (document.ratificationAvanceeForm.topCalage != null){
     var size = document.ratificationAvanceeForm.topCalage.length;
     for (var index = 0;index < size;index++){
       var choix = document.ratificationAvanceeForm.topCalage[index];   
       if ((choix.checked) && (choix.value == "true")){
         document.ratificationAvanceeForm.nbJoursCalage.disabled = false;
       }
      
      if ((choix.checked) && (choix.value == "false")){
        document.ratificationAvanceeForm.nbJoursCalage.value = "";
        document.ratificationAvanceeForm.nbJoursCalage.disabled = true;
      }
     }
   }
}



// Modification EFRONT-759 : en ratif simple (SS) on masque le input, mais affiche un span � la place.
function modifieDerogationRatification(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant) {
	
	var inputTopDerogation = jQuery("[name=topDerogation]");

	var blockDisplay = (navDectecteur.isMoz) ? "table-row" : "block";

	var topDerogation = inputTopDerogation.is(':checked');
	var typeRatification = jQuery("[name=typeRatification]").val();

	// 759 aussi : passage input > span de visu dans le cas ratif simple ...
	//  = document.getElementById("saisietaux").style.value;
	var taux = jQuery("[name=taux]").val();
	jQuery("#visutaux").html(taux);

	// Si ratif simple, on masque le bloc calcul du taux
	if (typeRatification != "SS") {
		jQuery("#bloccalcultaux").css("display", blockDisplay);
	}

	// alert(document.ratificationAvanceeForm.saisietaux.value);
	/******************************************/
	/** Gestion du champ motif de derogation **/
	/******************************************/
	if (topDerogation) {
		jQuery("#afficheMotifDerogation").css("display", blockDisplay);
		jQuery("[name=codeMotifDerogation]").attr("disabled", false);
		if(typeRatification == "SS") {
			
			// SSI 
			var btaux = jQuery("[name=methodecalcultaux]").is(":checked");
			if (!btaux) {
				jQuery("#visutaux").css("display", 'none');
				jQuery("[name=taux]").css("display", 'inline');
			}
			
			// On masque le bouton "calcul du taux" pour les ratifs simples non d�rog�es
			jQuery("#bloccalcultaux").css("display", blockDisplay);
			jQuery("#afficheTauxDerogation").css("display", blockDisplay);
		}
	}
	else {
		jQuery("#afficheMotifDerogation").css("display", 'none');
		jQuery("[name=codeMotifDerogation]").val("");
		jQuery("[name=codeMotifDerogation]").attr("disabled", true);
		if(typeRatification == "SS") {			
			// montantSaisiCacheSpan
			jQuery("#bloccalcultaux").css("display", 'none');
			
			if(jQuery("[name=methodecalcultaux]").is(":checked") == true) {
				jQuery("[name=methodecalcultaux]").attr("checked", false);
				modifieMethodeCalculTaux(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant);
			}
			
			// On masque le taux 
			jQuery("#afficheTauxDerogation").css("display", 'none');

		}
	}
}

// !!! PLUS UTILISE (du moins dans le front)
function modifieMethodeCalculRatification(listProduit,methodeCalculMontantSaisi){
   
   var methodeCalcul = document.ratificationAvanceeForm.methodeCalcul.value;
   
  //Si Montant
   if (methodeCalcul == methodeCalculMontantSaisi){
      document.ratificationAvanceeForm.methodeCalculCache.value = "Loyer financier";        
      document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.montant.value;
      document.ratificationAvanceeForm.montantSaisiCache.value = document.ratificationAvanceeForm.loyerFinancier.value;           
      document.getElementById("actionsCalcul").style.visibility='visible';
      if (document.getElementById("plusaffichemultipalier") != null){
         document.getElementById("plusaffichemultipalier").style.visibility='visible';
      }
      
   }else{
      document.ratificationAvanceeForm.methodeCalculCache.value = "montant";               
      document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.loyerFinancier.value;
      document.ratificationAvanceeForm.montantSaisiCache.value =  document.ratificationAvanceeForm.montant.value;
      document.getElementById("actionsCalcul").style.visibility='hidden';
      
      if (document.getElementById("plusaffichemultipalier") != null){
         document.getElementById("plusaffichemultipalier").style.visibility='hidden';
      }
      
   }
   /** On valorise les champs effectivement affich� sur la page **/   
   document.getElementById("methodeCalculCacheSpan").innerHTML = document.ratificationAvanceeForm.methodeCalculCache.value;                                 
   document.getElementById("montantSaisiCacheSpan").innerHTML = document.ratificationAvanceeForm.montantSaisiCache.value;
   
   afficheOuCacheBlocPlanFinancierRatification(listProduit,methodeCalculMontantSaisi);
}


function modifieGarantie(nomListeGarantie,nomLibelleGarantie){
    var listeGarantie = document.ratificationAvanceeForm.elements[nomListeGarantie];
    var libelleGarantie = document.ratificationAvanceeForm.elements[nomLibelleGarantie];
    
    if (listeGarantie.value != ""){
       libelleGarantie.value = listeGarantie.options[listeGarantie.selectedIndex].text;
    }else{
       libelleGarantie.value = "";
    }
}


/*
* 	BUT : Mettre � jour la checkbox (calcul du taux). On lance ensuite modifieMethodeCalculRatification2 qui se base sur la checkbox & le select.
*		Quand on arrive, la donn�e � jour est methodeCalculCache. 
*		Sert uniquement au chargement de la page, et pr�pare les donn�es avant l'appel � modifieMethodeCalculRatification2
*		La m�thode ci-apr�s (modifieMethodeCalculRatification2) n'est appel�e que pour les mises � jour
*/
function initMethodeCalculRatification(methodeCalculTaux, methodeCalculMontant)
{
	var methodeCalcul = document.ratificationAvanceeForm.methodeCalculCache.value;

	// alert("Init"+methodeCalcul);
	// On v�rifie si on se trouve en m�thode TAUX et si on a les droits ... 
	if (methodeCalcul == methodeCalculTaux && !isExterne) {
		// On coche la case
		jQuery('#choixMethodeCalculTauxGlobal').attr('value',methodeSaisieTauxGlobal);
	}
	else {
		// Sinon on met par d�faut � "MON"
		jQuery('input[name=methodeCalculCache]').attr('value', methodeCalculMontant);
	}
}

/*
* 	BUT : Mettre � jour la checkbox (calcul du taux). On lance ensuite modifieMethodeCalculSimulation2 qui se base sur la checkbox & le select.
*		Quand on arrive, la donn�e � jour est methodeCalculCache. 
*		Sert uniquement au chargement de la page, et pr�pare les donn�es avant l'appel � modifieMethodeCalculSimulation2
*		La m�thode ci-apr�s (modifieMethodeCalculSimulation2) n'est appel�e que pour les mises � jour
*/
function initMethodeCalculSimulation(methodeCalculTaux, methodeCalculMontant, methodeSaisieTauxGlobal) {
	var methodeCalcul = jQuery('input[name=methodeCalculCache]').attr('value');//document.simulationFormEtapeSimu.methodeCalculCache.value;

	if (methodeCalcul == methodeCalculTaux && !isExterne) {
		// On coche la case
		jQuery('#choixMethodeCalculTauxGlobal').attr('value',methodeSaisieTauxGlobal);
	} else {
		// Sinon on met par d�faut � "MON"
		jQuery('input[name=methodeCalculCache]').attr('value', methodeCalculMontant);		
	}
}



/*******************************************************************************/
/*******************************************************************************/
//TODO : Jamal --> Prise en compte du type de ratification (simple ou forc�e) **/
/*******************************************************************************/
/*******************************************************************************/

// EFRONT-759 > modifs
function modifieMethodeCalculRatification2(listProduit,methodeCalculLoyer, methodeCalculMontant, methodeCalculTaux)
{
	// alert(document.ratificationAvanceeForm.topDerogation);
	var topDerogation = (document.ratificationAvanceeForm.topDerogation == null || document.ratificationAvanceeForm.topDerogation == "undefined" ? false : document.ratificationAvanceeForm.topDerogation.checked);
	
	var btaux = (document.ratificationAvanceeForm.methodecalcultaux == null || document.ratificationAvanceeForm.methodecalcultaux == "undefined" ? false : document.ratificationAvanceeForm.methodecalcultaux.checked);
	// var btaux = document.ratificationAvanceeForm.methodecalcultaux.checked;
	
	var methodeCalcul = (btaux ? methodeCalculTaux : document.ratificationAvanceeForm.methodeCalcul.value);
	
	var typeRatification = document.ratificationAvanceeForm.typeRatification.value;
	
	document.ratificationAvanceeForm.methodeCalculCode.value = document.ratificationAvanceeForm.methodeCalcul.selectedIndex;
	// alert(document.ratificationAvanceeForm.methodeCalculCache.value+methodeCalcul);
	
	/*****************************/
	/** 1 - Si methode Montant **/
	/*****************************/
	if (methodeCalcul == methodeCalculLoyer)
	{
		document.ratificationAvanceeForm.methodeCalculCache.value = "MON";
		if (document.getElementById("methodeCalculCacheSpan") != null)
		{
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Loyer financier";
		}
		document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.montant.value;
		document.ratificationAvanceeForm.montantSaisiCache.value = document.ratificationAvanceeForm.loyerFinancier.value;           
		document.ratificationAvanceeForm.saisieloyer.value = document.ratificationAvanceeForm.loyerFinancier.value;           
		document.getElementById("actionsCalcul").style.visibility='visible';
	
		
	
		if (document.getElementById("plusaffichemultipalier") != null)
		{
			document.getElementById("plusaffichemultipalier").style.visibility='visible';
		}
	}
	/*****************************/
	/** 1 - Si methode Loyer    **/
	/*****************************/
	else if (methodeCalcul == methodeCalculMontant)
	{
		document.ratificationAvanceeForm.methodeCalculCache.value = "LOY";
		document.getElementById("methodeCalculCacheSpan").innerHTML = "Montant";
		document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.loyerFinancier.value;
		// alert("tata");
		document.ratificationAvanceeForm.montantSaisiCache.value =  document.ratificationAvanceeForm.montant.value;
		//On cache le lien multi palier
		document.ratificationAvanceeForm.saisieloyer.value = document.ratificationAvanceeForm.loyerFinancier.value;  
		document.getElementById("actionsCalcul").style.visibility='hidden';
		if (document.getElementById("plusaffichemultipalier") != null)
		{
			document.getElementById("plusaffichemultipalier").style.visibility='hidden';
		}
	}
	else
	{
		// alert("toto");
		document.ratificationAvanceeForm.methodeCalculCache.value = "TAU";
		
		// Dans l'intitul� on place direct ce qui correspond au select..
		if (document.ratificationAvanceeForm.methodeCalcul.value == 1)
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Loyer financier";
		else
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Montant";
		
		// On coche la case de recherche, apr�s avoir v�rifi� qu'on est bien d�rog� ...
		if (topDerogation || typeRatification == "SF")
		{
			document.ratificationAvanceeForm.methodecalcultaux.checked = true;
			modifieMethodeCalculTaux(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant);
		}
		
		document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.montant.value;  	
		document.ratificationAvanceeForm.saisieloyer.value =  document.ratificationAvanceeForm.loyerFinancier.value;
		
	}

	/** On valorise les champs effectivement affich� sur la page **/   
	if (document.getElementById("methodeCalculCacheSpan") != null)
	{
		document.getElementById("montantSaisiCacheSpan").innerHTML = document.ratificationAvanceeForm.montantSaisiCache.value;
		// alert("toto");
	}
	// alert("hmm1");
	afficheOuCacheBlocPlanFinancierRatification2(listProduit,methodeCalculMontant);
	// alert("hmm2");
}

//EFRONT-759 > modifs
function modifieMethodeCalculSimulation2(listProduit,methodeCalculLoyer, methodeCalculMontant, methodeCalculTaux) {
	var topDerogation = (document.simulationFormEtapeSimu.topDerogation == null || document.simulationFormEtapeSimu.topDerogation == "undefined" ? false : document.simulationFormEtapeSimu.topDerogation.checked);	
	var btaux = (document.simulationFormEtapeSimu.methodecalcultaux == null || document.simulationFormEtapeSimu.methodecalcultaux == "undefined" ? false : document.simulationFormEtapeSimu.methodecalcultaux.checked);
	var methodeCalcul = (btaux ? methodeCalculTaux : document.simulationFormEtapeSimu.methodeCalcul.value);	
	
	document.simulationFormEtapeSimu.methodeCalculCode.value = document.simulationFormEtapeSimu.methodeCalcul.selectedIndex;
	
	/*****************************/
	/** 1 - Si methode Montant **/
	/*****************************/
	if (methodeCalcul == methodeCalculLoyer) {
		document.simulationFormEtapeSimu.methodeCalculCache.value = "MON";
		if (document.getElementById("methodeCalculCacheSpan") != null){
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Loyer financier";
		}
		
		if(parseInt(document.simulationFormEtapeSimu.montant.value) || 0 > 0) {
			document.simulationFormEtapeSimu.montantSaisi.value = document.simulationFormEtapeSimu.montant.value;
		}
		document.simulationFormEtapeSimu.montantSaisiCache.value = document.simulationFormEtapeSimu.loyerFinancier.value;           
		document.simulationFormEtapeSimu.saisieloyer.value = document.simulationFormEtapeSimu.loyerFinancier.value;           
		document.getElementById("actionsCalcul").style.visibility='visible';
	
		if (document.getElementById("plusaffichemultipalier") != null){
			document.getElementById("plusaffichemultipalier").style.visibility='visible';
		}
	}
	/*****************************/
	/** 1 - Si methode Loyer    **/
	/*****************************/
	else if (methodeCalcul == methodeCalculMontant) {
		document.simulationFormEtapeSimu.methodeCalculCache.value = "LOY";
		document.getElementById("methodeCalculCacheSpan").innerHTML = "Montant";
		document.simulationFormEtapeSimu.montantSaisi.value = document.simulationFormEtapeSimu.loyerFinancier.value;
		document.simulationFormEtapeSimu.montantSaisiCache.value =  document.simulationFormEtapeSimu.montant.value;
		//On cache le lien multi palier
		document.simulationFormEtapeSimu.saisieloyer.value = document.simulationFormEtapeSimu.loyerFinancier.value;  
		document.getElementById("actionsCalcul").style.visibility='hidden';
		if (document.getElementById("plusaffichemultipalier") != null){
			document.getElementById("plusaffichemultipalier").style.visibility='hidden';
		}
	} else {
		document.simulationFormEtapeSimu.methodeCalculCache.value = "TAU";
		
		// Dans l'intitul� on place direct ce qui correspond au select..
		if (document.simulationFormEtapeSimu.methodeCalcul.value == 1)
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Loyer financier";
		else
			document.getElementById("methodeCalculCacheSpan").innerHTML = "Montant";
		

		document.simulationFormEtapeSimu.methodecalcultaux.checked = true;
		modifieMethodeCalculTauxSimulation(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant);

		document.simulationFormEtapeSimu.montantSaisi.value = document.simulationFormEtapeSimu.montant.value;  	
		document.simulationFormEtapeSimu.saisieloyer.value =  document.simulationFormEtapeSimu.loyerFinancier.value;
		
	}

	/** On valorise les champs effectivement affich� sur la page **/   
	if (document.getElementById("methodeCalculCacheSpan") != null){
		document.getElementById("montantSaisiCacheSpan").innerHTML = document.simulationFormEtapeSimu.montantSaisiCache.value;
	}
	afficheOuCacheBlocPlanFinancierSimulation(listProduit,methodeCalculMontant);
}
	



/* **********************************************************
*  PALIERS
*/
function modifieMethodeCalculRatificationPalier(listProduit,methodeCalculMontantLoyer,urlRaffraichitPage, methodeCalculMontant, methodeCalculTaux){
   var methodeCalcul = document.ratificationAvanceeForm.methodeCalcul.value;
   if (methodeCalcul == methodeCalculMontantLoyer){
     modifieMethodeCalculRatification2(listProduit,methodeCalculMontantLoyer, methodeCalculMontant, methodeCalculTaux);
   }else{
      var confirm = window.confirm('Les loyers saisis vont �tre perdus. �tes vous s�r de vouloir continuer?');
      if (confirm == true){
         document.ratificationAvanceeForm.action=urlRaffraichitPage; 
         document.ratificationAvanceeForm.submit();
      }else{
         document.ratificationAvanceeForm.methodeCalcul.value=methodeCalculMontantLoyer;
      }
   }
}

function modifieMethodeCalculSimulationPalier(listProduit,methodeCalculMontantLoyer,urlRaffraichitPage, methodeCalculMontant, methodeCalculTaux){
	   var methodeCalcul = document.simulationFormEtapeSimu.methodeCalcul.value;
	   if (methodeCalcul == methodeCalculMontantLoyer){
		   modifieMethodeCalculSimulation2(listProduit,methodeCalculMontantLoyer, methodeCalculMontant, methodeCalculTaux);
	   }else{
	      var confirm = window.confirm('Les loyers saisis vont �tre perdus. �tes vous s�r de vouloir continuer?');
	      if (confirm == true){
	         document.simulationFormEtapeSimu.action=urlRaffraichitPage; 
	         document.simulationFormEtapeSimu.submit();
	      }else{
	         document.simulationFormEtapeSimu.methodeCalcul.value=methodeCalculMontantLoyer;
	      }
	   }
	}

/*
* EFRONT-759
* ==========================
* Gestion du calcul du TAUX
* ==========================
* Principe : on utilise les m�mes champs HTML pour l'envoi du formulaire (> pas de modif r�gle RWEB)
* > Montant dans montantSaisi
* > Loyer dans montantSaisiCache (feinte : on place un input normal avec un onchange qui �crit dans le montantSaisiCache)
* > methodeCalculCache contient 
*
* A VOIR : multipalier, bloc compl�ment PFI 
*
* Chargement des donn�es : 
* > si on est directement en mode "calculerTaux" : A VOIR
* > si on change (on passe ici): selon le mode pr�c�dent on r�cup�re les valeurs au bons endroits
*
*/
function modifieMethodeCalculTaux(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant)
{	
	// ATTENTION : pour IE il faut forcer le selectIndex du SELECT : d�s qu'il est cach� cette valeur passe � -1 (d�selection ...)
	//document.ratificationAvanceeForm.methodeCalcul.selectedIndex = document.ratificationAvanceeForm.methodeCalculCode.value;
	jQuery('select[name=methodeCalcul]').prop('selectedIndex', jQuery('input[name=methodeCalculCode]').val());
	
	
	
	// var methode = document.ratificationAvanceeForm.methodeCalcul.options[document.ratificationAvanceeForm.methodeCalcul.selectedIndex].value;
	
	// alert(document.ratificationAvanceeForm.methodeCalcul.value+methode);
	
	//var btaux = document.ratificationAvanceeForm.methodecalcultaux.checked;
	var btaux = jQuery('input:checkbox[name=methodecalcultaux]:checked').val();
	
	//var topDerogation = document.ratificationAvanceeForm.topDerogation.checked;
	var topDerogation = jQuery('input:checkbox[name=topDerogation]:checked').val();
	
	
	var typeRatification = jQuery('input[name=typeRatification]').val();
	  	
   	if (!btaux)
   	{
	   	// D�cochage de la case
	   	// ------------------------
   		//document.getElementById("selectmodecalcul").style.display = 'block';
   		jQuery('#selectmodecalcul').css('display','block');
   		
   		//document.getElementById("intitulemontant").style.display = 'none';
   		jQuery('#intitulemontant').css('display','none');

   		//document.getElementById("methodeCalculCacheSpan").style.display = 'inline';
   		jQuery('#methodeCalculCacheSpan').css('display','inline');
   		//document.getElementById("montantSaisiCacheSpan").style.display = 'inline';
   		jQuery('#montantSaisiCacheSpan').show();
   		//document.getElementById("intituleloyer").style.display = 'none';
   		jQuery('#intituleloyer').css('display','none');
   		//document.getElementById("saisieloyer").style.display = 'none';
   		jQuery('#saisieloyer').css('display','none');


   		//document.getElementById("asterisqueloyer").style.display = 'none';
   		jQuery('#asterisqueloyer').css('display','none');
   		//document.getElementById("asterisquemontant").style.display = 'none';
   		jQuery('#asterisquemontant').css('display','none');
   		
   		//document.getElementById("asterisquemodecalcul").style.display = 'inline';
   		jQuery('#asterisquemodecalcul').css('display','inline');
   		// On passe le input taux en span
   		// document.ratificationAvanceeForm.taux.style.display = 'inline';
   		
   		// !! A ne lancer que si d�rogation coch� 
		if (topDerogation || typeRatification == "SF")
		{
	   		//document.getElementById("visutaux").style.display = 'none';
	   		jQuery('#visutaux').parent().css('display','none');
   			//document.getElementById("saisietaux").style.display = 'inline';
   			jQuery('#saisietaux').css('display','inline');
   		}
   		

		// On valorise le champ cach� "m�thode calcul"
		//document.ratificationAvanceeForm.methodeCalculCache.value = document.ratificationAvanceeForm.methodeCalcul.value;
		jQuery('input[name=methodeCalculCache]').val(jQuery('select[name=methodeCalcul]').val());
   		
   		// On r�cup�re l'�tat dans lequel on �tait avant cochage de calcul taux : valeur du select
   		// On en profite pour mettre � jour l'intitul� (montant / loyer financier)
		
		//if (document.ratificationAvanceeForm.methodeCalcul.value == methodeCalculMontant)
		if (jQuery('select[name=methodeCalcul]').val() == methodeCalculMontant) 
		{
			// Loyer: 
   			/*document.getElementById("montantSaisiCacheSpan").innerHTML = document.ratificationAvanceeForm.montantSaisi.value;
   			document.ratificationAvanceeForm.montantSaisi.value = document.ratificationAvanceeForm.saisieloyer.value;
   			document.getElementById("methodeCalculCacheSpan").innerHTML = "Montant";*/
console.log(jQuery('input[name=montantSaisi]').val())   			
   			jQuery('#montantSaisiCacheSpan').html(jQuery('input[name=montantSaisi]').val());
   			jQuery('input[name=montantSaisi]').val(jQuery('input[name=saisieloyer]').val());
   			jQuery('#methodeCalculCacheSpan').html("Montant");
		}
		//else if (document.ratificationAvanceeForm.methodeCalcul.value == methodeCalculLoyer)
		else if (jQuery('input[name=methodeCalculLoyer]').val() == methodeCalculLoyer) 
		{
   			
   			// Montant ok, loyer � r�cup dans saisieloyer
   			//document.getElementById("montantSaisiCacheSpan").innerHTML = document.ratificationAvanceeForm.saisieloyer.value;	
console.log(jQuery('input[name=saisieloyer]').val())
   			jQuery('#montantSaisiCacheSpan').html(jQuery('input[name=saisieloyer]').val());
   			// alert(document.ratificationAvanceeForm.saisieloyer.value+"hihi");
   			//document.getElementById("methodeCalculCacheSpan").innerHTML = "Loyer financier";
   			jQuery('#methodeCalculCacheSpan').html("Loyer financier");
   			
			//if (document.getElementById("plusaffichemultipalier") != null)
			if (jQuery('#plusaffichemultipalier') != null) 
			
			{
				//document.getElementById("plusaffichemultipalier").style.visibility='visible';
				jQuery('#plusaffichemultipalier').css('visibility','visible');
			}
   			
		}
   	}
   	else
   	{
 	   	// Cochage de la case
	   	// ------------------------
	   	
   		// On enl�ve le select pour afficher "Montant" 
   		// On modifie "methodeCalcul" pour afficher "Loyer"
   		// On v�rifie que le taux est affich� en lecture (span, pas input)
   		

   		// alert(document.ratificationAvanceeForm.methodeCalcul.value+" - "+document.getElementById("montantSaisiCacheSpan").innerHTML+" - "+document.ratificationAvanceeForm.montantSaisi.value);

		// On valorise le champ cach� "m�thode calcul"
		//document.ratificationAvanceeForm.methodeCalculCache.value = methodeCalculTaux;
		jQuery('input[name=methodeCalculCache]').val(methodeCalculTaux);		
		
		//if (document.getElementById("plusaffichemultipalier") != null)
		if (jQuery('#plusaffichemultipalier') != null)
		{
			//document.getElementById("plusaffichemultipalier").style.visibility='hidden';
			jQuery('#plusaffichemultipalier').css('visibility','hidden');
		}
		
		
   		// On r�cup�re les valeurs si elles sont saisies
   		//if (document.ratificationAvanceeForm.methodeCalcul.value == methodeCalculLoyer)
   		if (jQuery('select[name=methodeCalcul]').val() == methodeCalculLoyer) 
   		{

   			// montantSaisi contient le montant > on copie juste le loyer (montantSaisiCacheSpan) dans le input pr�vu � cet effet (saisieloyer)
   		   	// document.ratificationAvanceeForm.montantSaisi = "";
   			//document.ratificationAvanceeForm.saisieloyer.value = document.getElementById("montantSaisiCacheSpan").innerHTML;
   			jQuery('input[name=saisieloyer]').val(jQuery('#montantSaisiCacheSpan').html());
   		}
   		//else if (document.ratificationAvanceeForm.methodeCalcul.value == methodeCalculMontant)
   		else if (jQuery('select[name=methodeCalcul]').val() == methodeCalculMontant)	
   		{
   			// montantSaisi contient le loyer 
   			//document.ratificationAvanceeForm.saisieloyer.value = document.ratificationAvanceeForm.montantSaisi.value;
   			//document.ratificationAvanceeForm.montantSaisi.value = document.getElementById("montantSaisiCacheSpan").innerHTML;
   			
   			jQuery('input[name=saisieloyer]').val(jQuery('input[name=montantSaisi]').val());
   			jQuery('input[name=montantSaisi]').val(jQuery('#montantSaisiCacheSpan').html());
   			
   		}
   		
   		// On valorise le champ "methodeCalcul"
   		//document.ratificationAvanceeForm.methodeCalcul.value = methodeCalculTaux;
   		jQuery('select[name=methodeCalcul]').val(methodeCalculTaux);
   		
   		//document.getElementById("selectmodecalcul").style.display = 'none';
   		jQuery('#selectmodecalcul').css('display', 'none');
   		//document.getElementById("intitulemontant").style.display = 'inline';
   		jQuery('#intitulemontant').css('display','inline');


			//document.getElementById("methodeCalculCacheSpan").style.display = 'none';
			jQuery('#methodeCalculCacheSpan').css('display', 'none');
   		//document.getElementById("montantSaisiCacheSpan").style.display = 'none';
			jQuery('#montantSaisiCacheSpan').hide();
   		//document.getElementById("intituleloyer").style.display = 'inline';
   		jQuery('#intituleloyer').css('display','inline');
   		//document.getElementById("saisieloyer").style.display = 'inline';
   		jQuery('#saisieloyer').css('display','inline');
   		//document.getElementById("asterisqueloyer").style.display = 'inline';		
   		jQuery('#asterisqueloyer').css('display','inline');
   		//document.getElementById("asterisquemontant").style.display = 'inline';
   		jQuery('#asterisquemontant').css('display','inline');
   		//document.getElementById("asterisquemodecalcul").style.display = 'none';
   		jQuery('#asterisquemodecalcul').css('display', 'none');
   		
   		
   		// On passe le span taux en input
   		
   		//document.ratificationAvanceeForm.taux.style.display = 'none';
   		jQuery('#saisietaux').css('display', 'none');
   		//document.getElementById("visutaux").style.display = 'inline';
   		jQuery('#visutaux').css('display','inline');
   	}
}
	


/*
* ==========================
* Gestion du calcul du TAUX
* ==========================
* Principe : on utilise les m�mes champs HTML pour l'envoi du formulaire (> pas de modif r�gle RWEB)
* > Montant dans montantSaisi
* > Loyer dans montantSaisiCache (feinte : on place un input normal avec un onchange qui �crit dans le montantSaisiCache)
* > methodeCalculCache contient 
*
* A VOIR : multipalier, bloc compl�ment PFI 
*
* Chargement des donn�es : 
* > si on est directement en mode "calculerTaux" : A VOIR
* > si on change (on passe ici): selon le mode pr�c�dent on r�cup�re les valeurs au bons endroits
*
*/
function modifieMethodeCalculTauxSimulation(methodeCalculTaux, methodeCalculLoyer, methodeCalculMontant)
{
	// ATTENTION : pour IE il faut forcer le selectIndex du SELECT : d�s qu'il est cach� cette valeur passe � -1 (d�selection ...)
	jQuery('select[name=methodeCalcul]').prop('selectedIndex', jQuery('input[name=methodeCalculCode]').attr('value'));
	
	var btaux = jQuery('input:checkbox[name=methodecalcultaux]:checked').val();
	var topDerogation = jQuery('input:checkbox[name=topDerogation]:checked').val();

	// alert(btaux);
   	
   	if (!btaux) {
	   	// D�cochage de la case
	   	// ------------------------
   		jQuery('#selectmodecalcul').css('display','block');
   		jQuery('#intitulemontant').css('display','none');

   		jQuery('#methodeCalculCacheSpan').css('display','inline');
   		jQuery('#montantSaisiCacheSpan').show();
   		jQuery('#intituleloyer').css('display','none');
   		jQuery('#saisieloyer').css('display','none');


   		jQuery('#asterisqueloyer').css('display','none');
   		jQuery('#asterisquemontant').css('display','none');
   		
   		jQuery('#asterisquemodecalcul').css('display','inline');
   		
	   	jQuery('#visutaux').parent().css('display','none');
   		jQuery('#saisietaux').css('display','inline');
		
		jQuery('#selectmodecalcultaux').css('display', 'block');
		if(jQuery('#visutaux').html()!='--') jQuery('#saisietaux').val(jQuery('#visutaux').html());
		jQuery('#selectmodecalcultaux').next().remove();

		// On valorise le champ cach� "m�thode calcul"
		jQuery('input[name=methodeCalculCache]').val(jQuery('select[name=methodeCalcul]').val());

   		
   		// On r�cup�re l'�tat dans lequel on �tait avant cochage de calcul taux : valeur du select
   		// On en profite pour mettre � jour l'intitul� (montant / loyer financier)
		
		if (jQuery('select[name=methodeCalcul]').val() == methodeCalculMontant) {
			// Loyer: 
   			jQuery('#montantSaisiCacheSpan').html(jQuery('input[name=montantSaisi]').val());
   			jQuery('input[name=montantSaisi]').val(jQuery('input[name=saisieloyer]').val());
   			jQuery('#methodeCalculCacheSpan').html("Montant");
   			
		} else if (jQuery('select[name=methodeCalcul]').val() == methodeCalculLoyer) {
   			
   			// Montant ok, loyer � r�cup dans saisieloyer
   			jQuery('#montantSaisiCacheSpan').html(jQuery('input[name=saisieloyer]').val());
   			jQuery('#methodeCalculCacheSpan').html("Loyer financier");
   			
   			
			if (jQuery('#plusaffichemultipalier') != null) {
				jQuery('#plusaffichemultipalier').css('visibility','visible');
			}
		}
   	} else {   		
 	   	// Cochage de la case
	   	// ------------------------
	   	
   		// On enl�ve le select pour afficher "Montant" 
   		// On modifie "methodeCalcul" pour afficher "Loyer"
   		// On v�rifie que le taux est affich� en lecture (span, pas input)
   		

   		// alert(document.ratificationAvanceeForm.methodeCalcul.value+" - "+document.getElementById("montantSaisiCacheSpan").innerHTML+" - "+document.ratificationAvanceeForm.montantSaisi.value);

		// On valorise le champ cach� "m�thode calcul"
		jQuery('input[name=methodeCalculCache]').val(methodeCalculTaux);
				
		
		if (jQuery('#plusaffichemultipalier') != null){
			jQuery('#plusaffichemultipalier').css('visibility','hidden');
		}
		
   		// On r�cup�re les valeurs si elles sont saisies
   		if (jQuery('select[name=methodeCalcul]').val() == methodeCalculLoyer) {
   			// montantSaisi contient le montant > on copie juste le loyer (montantSaisiCacheSpan) dans le input pr�vu � cet effet (saisieloyer)
   		   	// document.ratificationAvanceeForm.montantSaisi = "";
   			jQuery('input[name=saisieloyer]').val(jQuery('#montantSaisiCacheSpan').html());
   		} else if (jQuery('select[name=methodeCalcul]').val() == methodeCalculMontant){
   			// montantSaisi contient le loyer 
   			jQuery('input[name=saisieloyer]').val(jQuery('input[name=montantSaisi]').val());
   			jQuery('input[name=montantSaisi]').val(jQuery('#montantSaisiCacheSpan').html());
   		}
   		
   		// On valorise le champ "methodeCalcul"
   		jQuery('select[name=methodeCalcul]').val(methodeCalculTaux);
		
		
		// On passe en mode de saisie 'Taux global'
		jQuery('#choixMethodeCalculTauxGlobal').val(methodeSaisieTauxGlobal);
		jQuery('#xh-methodecalcultauxglobal').children().html(jQuery('#choixMethodeCalculTauxGlobal option:selected').text());
		modifierMethodeSaisieTauxGlobal(methodeSaisieTauxGlobal,methodeSaisieTauxRefinancement);
		jQuery('#selectmodecalcultaux').css('display', 'none');
		jQuery('#selectmodecalcultaux').parent().append('<div class="label" style="width:225px;float:left;">Taux global</div>');
   		
   		jQuery('#selectmodecalcul').css('display', 'none');
   		jQuery('#intitulemontant').css('display','inline');

		jQuery('#methodeCalculCacheSpan').css('display', 'none');
   		jQuery('#montantSaisiCacheSpan').hide();

   		jQuery('#intituleloyer').css('display','inline');
   		jQuery('#saisieloyer').css('display','inline');
   		jQuery('#asterisqueloyer').css('display','inline');		
   		jQuery('#asterisquemontant').css('display','inline');
   		
   		jQuery('#asterisquemodecalcul').css('display', 'none');
   			
   		// On passe le span taux en input   		
		jQuery('#saisietaux').css('display', 'none');
		jQuery('#visutaux').parent().css('display','block');
		if(jQuery('#visutaux').html() == "") {
			jQuery('#visutaux').html('--');
		}
   		// alert("fin JS");
   	}
}


function afficheOuCacheBlocPlanFinancierRatification2(listProduit,methodeCalculMontant)
{

	var duree = document.ratificationAvanceeForm.duree.value;
	var montant = document.ratificationAvanceeForm.montantSaisi.value;
	var nature = document.ratificationAvanceeForm.codeProduitFinancier.value;
	var typeLoyerMontant = document.ratificationAvanceeForm.methodeCalculCache.value;

	// alert("Methode calcul cach�: "+typeLoyerMontant);

	/** Remplace les , par les .  **/
	montant = montant.replace(",",".");
	var dureeEntier = parseInt(duree);
	var montantEntier = parseFloat(montant);
	/** Il manque un des parametres pour trouver le produit FlashLease **/ 
	if ((trim(nature) == "") || (trim(montant) == "") || (trim(duree) == ""))
	{
		cacheRatifBlocPlanFinancier();
		return;
	}

	/*************************************************/
	/** 1 - Cr�dit bail bail ou Location financiere **/
	/*************************************************/
	var typeRatification = document.ratificationAvanceeForm.typeRatification.value;        
	if ((nature == "LF") || (nature == "CB"))
	{
		/********************************/
		/** 1.2 - Si simulation simple ou simple apporteur(Dans le service ratif, le type de ratif est SS pour les 2) **/
		/********************************/    
		if ((typeRatification == "SS") || (typeRatification == "RP"))
		{
			/***************************************/
			/** 1.2.1 - Si methodeCalcul = ""     **/
			/***************************************/
			if (typeLoyerMontant == "")
			{
				return;
			}
			/***************************************/
			/** 1.2.1 - Si methodeCalcul = "LOY"  **/
			/***************************************/
			else if (typeLoyerMontant == methodeCalculMontant)
			{ 

				for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++)
				{
					var produit = listProduit[indxlistproduit];
					var affichePlanFinancier = produit[6];

					if ((affichePlanFinancier == "true") && (produit[0] == nature))
					{
						// alert("tototo");
						afficheRatifBlocPlanFinancier();
					}  
				}
			}
			/****************************************/
			/** 1.2.1 - Autres CAS (MON, TAU)      **/
			/****************************************/
			else
			{

				/** Test pour verifier que tous les champs sont renseignes **/
				if ((nature == "") || isNaN(dureeEntier) || (isNaN(montantEntier)))
				{
					return;
				}
				
				// alert("passage");       

				/**********************************************************************************************/
				/** 1.2.1.1 Si le produit correspond, on affiche le bloc financier et on sort de la fonction **/
				/**********************************************************************************************/
				for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++)
				{
					var produit = listProduit[indxlistproduit];
					/** On teste si le code nature correspond au code nature recherche **/
					if (produit[0] == nature)
					{
						var dureeMin = parseInt(produit[1]);
						var dureeMax = parseInt(produit[2]);
						/** Test sur la duree **/
						if ((dureeMin < dureeEntier) && (dureeEntier <= dureeMax))
						{
							/** Test sur le montant **/
							var montantMin = parseFloat(produit[3]);
							var montantMax = parseFloat(produit[4]);

							if ((montantMin < montantEntier) && (montantEntier <= montantMax))
							{
								var affichePlanFinancier = produit[6];                 
								if (affichePlanFinancier == "true")
								{
									// alert("aaaaaah produit trouv�");
									afficheRatifBlocPlanFinancier();
									return;
								}
							}
						}
					}      
				}

				/**************************************************************************************/
				/** 1.2.1.1 Si aucun produit ne correspond, on n'affiche pas le bloc financier       **/
				/**************************************************************************************/
				cacheRatifBlocPlanFinancier();
				// alert("pas d'affichage");
			}
		}
		/************************************/
		/** 1.2 - Si simulation non simple **/
		/************************************/
		else
		{
			// alert("simu non simple");
			afficheRatifBlocPlanFinancier();
		}
	}
	/************************************************/
	/** 1 - Si nature est differente de e CB et LF **/
	/************************************************/
	else
	{
		// alert("nature pas bonne");
		cacheRatifBlocPlanFinancier();
	}
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/



function afficheOuCacheBlocPlanFinancierRatification(listProduit,methodeCalculMontantSaisi){

    var duree = document.ratificationAvanceeForm.duree.value;
    var montant = document.ratificationAvanceeForm.montantSaisi.value;
    var nature = document.ratificationAvanceeForm.codeProduitFinancier.value;
    var typeLoyerMontant = document.ratificationAvanceeForm.methodeCalcul.value; 
   
    
    //Remplace les , par les . 
    montant = montant.replace(",",".");
    
    var dureeEntier = parseInt(duree);
    var montantEntier = parseFloat(montant);
     
    /**
       Il manque un des parametres montant, duree, nature pour trouver le produit FLASHLEASE.
       On le met donc a null 
    **/
    if ((trim(nature) == "") || (trim(montant) == "") || (trim(duree) == "")){
       cacheRatifBlocPlanFinancier();
       return;
    }
 
    /**
      Si la nature est location financiere ou Credit-Bail.
    **/
    if ((nature == "LF") || (nature == "CB")){
    
       /**
         Si on calcule le montant en fonction du loyer 
       **/  
      if (typeLoyerMontant != methodeCalculMontantSaisi){      
         for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++){
           var produit = listProduit[indxlistproduit];
           var affichePlanFinancier = produit[6];
           if ((affichePlanFinancier == "true") && (produit[0] == nature)){
               afficheRatifBlocPlanFinancier();               
           }  
         }
       }
       //Si methodeCalcul=Montant
       else{     
        //Test pour verifier que tous les champs sont renseignes
         if ((nature == "") || isNaN(dureeEntier) || (isNaN(montantEntier))){
            return;
         }                 
         for (var indxlistproduit = 0;indxlistproduit < listProduit.length ;indxlistproduit++){
          var produit = listProduit[indxlistproduit];                   
          //On teste si le code nature correspond au code nature recherche
          if (produit[0] == nature){
            var dureeMin = parseInt(produit[1]);
            var dureeMax = parseInt(produit[2]);   
            //Test sur la duree
            if ((dureeMin < dureeEntier) && (dureeEntier <= dureeMax)){
             //Test sur le montant
              var montantMin = parseFloat(produit[3]);
              var montantMax = parseFloat(produit[4]);
            
              if ((montantMin < montantEntier) && (montantEntier <= montantMax)){                                  
                  var affichePlanFinancier = produit[6];
                  if (affichePlanFinancier == "true"){
                    /** Si le produit correspond, on affiche le bloc financier et on sort de la fonction **/
                    afficheRatifBlocPlanFinancier();                                                                   
                    return;
                  }
              }              
          }          
       }       
      }      
      cacheRatifBlocPlanFinancier();
      
     }
     }else{
       cacheRatifBlocPlanFinancier();
     }
}

function afficheRatifBlocPlanFinancier(){

    document.ratificationAvanceeForm.vr.disabled= false;
    if (document.ratificationAvanceeForm.premierLoyerMajore != null){
       document.ratificationAvanceeForm.premierLoyerMajore.disabled=false;
    }
    
            
    document.getElementById("complementPlanFinancier").style.visibility='visible';
    document.getElementById("complementPlanFinancier").style.display='block';
    document.ratificationAvanceeForm.affichePlanFinancement.value = "true";
     if (trim(document.ratificationAvanceeForm.vr.value) == ""){
       mettreAZero(document.ratificationAvanceeForm.vr);
    }
    
    if ((document.ratificationAvanceeForm.premierLoyerMajore) && (trim(document.ratificationAvanceeForm.premierLoyerMajore.value) == "")){
       mettreAZero(document.ratificationAvanceeForm.premierLoyerMajore);
    }
    
    

}

function cacheRatifBlocPlanFinancier(){
    document.ratificationAvanceeForm.vr.value= "";
    document.ratificationAvanceeForm.premierLoyerMajore.value="";
    
    
    document.ratificationAvanceeForm.vr.disabled= true;    
    document.ratificationAvanceeForm.premierLoyerMajore.disabled=true;
    
    
    document.ratificationAvanceeForm.affichePlanFinancement.value = "false";
    document.getElementById("complementPlanFinancier").style.visibility='hidden';
    document.getElementById("complementPlanFinancier").style.display='none';
    
}


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_RAT_GER002.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

function modifieVisibiliteAnneeMiseServiceRatification(nomParamNeuf,nomParamAnnee){
    
    var paramNeuf = document.ratificationSimpleForm.elements[nomParamNeuf];
    var paramAnnee = document.ratificationSimpleForm.elements[nomParamAnnee];
    
    /*var size = paramNeuf.length;
    
    for (var index = 0;index < size;index++){
       var choix = paramNeuf[index];
       if ((choix.checked) && (choix.value == "false")){
         paramAnnee.disabled = false;
      }
      
      if ((choix.checked) && (choix.value == "true")){
         paramAnnee.value = "";
         paramAnnee.disabled = true;
      }
    }*/
    
    modifieVisibiliteAnneeMiseServiceAux(paramNeuf,paramAnnee);
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_RAT_GER003.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function MultiPalierJs(_rang,_nombreEcheance,_periodicite,_loyer){
   this.rangPalier = _rang;
   this.nombreEcheance = _nombreEcheance;
   this.periodicite = _periodicite;
   this.loyer = _loyer;
}

//Fonction permet d'ajouter un palier dans la liste
//Parametre 1 : formulaire courant
//Parametre 2 : clePalier : Cle pour les paliers
function addMultiPalierJs(formulaire,clePalier){
     
     //On incremente la sequence.
     formulaire.sequencePalier.value = parseInt(formulaire.sequencePalier.value) + 1;
     
     var rangPalier = parseInt(formulaire.nombrePalier.value) + 1;
     
     var nombreEcheance = formulaire.nombreEcheanceNouveauPalier.value;
     if (nombreEcheance != null){
        nombreEcheance = nombreEcheance.replace("'","\'");
     }

     var periodicite = formulaire.codePeriodiciteNouveauPalier.value;
     if (periodicite != null){
        periodicite = periodicite.replace("'","\'");
     }
     
     var loyer = formulaire.loyerNouveauPalier.value;
     if (loyer != null){
         loyer = loyer.replace("'","\'");
     }
     
     
     var elementSelectPeriodicite = formulaire.codePeriodiciteNouveauPalier;
    
     var multiPalierJs = new MultiPalierJs(rangPalier,nombreEcheance,periodicite,loyer);
     
     var cleCompletePalier = clePalier + formulaire.sequencePalier.value;
     
     //On ajoute la palier
     this.addPalier(multiPalierJs,elementSelectPeriodicite,formulaire.nombrePalier,formulaire.sequencePalier.value,cleCompletePalier);
     
     //On incremente le rang du palier
     formulaire.nombrePalier.value = rangPalier;
     
}

function addPalier(multiPalierJs,elementSelectPeriodicite,elementNombrePalier,sequencePalier,clePalier){

     //Recuperation du tableau
     var tbodymultipalier = document.getElementById("tbodymultipalier");
     var trespacepalier = document.getElementById("trespacepalier");
    
     
     var trCreerNouveauPalier = document.createElement("tr");
     trCreerNouveauPalier.setAttribute("id","palier"+sequencePalier);
     
     //Ajout de la colonne rang
     var tdCreerRang = document.createElement("td");
     tdCreerRang.appendChild(document.createTextNode(multiPalierJs.rangPalier));
     trCreerNouveauPalier.appendChild(tdCreerRang);
     
     //Ajout du champ nouvelle echeance
     var tdCreerNouvelleEcheance = document.createElement("td");
     var interieurNouvelleEcheance = document.createElement("input");
     interieurNouvelleEcheance.setAttribute("size",7);
     interieurNouvelleEcheance.setAttribute("maxLength",7);
     interieurNouvelleEcheance.setAttribute("name","nombreEcheance("+clePalier+")");     
     interieurNouvelleEcheance.setAttribute("value",multiPalierJs.nombreEcheance);
     tdCreerNouvelleEcheance.appendChild(interieurNouvelleEcheance);
     trCreerNouveauPalier.appendChild(tdCreerNouvelleEcheance);
     
     //Ajout du champ Periodicite
     var tdCreerPeriodicite = document.createElement("td");
     var interieurPeriodicite = document.createElement("select");
     var selectCodePeriodiciteNouveauPalier = elementSelectPeriodicite;
     var filsSelectCodePeriodiciteNouveauPalier = selectCodePeriodiciteNouveauPalier.childNodes;
     for (var indxPer= 0;indxPer < filsSelectCodePeriodiciteNouveauPalier.length;indxPer++){
        var element = filsSelectCodePeriodiciteNouveauPalier[indxPer].cloneNode(true);
        interieurPeriodicite.appendChild(element);
     }
     interieurPeriodicite.value=multiPalierJs.periodicite;
     
     
     //Correction BUG connu, lorsque l'on clonne un option, l'attribut selected n'est pas copie
//     if (isLoadPage == false){
 //       interieurPeriodicite.selectedIndex=selectCodePeriodiciteNouveauPalier.selectedIndex;
  //   }
     
     interieurPeriodicite.setAttribute("name","periodicitePalier("+clePalier+")");     
     
     tdCreerPeriodicite.appendChild(interieurPeriodicite);
     trCreerNouveauPalier.appendChild(tdCreerPeriodicite);
     
     //Ajout du champ loyer
     var tdCreerLoyer = document.createElement("td");
     var interieurLoyer = document.createElement("input");
     interieurLoyer.setAttribute("size",18);
     interieurLoyer.setAttribute("maxLength",12);
     interieurLoyer.setAttribute("name","loyerPalier("+clePalier+")");
     interieurLoyer.setAttribute("value",multiPalierJs.loyer);
     
     tdCreerLoyer.appendChild(interieurLoyer);
     tdCreerLoyer.appendChild(document.createTextNode(" �"));
     trCreerNouveauPalier.appendChild(tdCreerLoyer);
     
     //Ajout du lien supprimer
     var tdCreerLienSupprimer = document.createElement("td");
     var interieurLienSupprimer = document.createElement("span");
     interieurLienSupprimer.style.cursor = "pointer";
     
     //Evenement sur onclick
     addListener(interieurLienSupprimer,'click',function(){deleteMultiPalierJs(elementNombrePalier,sequencePalier);});
     
     interieurLienSupprimer.appendChild(document.createTextNode("Supprimer"));
     tdCreerLienSupprimer.appendChild(interieurLienSupprimer);
     trCreerNouveauPalier.appendChild(tdCreerLienSupprimer);
     
     //Ajout de la nouvelle ligne dans le tableau
     tbodymultipalier.insertBefore(trCreerNouveauPalier,trespacepalier);
     
     //Test sur le bouton ajouter (A limiter a 4 paliers)
     var nbElement = parseInt(elementNombrePalier.value)  + 1;
     if (nbElement >= 4){
        document.getElementById("trespacepalier").style.display='none';
        document.getElementById("trnouveaupalier").style.display='none';
     }

}

function deleteMultiPalierJs(elementNombrePalier,sequencePalier){
  
  
   //Recupere le noeud parent pour supprimer.
   var tbodymultipalier = document.getElementById("tbodymultipalier");
   
   //Recupere le noeud enfant a supprimer.
   var idtrSupprimerNouveauPalier="palier"+sequencePalier;
   var trSupprimerNouveauPalier = document.getElementById(idtrSupprimerNouveauPalier);
   var trespacepalier = document.getElementById("trespacepalier");
   
   //Renumerotte l'ensemble des rangs des fils.
   for (var frere = trSupprimerNouveauPalier.nextSibling; frere != trespacepalier; frere = frere.nextSibling) { 
      var noeudChangerRang = frere.firstChild.firstChild;
      noeudChangerRang.nodeValue =  parseInt(noeudChangerRang.nodeValue) - 1;
   }
   
   //Supprime l'element.
   tbodymultipalier.removeChild(trSupprimerNouveauPalier);
   
   //On affiche le champ nouveau palier.
   if (parseInt(elementNombrePalier.value) == 4){
      document.getElementById("trespacepalier").style.display='';
      document.getElementById("trnouveaupalier").style.display='';      
   }
   
   //Suppression d'un nombre palier.
   elementNombrePalier.value = parseInt(elementNombrePalier.value) - 1;
}


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_CTR_CRE002.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

function afficheOuCacheLoyer(){
  if (document.clientContratForm.codeFondsDeCommerce != null){
     var fondsCommerce = document.clientContratForm.codeFondsDeCommerce.value;
  
     if (fondsCommerce == "LOC"){
        afficheLoyerContrat();
     }else{
        cacheLoyerContrat();
     }
  }
}

function afficheLoyerContrat(){
    if (document.clientContratForm.loyer != null){
      document.clientContratForm.loyer.disabled= false;
      document.getElementById("blocLoyerContrat").style.visibility='visible';
      document.clientContratForm.clientLocataire.value = "true";
      if (trim(document.clientContratForm.loyer.value) == ""){
       mettreAZero(document.clientContratForm.loyer);
      }
    }
}


function cacheLoyerContrat(){
    if (document.clientContratForm.loyer != null){
       document.clientContratForm.loyer.value= "";
       document.clientContratForm.loyer.disabled= true;
       document.clientContratForm.clientLocataire.value = "false"; 
       document.getElementById("blocLoyerContrat").style.visibility='hidden';
    }
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_CTR_CRE006.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function modifieVisibiliteAnneeMiseServiceContrat(nomParamNeuf,nomParamAnnee){
    
    var paramNeuf = document.materielContratForm.elements[nomParamNeuf];
    var paramAnnee = document.materielContratForm.elements[nomParamAnnee];
    
    /*var size = paramNeuf.length;
    
    for (var index = 0;index < size;index++){
       var choix = paramNeuf[index];
       if ((choix.checked) && (choix.value == "false")){
         paramAnnee.disabled = false;
      }
      
      if ((choix.checked) && (choix.value == "true")){
         paramAnnee.value = "";
         paramAnnee.disabled = true;
      }
    }*/

    modifieVisibiliteAnneeMiseServiceAux(paramNeuf,paramAnnee);
}

function modifieVisibiliteAnneeMiseServiceSimulation(nomParamNeuf,nomParamAnnee){

    var paramNeuf = document.materielSimulationForm.elements[nomParamNeuf];
    var paramAnnee = document.materielSimulationForm.elements[nomParamAnnee];
    
    modifieVisibiliteAnneeMiseServiceAux(paramNeuf,paramAnnee);
    
}

function modifieVisibiliteAnneeMiseServiceAux(paramNeuf,paramAnnee) {
    
    var size = paramNeuf.length;
    
    for (var index = 0;index < size;index++){
       var choix = paramNeuf[index];
       if(choix.checked) {
    	   if((choix.value == "false")){
    		   paramAnnee.disabled = false;
    	   } else {
    		   paramAnnee.value = "";
    		   paramAnnee.disabled = true;
    	   }
       } else {
    	   //choix.nextSibling.removeClassName('checked');
    	   jQuery(choix).nextAll('.xh-checkbox').removeClass('checked');
       }
    }
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_MON_DES002.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

function afficheOuCacheLoyerMontage(){
  if (document.clientMontageForm.codeFondsDeCommerce != null){
     var fondsCommerce = document.clientMontageForm.codeFondsDeCommerce.value;
  
     if (fondsCommerce == "LOC"){
        afficheLoyerMontage();
     }else{
        cacheLoyerMontage();
     }
  }
}

function afficheLoyerMontage(){
    if (document.clientMontageForm.loyer != null){
      document.clientMontageForm.loyer.disabled= false;
      document.getElementById("blocLoyerMontage").style.visibility='visible';
      document.clientMontageForm.clientLocataire.value = "true";
      if (trim(document.clientMontageForm.loyer.value) == ""){
       mettreAZero(document.clientMontageForm.loyer);
      }
    }
}


function cacheLoyerMontage(){
    if (document.clientMontageForm.loyer != null){
       document.clientMontageForm.loyer.value= "";
       document.clientMontageForm.loyer.disabled= true;
       document.clientMontageForm.clientLocataire.value = "false"; 
       document.getElementById("blocLoyerMontage").style.visibility='hidden';
    }
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_MON_DES006.jsp-------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
function modifieVisibiliteAnneeMiseServiceMontage(nomParamNeuf,nomParamAnnee){
    
    var paramNeuf = document.materielMontageForm.elements[nomParamNeuf];
    var paramAnnee = document.materielMontageForm.elements[nomParamAnnee];
    
    /*var size = paramNeuf.length;
    
    for (var index = 0;index < size;index++){
       var choix = paramNeuf[index];
       if ((choix.checked) && (choix.value == "false")){
         paramAnnee.disabled = false;
      }
      
      if ((choix.checked) && (choix.value == "true")){
         paramAnnee.value = "";
         paramAnnee.disabled = true;
      }
    }*/

    modifieVisibiliteAnneeMiseServiceAux(paramNeuf,paramAnnee);
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//----------------FRT_CON_REC002.jsp-------------------------------------------
//---------------------------------------------------------------u--------------
//-----------------------------------------------------------------------------

function isIE(){

	var navigator = window.navigator.userAgent.toLowerCase();
	var itsmsie = navigator.indexOf("msie",0) + 1;
	return itsmsie>0;
	
}

function calculerPositionAbsolue(elem){
	var elemParent = elem.offsetParent;
	var posX = elem.offsetLeft;
	var posY = elem.offsetTop;

	while ((null != elemParent) && ('page' != elemParent.id)){
		posX += elemParent.offsetLeft;
		posY += elemParent.offsetTop;
		elemParent = elemParent.offsetParent;
	} 
	var position = {'X'	: posX, 'Y'	: posY};	
	return position;
}

var isActionActive = false;

function afficheActionContrat(elem,urlModifier,urlAnnuler,urlImprimer){
		var position = calculerPositionAbsolue(elem);
		var actions = document.getElementById('actions');
		document.getElementById("lienActionModifierContrat").href=urlModifier;
		document.getElementById("lienActionAnnulationContrat").href=urlAnnuler;
		document.getElementById("lienActionImprimerContrat").href=urlImprimer;
		actions.style.display='block';
		var actionsX =  position['X'] - actions.offsetWidth;
		var actionsY = position['Y'];
		if(isIE()){
				actions.style.left = actionsX;
				actions.style.top = actionsY;
		} else {
			actions.style.left = actionsX +"px";
			actions.style.top = actionsY+"px";		
		}
		
		isActionActive = true;
}

function cacheActionContrat(elem){
	    var evenement = (arguments[0] || window.event); 
	    setIsActionActive(evenement);
		window.setTimeout("hideActions()", 500);

}


function hideActions(event){
		if(!isActionActive){
			var actions = document.getElementById('actions');
			actions.style.display='none';
		}
}

function setIsActionActive(event){
	if(event.type == "mouseover" && !isActionActive){
		isActionActive = true;
	}
	if(event.type == "mouseout" && isActionActive){
		isActionActive = false;
	}
}

//@deprecated utiliser la fonction $ de prototype.js
function identity(element){
	
	if (element != null && typeof element == 'string'){
       element = document.getElementById(element);
   	} 
   	
   	return element;
}

//@deprecated utiliser la fonction Event.observe de prototype.js
function addListener(element, baseName, handler){

	element = identity(element);

	if(element != null && typeof element != "undefined"){

		if(element.addEventListener){
			element.addEventListener(baseName, handler, false);
		}
		else //Cas IE
		if(element.attachEvent){
			element.attachEvent('on'+baseName,handler);
		}	
	}
}//addListener


function setPositionAbsolue(elem, positionX, positionY){

		if(navDectecteur.isIE){
		
				elem.style.left = positionX==null?'':positionX;
				elem.style.top = positionY==null?'':positionY;
		} else {
			elem.style.left = positionX==null?'':positionX +"px";
			elem.style.top = positionY==null?'':positionY+"px";		
		}
}

//Calcul la position absolue a partir d un element de reference
function calculerPositionAbsolueFromRef(elem, elemRefId){

	var elemParent = elem.offsetParent;
	var posX = elem.offsetLeft;
	var posY = elem.offsetTop;

	while (null != elemParent && elemRefId != elemParent.id){
		posX += elemParent.offsetLeft;
		posY += elemParent.offsetTop;
		elemParent = elemParent.offsetParent;
	} 
	
	var position = {'X'	: posX, 'Y'	: posY};	
	return position;
}

var isSelectActif = false;
var nameSelectActif=null;

//Gestion Bug IE des selects
function initSelects(){

	
		var listeSelects = document.getElementsByTagName('select');
		
		//Pour tous les selects de la page
		for (var i=0; i < listeSelects.length; i++) {
	
			var select = listeSelects[i];

			
			if(select.className.match(/IEresizable/) && navDectecteur.isIE){
			
			
				select.onmouseover=function(){
							elargirSelect(this);
				};

				select.onblur=function(){
						var elementSource = this;						
						if(nameSelectActif != null){
							if(isLong(elementSource)){
								retrecirSelect(elementSource);
							}
							isSelectActif=false;
							nameSelectActif=null;	
						}
				};				

				select.onmousedown=function(){elargirSelect(this);isSelectActif=true;};

				addListener(select, 'mouseout', retrecir);
				addListener(select, 'change', retrecir);
	
				// TODO : A VERIFIER
				//var width = $(select).getWidth()
				var width = 150;
				select.minWidth=width;
				
				//Gestion des selects avec des contenus trop petit (en attendant de trouver mieux)
				while(select.options[0].text.length< (select.minWidth/4)){
					select.options[0].text=select.options[0].text+'             ';
				}
	
				//On ajoute un elem qui va prendre la place du select dans le flux html
				var elemHidden = document.createElement('select');
				elemHidden.style.width=width;
				elemHidden.style.display='none';
				elemHidden.style.visibility='hidden';
				select.parentNode.insertBefore(elemHidden,select.nextSibling);

			}
		
		}
		
		function elargirSelect(select){
						
			if(select.name != nameSelectActif){	
				nameSelectActif=select.name;
				reinitSelectsInactifs(select);
				select.style.position='absolute';
				select.style.width = '';
				select.nextSibling.style.display='inline';
				select.style.zIndex=1;
			}

		}
	
	
		function retrecirSelect(select){
				select.style.width = select.nextSibling.style.width;
				select.style.position='static';
				select.nextSibling.style.display='none';
				select.style.zIndex=0;
		}
		
		
		//Gestion Bug IE des selects
		//Reinitialise la taille des selects inactif de la page
		function reinitSelectsInactifs(selectActif){
		
				var listeSelects = document.getElementsByTagName('select');
				var nbSelects = listeSelects.length;
		
				//Pour tous les selects de la page
				for (var i=0; i < nbSelects; i++) {
				
					var select = listeSelects[i];
				
					if(select.className.match(/IEresizable/)){
		
						if(select != selectActif){
							retrecirSelect(select);
						}
					}
				}
		}			
		

		function retrecir(){
			var evenement = (arguments[0] || window.event); 
			if(evenement.type != "mouseout"|| !isSelectActif){
				if(nameSelectActif != null){
					var elementSource = (evenement.srcElement || evenement.target);
					if(isLong(elementSource)){
						retrecirSelect(elementSource);
						isSelectActif=false;
						nameSelectActif=null;	
					}
				}
			}
		}


		function isLong(select) {
			var islong =  (select.style.width=='');
			return islong;
		}

}

/*********************************************************************/
// LBP2-1 - Saisie du taux compos� p�riodique dans la simulation forc�e

function initMethodeSaisieTauxGlobal(methodeSaisieTauxGlobal,methodeSaisieTauxRefinancement) {
	//if((document.simulationFormEtapeSimu != undefined && document.simulationFormEtapeSimu.tauxRefinancement.value != null && document.simulationFormEtapeSimu.tauxRefinancement.value != "")
	//		|| (document.ratificationAvanceeForm != undefined && document.ratificationAvanceeForm.tauxRefinancement.value != null && document.ratificationAvanceeForm.tauxRefinancement.value != "")) {
	/*if(jQuery('input[name=tauxRefinancement]').attr('value') != "") {
		jQuery('#choixMethodeCalculTauxGlobal').attr('value',methodeSaisieTauxRefinancement);
	} else {
		jQuery('#choixMethodeCalculTauxGlobal').attr('value',methodeSaisieTauxGlobal);
	}*/
	
}

function modifierMethodeSaisieTauxGlobal(methodeSaisieTauxGlobal,methodeSaisieTauxRefinancement) {
	var methodeSaisie = jQuery('#choixMethodeCalculTauxGlobal').attr('value');
	
	if(methodeSaisie == methodeSaisieTauxGlobal) {
	
		var isNullTauxGlobalCalcule = jQuery('#affichageTauxGlobalCalcule').html() == null
										|| jQuery('#affichageTauxGlobalCalcule').html() == "";
	
		jQuery('#saisietauxrefi').css('display','none');
		jQuery('#trTauxDeMarge').css('display','none');
		jQuery('#trTauxGlobal').css('display','none');
		jQuery('#saisietauxrefi').attr('value','');
		jQuery('#saisietauxdemarge').attr('value','');
		//Affiche le champ de saisie du taux global si la case "Calcul du taux' n'est pas coch�e
		if(!jQuery('input:checkbox[name=methodecalcultaux]:checked').val()) {
			jQuery('#saisietaux').css('display','block');
		}
		
	} else {
		//Affiche les champ de saisie du taux compos�
		jQuery('#saisietauxrefi').css('display','inline');
		jQuery('#trTauxDeMarge').css('display','block');
		jQuery('#trTauxGlobal').css('display','block');
		jQuery('#saisietaux').css('display','none');
		
		calculTauxGlobal();
		modifierPeriodiciteTaux();
	}
	
}

function calculTauxGlobal() {

	var tauxRefi = jQuery('#saisietauxrefi').attr('value');
	var tauxMarge = jQuery('#saisietauxdemarge').attr('value');		
	var tauxCalcule;
	if(tauxRefi == null || tauxMarge == null || tauxRefi == "" || tauxMarge == "" || isNaN(tauxRefi) || isNaN(tauxMarge)) {
		tauxCalcule = "";
	} else {
		var tauxCalcule = parseFloat(Number(parseFloat(tauxRefi) + parseFloat(tauxMarge)).toFixed(6));
		if(tauxCalcule == null ) {
			tauxCalcule = "";
		}
	}
	/*
	if(document.simulationFormEtapeSimu != undefined) {
		//Cas d'une simulation
		document.simulationFormEtapeSimu.taux.value = tauxCalcule;
	} else if(document.simulationPalierForm !=undefined){
		document.simulationPalierForm.taux.value = tauxCalcule;
	}	else if(document.ratificationPalierForm !=undefined){
		document.ratificationPalierForm.taux.value = tauxCalcule;
	}else{
		//Cas d'une ratification
		document.ratificationAvanceeForm.taux.value = tauxCalcule;
	}
	*/
	jQuery('#saisietaux').attr('value', tauxCalcule);
	jQuery('#affichageTauxGlobalCalcule').html(tauxCalcule);
}

function modifierPeriodiciteTaux() {
	var libelle = jQuery('#choixPeriodiciteTaux option:selected').text();
	jQuery('#spanPeriodiciteTauxGlobal').html(libelle);
	jQuery('#spanPeriodiciteTauxMarge').html(libelle);
}

/*********************************************************************/

/***************** OR - WATCH LIST ***********************************/
function changeTypeRIB(type) {
	jQuery("select[name=typeRIB] option").each(function(i, v) {
		if(type==v.value) {
			jQuery('#saisie'+v.value).show();
		} else {
			jQuery('#saisie'+v.value).hide();
		}
	});
}

function changerFocusIban(elt) {
	var eltC = jQuery(elt);
	
	var eltCname = eltC.attr('name');
	var numC = parseInt(eltCname.substr(-1,1));
	var nomC = eltCname.substr(0,eltCname.length-1);
	var eltCvalue = eltC.val();
	var nbCar = eltCvalue.length;
	var eltDname;

	if(nbCar==4) {
		eltDname = nomC + (numC+1);
		jQuery("input[name="+eltDname+"]").focus();
	} else if(nbCar==0 && event.keyCode==CODE_KEY_BACKSPACE) {
		eltDname = nomC + (numC-1);
		jQuery("input[name="+eltDname+"]").focus();
	}
}

function adapterFormatIban() {
	
	var nom = "iban";
	var num = 1;
	var elt = jQuery("input[name="+nom+num+"]");
	var eltValue = elt.val();

	if(eltValue.substr(0,2).toUpperCase()=="FR") {
		jQuery("input[name="+nom+"7]").attr("maxlength",3);
		jQuery("input[name="+nom+"8]").hide();
		jQuery("input[name="+nom+"9]").hide();
	} else {
		jQuery("input[name="+nom+"7]").attr("maxlength",4);
		jQuery("input[name="+nom+"8]").show();
		jQuery("input[name="+nom+"9]").show();
	}

}
/*********************************************************************/
