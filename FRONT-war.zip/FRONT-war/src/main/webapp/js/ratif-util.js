

/** Gestion de l'affichage ou non des loyers **/
function cacher(elem) {
  elem.style.display = 'none';
}
function afficher(elem) {
  elem.style.display = '';
}
