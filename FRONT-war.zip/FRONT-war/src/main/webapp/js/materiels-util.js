
	var MaterielsCollection = Class.create({

	   initialize: function() {
	   },

	   initMateriels: function() {
	   
		    //Initialisation de la collection des materiels
			this.materiels = $$('div.materiel');

		   	var partition = this.materiels.partition(function(elem) {
		   						return (elem.style.display=='none')});
		   	
		   	this.materielsVisibles = partition[1];
		   	this.materielsInvisibles = partition[0];
		   	
		   	
		  	//Initialisation des boutons et champs de formulaire
		   	initDeleteButtons();
			initAddButtons();
			
			//Initialisation des index des mat�riels
			calculIndexMateriels();
	
			//Initialisation de la zone apercu de texte
		   	this.textArea = $('textMateriels');
		   	if(this.textArea != null){
			  	initFields();
			   	this.textArea.positionYMin = Position.page(this.textArea)['top']; 
			   	this.textArea.initialOffsetY = Position.realOffset(this.textArea)['top'];
	 			//initTextMaterielsArea();
	 			buildTextMateriels();
	 			
	 		}
		   	


	   },

	   setMaxCaracteres: function(nbcaract) {
	   	this.maxCaracteres = nbcaract;
	   },	

	   isMaterielPrincipal:function(materiel) {
	   		return materiel == this.materielsVisibles[0];
	   },
	   
	   firstMateriel:function() {
	   		return this.materielsVisibles.first();
	   },
	   
	   lastMateriel:function() {
	   		return this.materielsVisibles.last();
	   },
	   
	   isFull:function() {
	   	return (this.materielsVisibles.length==this.materiels.length);
	   },
	   
	   
	   previousMateriel:function(materiel) {
	   	var index = this.materielsVisibles.indexOf(materiel);
	   	var previousMat = null;
	   	if(index != 0){
	   		previousMat = this.materielsVisibles[index-1];
	   	}
	   	return previousMat;
	   },
	   
	   nextMateriel:function(materiel) {
	   	var index = this.materielsVisibles.indexOf(materiel);
	   	var nextMat = null;
	   	if(index != (this.materielsVisibles.length-1)){
	   		nextMat = this.materielsVisibles[index+1]
	   	}
	   	return nextMat;
	   },	   
	   
	   addMateriel: function() {
	   		var materiel = null;
	   		if(this.materielsInvisibles.length > 0){
		   		materiel = this.materielsInvisibles[0];
		    	new Insertion.After(this.materielsVisibles[this.materielsVisibles.length-1], materiel); 
		   		materiel.show();
		   		this.materielsInvisibles = this.materielsInvisibles.reject(function(elem) { return elem==materiel});
				this.materielsVisibles.push(materiel);
		   		calculIndexMateriels();
		   		jQuery(materiel).find('.field')[0].activate();
			}
			return materiel;
	   },
	   
	   deleteMateriel: function(materiel) {
	    	materiel.hide();
 			reinitFields(materiel); 
			this.materielsVisibles = this.materielsVisibles.reject(function(elem) { return elem==materiel});
			this.materielsInvisibles.push(materiel);
	   		calculIndexMateriels();
	   }
	   
	});

var materielsCollection = new MaterielsCollection();

function calculIndexMateriels() {
    for(var i = 0; i <  materielsCollection.materielsVisibles.length; i++){
    	var mat = jQuery(materielsCollection.materielsVisibles[i]).find('.index')[0];
	    mat.value=i+1;
	 }	 
    
   for(var j = 0; j <  materielsCollection.materielsInvisibles.length; j++){
	   var mat = jQuery(materielsCollection.materielsInvisibles[j]).find('.index')[0];
	   mat.value=j+materielsCollection.materielsVisibles.length+1;
   }	 
    
}



 function reinitEtatAndAnnee(materiel){
  	var etat = jQuery(materiel).find('.etat');
 	var annee = jQuery(materiel).find('.annee')[0];
 	//if(etat != null && etat != undefined && etat.length>0) {
	 	etat[0].value='true';
	 	etat[0].checked=true;
	 	etat[1].value='false';
	 	etat[1].checked=false;
 	//}
 	//if(annee != null && annee != undefined) {
 		annee.disable();
 	//}
 }//fin reinitEtatAndAnnee

 function reinitFournisseur(materiel){
  	var fournisseur = jQuery(materiel).find('.fournisseur')[0];
 	if(fournisseur){
		fournisseur.options.selectedIndex=0;
 	}
 }//fin reinitFournisseur
 
 function reinitCatalogue(materiel){
	  	var codeCat = jQuery(materiel).find('.codeCat')[0];
	 	if(codeCat){
	 		codeCat.options.selectedIndex=0;
	 	}
	 }//fin reinitCatalogue

 function reinitMateriel(materiel){
	  	var codeMat = jQuery(materiel).find('.codeMat')[0];
	 	if(codeMat){
	 		codeMat.options.selectedIndex=0;
	 	}
	 	
	 }//fin reinitCatalogue

 function reinitNombreMateriel(materiel){
	  	var nbMat = jQuery(materiel).find('.nombreMateriel')[0];
	 	if(nbMat){
	 		nbMat.value="";
	 	}
	 	
	 }//fin reinitNombreMateriel

 function reinitFields(materiel){
	var fields = jQuery(materiel).find('.field');
 	for(var i=0; i<fields.length;i++){
 		var field = fields[i];
 		field.clear();
 	}
 	
 	reinitEtatAndAnnee(materiel);
 	reinitFournisseur(materiel);
 	reinitCatalogue(materiel);
 	reinitMateriel(materiel);
 	reinitNombreMateriel(materiel);
	
 }// fin reinitFields
 
 function showAddAction(materiel){
   	var actionAdd = jQuery(materiel).find('.add');
 	var actionDel = jQuery(materiel).find('.del');
 	
 	actionAdd.css('display','inline');
 	actionDel.hide();
 	
 }
 
 function showDelAction(materiel){
   	var actionAdd = jQuery(materiel).find('.add');
 	var actionDel = jQuery(materiel).find('.del');
 	
 	actionAdd.hide();
 	
 	actionDel.css('display','inline');
 }
 
  function showAddAndDelAction(materiel){
  var actionAdd = jQuery(materiel).find('.add');
 	var actionDel = jQuery(materiel).find('.del');
 	
 	actionAdd.css('display','inline');
 	actionDel.css('display','inline');
 	
 }
 
   function hideAddAndDelAction(materiel){
   	var actionAdd = jQuery(materiel).find('.add');
 	var actionDel = jQuery(materiel).find('.del');
 	
 	actionAdd.hide();
 	actionDel.hide();
 	
 }
 
 function addMateriel(event){
 	event.stop();
 	var currentMat = Event.findElement(event, 'div');
 	currentMat = jQuery(currentMat).parent().parent()[0];
 	var newMat = materielsCollection.addMateriel();
 	if(!materielsCollection.isFull()){
 		showAddAndDelAction(newMat);
 	} else {
 		showDelAction(newMat);
 	}
 	//Modification de l'action du materiel courant ajouter--->supprimer
 	if(materielsCollection.isMaterielPrincipal(currentMat)){
 		hideAddAndDelAction(currentMat);
 	} else {
 		showDelAction(currentMat);
 	}
 	
 }//fin addMateriel

 function delMateriel(event){
 	event.stop();
 	var currentMat = Event.findElement(event, 'div');
	currentMat = jQuery(currentMat).parent().parent()[0];
 	if(currentMat == materielsCollection.lastMateriel()){
 		var previousMat = materielsCollection.previousMateriel(currentMat);
 		if(previousMat == materielsCollection.firstMateriel()){
			showAddAction(previousMat);
 		} else {
 			 //Modification de l'action du materiel precedent supprimer--->supprimer/ajouter
	 		showAddAndDelAction(previousMat);
 		}
 	} else {
 	 	//Modification de l'action du dernier materiel
	 	showAddAndDelAction(materielsCollection.lastMateriel());
 	}
 	
 	materielsCollection.deleteMateriel(currentMat);
 	if(materielsCollection.textArea){
 		buildTextMateriels();
 		moveTextArea();
 	}

 }//fin delMateriel


 function initAddButtons(){ 	
	 jQuery('.add').each(function(i){
	 Event.observe($(this),'click', addMateriel);
	 
	    });
}//fin initAddButtons
 
function initDeleteButtons(){	
	jQuery('.del').each(function(i){
		Event.observe($(this),'click', delMateriel);
	});
}
//fin initDeleteButtons
 
 function initFields(){
  	var fields = jQuery(document).find('.field');
 	for(var i=0; i<fields.length; i++){
 		var field = fields[i];
 		if(field.hasClassName('etat')){
 			Event.observe(field,'click', buildTextMateriels);
 		} else {
 			Event.observe(field,'keyup', buildTextMateriels);
 		}
 	}
 }//fin initFields
 

 
 function getText(_text) {
 		var text = _text;
 		if(text!=''){
 			text = text.concat(' ');
 		}
 
 	return text;
 }



 
 function buildTextMateriels(){
 
 	//Affichage du materiel principal	
 	var text = buildTextMateriel(materielsCollection.materielsVisibles[0]);
 	
 	var nbMateriels = materielsCollection.materielsVisibles.length;
 	for(var i=1;i < nbMateriels; i++){
 		var materiel = materielsCollection.materielsVisibles[i];
 		
 		var textMateriel = buildTextMateriel(materiel);
 		text= text.concat(textMateriel==''?'':' ; '.concat(textMateriel));
 	}
 	
 	text = text.concat(' ; ');
 	
 	var maxCaracteres = materielsCollection.maxCaracteres;
 	var nbCaracteres = text.length;
 	var counter = ''.concat(nbCaracteres).concat('/').concat(maxCaracteres);
 	
 	if(nbCaracteres>maxCaracteres){
 		materielsCollection.textArea.addClassName('warning');
 	} else {
 		materielsCollection.textArea.removeClassName('warning');
 	}
 	
 	//Update des zones
 	jQuery(materielsCollection.textArea).find('.zoneTextMateriels')[0].update(text);
 	jQuery(materielsCollection.textArea).find('.zoneCounter')[0].update(counter);
 	//$('textMaterielsHidden').update(materielsCollection.textArea.innerHTML);
 }
 
 
 
 function moveTextArea(){
  
	var offsetY = Position.realOffset(materielsCollection.textArea)['top'];
	var moveY = offsetY - materielsCollection.textArea.initialOffsetY;
  	
  	if(moveY >  materielsCollection.textArea.positionYMin){
  	setPositionAbsolue(materielsCollection.textArea,null, Math.max(moveY, materielsCollection.textArea.positionYMin));

 	} else if(Position.positionedOffset(materielsCollection.textArea) > materielsCollection.textArea.positionYMin) {
 		setPositionAbsolue(materielsCollection.textArea,null, materielsCollection.textArea.positionYMin);
 	}
 
 }
 
 function initTextMaterielsArea(){
 		var textMaterielsArea = materielsCollection.textArea;
 		if( textMaterielsArea != null){
	 		Event.observe(window,'scroll', moveTextArea );
 		}
 }
 