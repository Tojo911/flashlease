// JavaScript Document
// Site : FRANFINANCE 
// Date : 24/08/2006 
// Objet : Script g�n�ral du site FranFinance
// Commentaires : Ce script g�re pour le moment l'impression des pages gr�ce aux �l�ments dont l'id est print et le menu du site (en cours).


// === IMPRESSION ===

function imprimer() { window.print(); } //imprimes la fen�tre


// === MENU	===

// A changer en cas de mofication d'arborescence.
var chemin = "/images/menu/";

// Ne pas modifier cette variables
if(typeof rubriques != "undefined")
   var nbmenu = rubriques.length;

// FONCTIONS

function hideAllMenu()
{
	for(i=0;i<nbmenu;i++)
	{
		document.getElementById(rubriques[i][3]).style['display']="none";
	}
}

function showMenu(rub)
{
	document.getElementById(rub).style['display']="block";
	if(rub != rub_courante)
	{
		source = document.getElementById("t_"+rub).getElementsByTagName('img')[0].src;
		document.getElementById("t_"+rub).getElementsByTagName('img')[0].src = document.getElementById("t_"+rub).getElementsByTagName('img')[0].src.split(".png")[0].replace(/alt_/,"")+"_on.png";
		if(rub != rubriques[0][3])
		{
			document.getElementById("t_"+rub).style.marginLeft = "-1px";
		}
	}	
}

function reinitMenuActions()
{
	if(rub_courante != "")
	{
		hideAllMenu();
		showMenu(rub_courante);
	}else{
		hideAllMenu();
	}
}
/* -- Functions non utilis�es -- 
function reinitMenu()
{
	setTimeout("reinitMenuActions()",2000);
}
*/
function rollout(rub)
{
	document.getElementById("t_"+rub).getElementsByTagName('img')[0].src = source;
	document.getElementById("t_"+rub).style.marginLeft = "0px";
}

function ecritMenu(contextRoot)
{
    
	// Ecriture du menu
	str = '<div id="cache" onmouseover="reinitMenuActions()"></div> \n';
	str += '<div id="cache2" onmouseover="reinitMenuActions()"></div> \n';
	str += '<dl id="menu"> \n';
	for (i=0;i<nbmenu;i++)
	{
		if(rubriques[i][3] != rub_courante)
		{
			if(i != nbmenu-1){
				str += '<dt id="t_'+rubriques[i][3]+'"><a href="#" onmouseover="hideAllMenu();showMenu(\''+rubriques[i][3]+'\');" onmouseout="rollout(\''+rubriques[i][3]+'\')"><img src="'+niveau+chemin+rubriques[i][2]+'.png" alt="'+rubriques[i][0]+'" border="0" /></a></dt> \n';
			}else{
				str += '<dt id="t_'+rubriques[i][3]+'"><a href="#" onmouseover="hideAllMenu();showMenu(\''+rubriques[i][3]+'\');" onmouseout="rollout(\''+rubriques[i][3]+'\')"><img src="'+niveau+chemin+'alt_'+rubriques[i][2]+'.png" alt="'+rubriques[i][0]+'" border="0" /></a></dt> \n';
			}
		}else{
			str += '<dt style="margin-top:0px;margin-left:-1px;" id="t_'+rubriques[i][3]+'"><a href="#" onmouseover="hideAllMenu();showMenu(\''+rubriques[i][3]+'\');"><img src="'+niveau+chemin+rubriques[i][2]+'_on.png" alt="'+rubriques[i][0]+'" border="0" /></a></dt> \n';
		}
		if (rub_courante == rubriques[i][3])
		{
			str += '	<dd id="'+rubriques[i][3]+'" style="display:block;"> \n';
		}else{
			str += '	<dd id="'+rubriques[i][3]+'" style="display:none;"> \n';
		}
		str += '		<ul> \n';
		var tab_srub = eval('ss_rubriques_m'+(i+1));
		for (j=0;j<tab_srub.length;j++)
		{
			if(j<tab_srub.length-1)
			{
				str += '			<li><a href="'+niveau+tab_srub[j][1]+'">'+tab_srub[j][0]+'</a></li> \n';
			}else{
				str += '			<li><a href="'+niveau+tab_srub[j][1]+'" class="last">'+tab_srub[j][0]+'</a></li> \n';
			}
		}
		str += '		</ul> \n';
		str += '	</dd> \n';
	}
	
	if (haspor)
	{
		str += '<dt style="margin-top:12px;float:right;">';
		str += '<form name="criteresDOSForm" method="post" action="'+contextRoot+'/por_rec/PreparationRechercheCompletudeDOSAction.do">';
		str += '<ul>';
		str += '<li><span class="label">N�&nbsp;FlashLease&nbsp;</span></li>';
		str += '<li><input type="text" name="critereRechercheRapide" maxlength="10" size="10"></li>';
		str += '<li><input type="image" src="'+contextRoot+'/img/plie.gif" alt="" title="" /></li>';
		str += '</ul>';
	
		str += '</form> \n';
		str += '</dt>';
	}

	str += '</dl> \n';
	document.write(str);
	// alert(str);
}

function ecritBarreAvancement() 
{
  
    if(navigation_niveau != "" && navigation_niveau == 2)
	{
	    barre = '<div id="path">';
	    barre += '<a href="'+accueil[1]+'" accesskey="s">'+accueil[0]+'</a>';
		for (i=0;i<nbmenu;i++)
		 {
		   if(rubriques[i][3] == rub_courante)		   
		    {	 
			  barre += '<a href="#">'+rubriques[i][0]+'</a>';
			  var tab_srub = eval('ss_rubriques_m'+(i+1));
			  for (j=0;j<tab_srub.length;j++) {			   
			     if(tab_srub[j][2] == ss_rub_courante) {        		   
			       barre +='<a href="'+niveau+tab_srub[j][1]+'">'+tab_srub[j][0]+'</a>'
			     }
			  }
			  
			}
		 }		
		//barre += '&nbsp;'+ss_rub_courante_label;
		barre += '</div>';
		//alert(barre);
		document.write(barre);
	}  
    
}

function sidebar(contextRoot)
{    
	// Generation du sidebar (menu)		
	str = "<!--[ SIDEBAR ]-->\n"
		+ "<div class=\"sidebar\">\n"
		+ "		<div class=\"primary-closed\">\n"
		+ "		<p>\n"
		+ "			<span class=\"semio\">Acc�der au menu</span>\n"
		+ "		</p>\n"
		+ "</div>\n"
		+ "<div class=\"primary-opened\">\n"
		
		+ "<ul>\n";
	for (i=0; i<nbmenu; i++)
	{
		str += "<li>\n"
			+ "		<span>" + rubriques[i][0] + "</span>\n";
			
		var tab_srub = eval('ss_rubriques_m'+(i+1));
		if(tab_srub.length > 0)
		{
			str += "<ul>\n";
			for (j=0;j<tab_srub.length;j++)
			{
				str += "<li>\n"
					+ "		<a href=\"" + niveau + tab_srub[j][1] + "\">" + tab_srub[j][0] + "</a>\n"
					+ "</li>\n";
			}
			str += "</ul>\n";
		}							
		str += "</li>\n";			
	}		
	str += "</ul>\n";
		
	if (haspor)
	{
		str += '<dt style="margin-top:12px;float:right;">';
		str += '<form name="criteresDOSForm" method="post" action="'+contextRoot+'/por_rec/PreparationRechercheCompletudeDOSAction.do">';
		str += '<ul>';
		str += '<li><span class="label">N�&nbsp;FlashLease&nbsp;</span></li>';
		str += '<li><input type="text" name="critereRechercheRapide" maxlength="10" size="10"></li>';
		str += '<li><input type="image" src="/acq_web_front/images/plie.gif" alt="" title="" /></li>';
		str += '</ul>';
	
		str += '</form> \n';
		str += '</dt>';
	}
		
	document.write(str);
	alert(str);
}

