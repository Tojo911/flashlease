function ChampFraisMontageJs(_url,_libelle){
      this.libelle = _libelle;
      this.url = _url;
   }
function cacheLiensFraisMontage(){
	 var evenement = (arguments[0] || window.event);
	 setIsActionActive(evenement);
	 window.setTimeout("hideActionsFraisMontage()", 500);
}

function hideActionsFraisMontage(){
	if(!isActionActive){
     var actionsCalcul = document.getElementById('actionsFraisMontage');
     actionsCalcul.style.display='none';
   }
}

 function afficheLiensFraisMontage(elem,listChampMontageJs,action){

	    
	  var position = calculerPositionAbsolue(elem);
	
	  
	  var actionsFraisMontage = document.getElementById('actionsFraisMontage');
	   var oUlElement = document.createElement("ul");
	   
	  for(indxPal = 0; indxPal < listChampMontageJs.length;indxPal++) {	
	    var elementChampFraisMontageJs = listChampMontageJs[indxPal];
	    
	    
	    var oLiElement = document.createElement("li");
	    var oAElement = document.createElement("a");
	    var aActionLabel = elementChampFraisMontageJs.libelle;
	    addListener(oAElement,'click',function(){clickLienFraisMontage(action);});
	    oAElement.href = '#';		 
	    remplacerTexte(oAElement, aActionLabel)	 
	    oUlElement.appendChild(oLiElement);
	    oLiElement.appendChild(oAElement);		
 	  }
	  if(actionsFraisMontage.hasChildNodes()) {	
		  actionsFraisMontage.replaceChild(oUlElement,actionsFraisMontage
				  .firstChild);

	  } else {
		  actionsFraisMontage.appendChild(oUlElement);
		  
	  }  
	  positionne('actionsFraisMontage',position['X'],position['Y']);
	  actionsFraisMontage.style.display='block';
	  isActionActive = true;
}

/*function clickLienFraisMontage(){

	forceFraisMontageCheckbox = jQuery('#forceFraisMontage');
	forceFraisMontageField = jQuery('input[name="forceFraisMontage"]');
	
	fieldEditable = jQuery('input[name="fraisDeMontage"]');
	fieldNotEditable = jQuery('input[name="fraisDeMontageCalcule"]');

	montantSaisi = jQuery('input[name="montantSaisi"]');

	if(forceFraisMontageCheckbox.attr('checked') == 'checked') {
		fieldEditable.show();
		fieldNotEditable.hide();
		fieldEditable.focus();
		changeFraisMontage();
		forceFraisMontageField.val(true);
	} else {
		fieldEditable.hide();
		fieldNotEditable.show();
		montantSaisi.focus();
		forceFraisMontageField.val(false);
	}
}
*/

function clickLienFraisMontage(action){
     if (jQuery('#forceFraisMontage').attr('checked')){
   	
     	jQuery('#fraisDeMontage').show();
     	jQuery('#fraisDeMontageCalcule').hide();
     	
     	jQuery('input[name=forceFraisMontage]').attr('value', 'true');
     	jQuery('input[name=fraisDeMontage]').focus();
     } else {

      	jQuery('#fraisDeMontage').hide();
     	jQuery('#fraisDeMontageCalcule').show();
    	 
       jQuery('input[name=forceFraisMontage]').attr('value', 'false');
	   jQuery('input[name=montantSaisi]').focus();
       changeFraisMontage();
        }
}

 
function changeFraisMontage(){
	var fraisDeMontage = jQuery('input[name="fraisDeMontage"]');
	var fraisDeMontageCalcule = jQuery('input[name="fraisDeMontageCalcule"]');

	if (!jQuery('#forceFraisMontage').attr('checked')) {
		var formatMontantSaisi = /^\d\d?\d?\d?\d?\d?\d?((((\.|\,)\d)?)|(((\.|\,)\d\d)?))$/;

		// pointeurs pour jQuery
		montantSaisi = jQuery('input[name="montantSaisi"]');


		minFraisMontage = jQuery('input[name="minFraisMontage"]');
		maxFraisMontage = jQuery('input[name="maxFraisMontage"]');

		prcFraisMontage = jQuery('input[name="prcFraisMontage"]');

		var mntSaisi = montantSaisi.val();
		if (!formatMontantSaisi.test(mntSaisi)){
			//alert("Valeur incorrecte du montant.");
			montantSaisi.val(0) ;
			montantSaisi.focus();

			return false;
		}

		var mntSaisi = parseFloat(montantSaisi.attr('value'));
		if (isNaN(mntSaisi)){
			alert("Montant invalide");
			return;
		}

		var mntFrais = montantSaisi.attr('value') * prcFraisMontage.val() / 100;
		if (mntFrais < minFraisMontage.val()) {
			mntFrais = minFraisMontage.val();
		} else if (mntFrais > maxFraisMontage.val()) {
			mntFrais = mntFrais = maxFraisMontage.val();
		} 
		fraisDeMontage.val(mntFrais);
		fraisDeMontageCalcule.val(mntFrais);
	} else {
		fraisDeMontage.val(fraisDeMontageCalcule.val());
	}
} 