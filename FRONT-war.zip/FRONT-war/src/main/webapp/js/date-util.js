/**==============================================**/
/**==============================================**/
/** Patern 1 : JJ/MM/SSYY , JJ.MM.SSYY, JJMMSSYY **/
/** Patern 2 : JJ/MM/YY , JJ.MM.YY, JJMMYY       **/
/** Patern 3 : J/M/SSYY , J.M.SSYY, JMSSYY       **/
/** Patern 4 : J/M/YY , J.M.YY, JMYY             **/
/**==============================================**/
/**==============================================**/
String.prototype.trim = function () {
   var reExtraSpace = /^\s+(.*?)\s+$/;
   return this.replace(reExtraSpace, "$1");
}

CheckDate = {
  JJ_MM_SSYY : /(?:0[1-9]|[12][0-9]|3[01])(?:0[1-9]|1[0-2])(?:(19|20)\d{2}$)/,
  JJ_MM_YY   : /(?:0[1-9]|[12][0-9]|3[01])(?:0[1-9]|1[0-2])(?:\d{2}$)/,
  J_M_SSYY   : /(?:[1-9])(?:[1-9])(?:(19|20)\d{2}$)/,
  J_M_YY     : /(?:[1-9])(?:[1-9])(?:\d{2}$)/,
  MM_YYYY    : /(?:0[1-9]|1[0-2])(?:(19|20)\d{2}$)/,
  
  FIRST_LENGTH    : 8,
  SECOND_LENGTH   : 6,  
  TIRD_LENGTH     : 4,
  
  ERROR_MESSAGE   : "Le format de la date est invalide",
  
  
formatDate_JJ_MM_SSYY : function (sDate) {  
      var reSSYY = /(?:19\d{2}$|20\d{2}$)/;
      var reJJ = /(?:0[1-9]|[12][0-9]|3[01])/;
      var arrSSYY = sDate.match(reSSYY);
      sDate = sDate.replace(reSSYY, ""); 
      var arrJJ = sDate.match(reJJ);
      sDate = sDate.replace(reJJ, "");
      return arrJJ[0]+"/"+sDate+"/"+arrSSYY[0];
},

formatDate_J_M_SSYY : function (sDate) {  
      var reSSYY = /(?:19\d{2}$|20\d{2}$)/;
      var reJ = /(?:[0-9])/;
      var arrSSYY = sDate.match(reSSYY);
      sDate = sDate.replace(reSSYY, ""); 
      var arrJ = sDate.match(reJ);
      sDate = sDate.replace(reJ, "");
      return "0"+arrJ[0]+"/0"+sDate+"/"+arrSSYY[0];
},

formatDate_JJ_MM_YY : function (sDate) {  
      var reYY = /(?:\d{2}$)/;
      var reJJ = /(?:0[1-9]|[12][0-9]|3[01])/;
      var arrYY = sDate.match(reYY);
      sDate = sDate.replace(reYY, ""); 
      var arrJJ = sDate.match(reJJ);
      sDate = sDate.replace(reJJ, "");
      return arrJJ[0]+"/"+sDate+"/20"+arrYY[0];
},

formatDate_J_M_YY : function (sDate) {  
      var reYY = /(?:\d{2}$)/;
      var reJ = /(?:[1-9])/;
      var arrYY = sDate.match(reYY);
      sDate = sDate.replace(reYY, ""); 
      var arrJ = sDate.match(reJ);
      sDate = sDate.replace(reJ, "");
      return "0"+arrJ[0]+"/0"+sDate+"/20"+arrYY[0];
},


formatDate_MM_YYYY : function (sDate) {
    
      var reSSYY = /(?:19\d{2}$|20\d{2}$)/;
      var reMM = /(?:0[1-9]|1[0-2])/;
      var arrSSYY = sDate.match(reSSYY);
      sDate = sDate.replace(reSSYY, ""); 
      var arrMM = sDate.match(reMM);
      sDate = sDate.replace(reMM, ""); 
      // var arrJJ = sDate.match(reJJ);
      return arrMM[0]+"/"+arrSSYY[0];
},
  
  
  validateDateFunction : function (sDate) {      
      var taille = sDate.replace(/[\/|.]/g,"").length;     
      var sDate_ = sDate.replace(/[\/|.]/g,"");
      switch(taille) {
        case CheckDate.FIRST_LENGTH :
        // traitment;
         if(CheckDate.JJ_MM_SSYY.test(sDate_)){  
            return CheckDate.formatDate_JJ_MM_SSYY(sDate_);
         } else { 
            throw CheckDate.ERROR_MESSAGE;
         }      
        break;
        case CheckDate.SECOND_LENGTH :
       
       if(CheckDate.J_M_SSYY.test(sDate_)){
          return CheckDate.formatDate_J_M_SSYY(sDate_);
       } else if(CheckDate.JJ_MM_YY.test(sDate_)) { 
          return CheckDate.formatDate_JJ_MM_YY(sDate_);
       } else if (CheckDate.MM_YYYY.test(sDate_)) {
       	  return CheckDate.formatDate_MM_YYYY(sDate_);
       } else { 
         throw CheckDate.ERROR_MESSAGE;
       } 
       break;
       case CheckDate.TIRD_LENGTH :
       // traitment;
        if(CheckDate.J_M_YY.test(sDate_)){
           return CheckDate.formatDate_J_M_YY(sDate_);
        } else { 
          throw CheckDate.ERROR_MESSAGE;
        }
       break;
       default :
         throw CheckDate.ERROR_MESSAGE;
       break;
     }
         
  }, 
  
  validateAndTransformeDate : function (oInputText) {
   try {
      if(oInputText.value.trim()) {
       var formattedDate = CheckDate.validateDateFunction(oInputText.value)
       oInputText.value = formattedDate;
      }
     } catch(e) {
       alert(CheckDate.ERROR_MESSAGE);
       
     }
  },
  



  /* 
  	!!!!!!  Feinte in�vitable (2 m�thodes suivantes) : les patterns J/M/YYYY et MM/YYYY ne sont pas dissociables 
  	ie: une saisie 1/1/2008 > 11/2008 si on priorise le second pattern, au lieu de 01/01/2008
  	2/1/2008 au contraire sera bien transform� en 02/01/2008 (car non catch� par second pattern)
  	si l'on priorise le 1er pattern, 95/2009 sera transform� en 9/5/2009 (pour d�terminer le pattern on vire les / et se base sur le nombre de chiffres ...)
  	rem: il aurait fallu utiliser les / pour distinguer correctement les 2 cas litigieux.
  */ 
  validateDateSpecialeFunction : function (sDate) {      
      var taille = sDate.replace(/[\/|.]/g,"").length;     
      var sDate_ = sDate.replace(/[\/|.]/g,"");
      switch(taille) {
        case CheckDate.SECOND_LENGTH :
		if (CheckDate.MM_YYYY.test(sDate_)) {
       	  		return CheckDate.formatDate_MM_YYYY(sDate_);
       		} else { 
         		throw CheckDate.ERROR_MESSAGE;
       		} 
	       break;
       default :
         throw CheckDate.ERROR_MESSAGE;
       break;
     }
         
  },   


  validateAndTransformeDateSpeciale : function (oInputText) {
   try {
	  var value=oInputText.value.trim();
      if(value != null && value != undefined && value != '') {
       var formattedDate = CheckDate.validateDateSpecialeFunction(oInputText.value)
       oInputText.value = formattedDate;
      }
     } catch(e) {
       alert(CheckDate.ERROR_MESSAGE);
       
   }
   
  
  
  }
  
}

 