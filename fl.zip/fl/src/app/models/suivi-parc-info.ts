import Global from './global-functions';

export class SuiviParcInfo {
  id: number;
  client: Map<string, any>;
  statut: Map<string, any>;
  montant: any;
  dateStatut: number;
  dateExpire: number;
  statutCommercial: string;

  constructor(response: any) {
    this.id = response.referenceInterne; // Num affaire => referenceInterne
    this.client = Global.convertToMap(response.client);
    this.statut = Global.convertToMap(response.statut);
    this.montant = response.montantRachat;
    this.statutCommercial = response.statutCommercial;
    this.dateStatut = Global.convertToMap(response.firstElement).get('dateDebutLocation');
    this.dateExpire = Global.convertToMap(response.firstElement).get('dateFinLocation');
  }
}
