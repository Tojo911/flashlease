import { Perimetre } from './perimetre';
import { Timestamp } from 'rxjs/internal/operators/timestamp';
import { ModelOption } from './option-model';
import { HomeTabEnum } from './enums/home-tab.enum';

export class CritereRechercheInfo {
  numeroFL?: number;
  numeroSIREN?: number;
  raisonSociale?: string;
  codeStatut?: string;
  statuts?: string[];
  statutsCommerciaux?: string[];
  vendeurs?: (number | string)[];
  phase?: string;
  debut?: number;
  fin?: number;
  appel?: boolean;
  derogation?: boolean;
  montant?: number;
  codeEkipAgence?: string;
  numeroAccord?: string;
  idVendeur?: number | string;
  idAgence?: number | string;
  idApporteur?: number | string;
  idMarche?: number | string;
  referenceDossierInterne?: string;
  referenceApporteur?: string;
  raisonSocialeClient?: string;
  nombreLoyerRestants?: number;
  agences?: number[];
  dateFinMin?: number;
  dateFinMax?: number;
  perimetres?: Perimetre[];
  dateFinValidite?: number;
  dateRachatMin?: number;
  dateRachatMax?: number;
  numAffaire: string;
  statutRachat: string;
  demandeRachat: string;
  // dateDebutMin: Date;
  // dateDebutMax: Date;
  customFields: any;

  constructor(response?: CriteresModelToMap) {
    this.customFields = response;
    if (response) {
      if (response.numeroFL) {
        this.numeroFL = response.numeroFL;
      }
      if (response.numeroSIREN) {
        this.numeroSIREN = response.numeroSIREN;
      }
      if (response.raisonSociale) {
        this.raisonSociale = response.raisonSociale;
      }
      if (response.raisonSocialeClient) {
        this.raisonSociale = response.raisonSocialeClient;
      }
      if (response.statut) {
        this.codeStatut = response.statut.value;
      }
      if (response.statut) {
        this.statutRachat = response.statut.value;
      }
      if (response.statuts && response.statuts.length > 0) {
        this.statuts = response.statuts.map(it => it.value);
      }
      if (response.statutCommercial) {
        this.statutsCommerciaux = response.statutCommercial.map(it => it.value);
      }
      if (response.phase) {
        this.phase = response.phase;
      }
      if (response.dateCreation) {
        this.debut = response.dateCreation[0]
          ? response.dateCreation[0].getTime()
          : null;
        this.fin = response.dateCreation[1]
          ? response.dateCreation[1].getTime() + 86399 // Conversion jour en milliseconde
          : null;
      }
      if (response.dateRachat) {
        this.dateRachatMin = response.dateRachat[0]
          ? response.dateRachat[0].getTime()
          : null;
        this.dateRachatMax = response.dateRachat[1]
          ? response.dateRachat[1].getTime() + 86399 // Conversion jour en milliseconde
          : null;
      }
      if (response.dateRachat) {
        this.debut = response.dateRachat[0]
          ? response.dateRachat[0].getTime()
          : null;
        this.fin = response.dateRachat[1]
          ? response.dateRachat[1].getTime() + 86399 // Conversion jour en milliseconde
          : null;
      }
      if (response.ekipAgence) {
        this.codeEkipAgence = response.ekipAgence;
      }

      if (response.numAccord) {
        this.numeroAccord = response.numAccord;
      }
      if (response.demandeRachat) {
        this.demandeRachat = response.demandeRachat + '';
      }
      if (response.affaire) {
        this.numAffaire = response.affaire + '';
      }

      if (response.perimetre) {
        if (response.perimetre.vendeur) {
           this.vendeurs = [].concat(response.perimetre.vendeur);
        }
        this.idVendeur = response.perimetre.vendeur;
        this.idAgence = response.perimetre.agence;
        this.idMarche = response.perimetre.marche;
        this.idApporteur = response.perimetre.apporteur;
        this.codeEkipAgence = response.perimetre.agenceDetails
          ? response.perimetre.agenceDetails.identifiantEKIP
          : null;
      }
      if (response.perimetres) {
        this.perimetres = response.perimetres;
      }
      if (response.refDossierInterne) {
        this.referenceDossierInterne = response.refDossierInterne;
      }

      if (response.refApporteur) {
        this.referenceApporteur = response.refApporteur;
      }
      if (response.agences) {
        this.agences = response.agences;
      }
      if (response.nbLoyerRestant) {
        this.nombreLoyerRestants = response.nbLoyerRestant;
      }

      if (response.dateFinContrat) {
        this.dateFinMin = response.dateFinContrat[0].getTime();
        this.dateFinMax = response.dateFinContrat[1].getTime() + 86399;
      }
      if (response.dateFinValidite) {
        this.dateFinValidite = response.dateFinValidite.getTime();
      }
    }
  }

  // setPerimetres(perimetres) {
  //   return perimetres.map(it => {
  //     const perimetre: any = {};
  //     perimetre.marche = it.marche;
  //     perimetre.apporteur = it.apporteur;
  //     perimetre.agence = it.agence;
  //     if (this.phase === HomeTabEnum[0]) {
  //       perimetre.vendeur = it.vendeur;
  //     }
  //     // pers.push( perimetre);
  //     return perimetre;
  //   });
  //   // return
  // }
}

export class CriteresModelToMap {
  numeroFL?: number;
  numeroSIREN?: number;
  raisonSociale?: string;
  montant?: number[];
  statut?: ModelOption;
  statuts?: ModelOption[];
  statutCommercial?: ModelOption[];
  vendeur?: number;
  phase?: string;
  dateCreation?: Date[];
  ekipAgence?: string;
  perimetre?: Perimetre;
  perimetres?: Perimetre[];
  numAccord?: string;
  numDossier?: string;
  refDossierInterne?: string;
  refApporteur?: string;
  raisonSocialeClient?: string;
  nbLoyerRestant?: number;
  agences?: any[];
  dateFinValidite?: Date;
  dateFinContrat?: Date[];
  demandeRachat?: number;
  affaire?: number;
  dateReception: Date[];
  dateRachat: Date[];

  constructor() {}

  // static setPerimetres(perimetres: Perimetre[], phase: string) {
  //   const crit = new CriteresModelToMap();
  //   crit.perimetres = perimetres;
  //   crit.phase = phase;
  //   return crit;
  // }
}
