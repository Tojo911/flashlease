import { VendeurInfos, MarcheInfos, AgenceInfos, ApporteurInfos } from './ddf';

export interface Perimetre {
  id?: string;
  name?: string;
  type?: string;
  children?: Perimetre[];
  marche?: string | number;
  agence?: string | number;
  apporteur?: string | number;
  vendeur?: string | number;
  vendeurDetails?: VendeurInfos;
  marcheDetails?: MarcheInfos;
  agenceDetails?: AgenceInfos;
  apporteurDetails?: ApporteurInfos;
  items?: any[];
  list?: any[];
}
