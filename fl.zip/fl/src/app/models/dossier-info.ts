import { ModelOption } from '../models/option-model';

import { PersonneInfo, VendeurInfo, RachatVo, VendeurVo, AgenceVo, ApporteurVo } from './ddf';
import Global from './global-functions';
export class DossierInfo {
  /* TODO: @anas: we need to rediscuss this and check info with backend data */
  id: number;
  numSiren: number;
  montant: any;
  duree: ModelOption;
  produitFinancier: Map<string, any>;
  dateSaisie: number;
  dateCreation?: number;
  raisonSociale: string;
  statut: Map<string, any>;
  materiel: Map<string, any>;
  blocMateriel: Map<string, any>;
  blocPlanFinancement: Map<string, any>;
  vendeur: VendeurInfo;
  // To be changed with correct attribute
  loyerFinancier: any;
  periodicite: any;
  loyerTotal: any;
  assurance: any;
  calage: any;
  nbJoursCalage: any;
  assurance_personne: any;
  assurance_materiel: any;
  bareme: any;
  fournisseur: any;
  maintenance: any;
  serie: any;
  designation: any;
  statutCommercial: string;
  montantRachat;
  dateStatut: number;
  dateExpire: number;
  dateRachat: string;
  dateFinValidite: number;
  dateValiditeAccord: number;
  topDirigeant?: boolean;
  infosDirigeant?: PersonneInfo;
  dateReception: number;
  pieces: string;
  numeroContrat: string;
  numeroOctroi: string;
  numEkip: number;
  refApporteur: string;
  loyer: number;
  agence: string;
  apporteur: string;
  vendor: string;
  demandeRachat: number;
  numAffaire: string;
  statutRachat: string;
  constructor(response: any) {
    this.topDirigeant = response.topDirigeant;
    this.infosDirigeant = response.infosDirigeant;
    this.montantRachat = response.montantRachat;
    this.dateStatut = Global.gets(response.statut).date;
    if (response.firstElement) {
      this.dateExpire = response.firstElement.dateFinLocation;
    }
    this.dateReception = response.dateReceptionDocumentNonTraite;
    this.id = response.referenceInterne
      ? response.referenceInterne
      : response.numeroFL
      ? response.numeroFL
      : response.idDossier;
    this.numSiren = response.client
      ? response.client.siren
      : response.numeroSIREN
      ? response.numeroSIREN
      : response.siren;
    this.montant = response.montant ? response.montant : response.montantHT;
    if (response.duree) {
      this.duree = response.duree.toString();
    }
    this.produitFinancier = Global.convertToMap(response.produitFinancier);
    this.dateSaisie = response.dateCreation
      ? response.dateCreation
      : response.dateSaisie;
    this.raisonSociale = response.client
      ? response.client.raisonSociale
      : response.raisonSociale
      ? response.raisonSociale
      : response.raisonSocialClient;
    this.statut = Global.convertToMap(response.statut);
    this.pieces = Global.getA(response.pieces).join();
    // remplacement de 'ratification' par 'Accord Détaillé'
    this.numeroContrat = response.numeroContrat;
    this.numeroOctroi = response.numeroOctroi;
    this.materiel = Global.convertToMap(response.materiel);
    this.blocMateriel = Global.convertToMap(response.blocMateriel);
    this.blocPlanFinancement = Global.convertToMap(
      response.blocPlanFinancement
    );
    this.loyer = Global.gets(response.firstElement).nombreLoyersRestants;
    this.numEkip = response.referenceInterne;
    this.refApporteur = Global.gets(response.firstElement).referenceApporteur;
    this.vendeur = response.vendeur ? response.vendeur : null;
    this.vendor =  response.nomVendeur; // Global.convertToMap(response.vendeur);
    this.apporteur = response.nomApporteur;
    // To be changed with correct attribute
   /* this.loyerFinancier = '256';
    this.periodicite = 'Semestrielle';
    this.loyerFinancier = '3256';
    this.assurance = '145';
    this.calage = '';
    this.nbJoursCalage = '';
    this.assurance_personne = '';
    this.assurance_materiel = '';
    this.bareme = '';
    this.fournisseur = 167;
    this.maintenance = '';
    this.serie = '56897425';
    this.designation = 'Designation';*/
    this.dateFinValidite = response.dateFinValidite;
    this.statutCommercial = response.statutCommercial;
  }
  static dossierFromRachatVo(res: RachatVo) {
    const dos = new DossierInfo({});
    res = Global.gets(res);
    const vendeur = Global.gets(res.vendeur) as VendeurVo;
    const agence = Global.gets(vendeur.agence) as AgenceVo;
    const apporteur = Global.gets(agence.apporteur) as ApporteurVo;
    dos.demandeRachat = res.referenceRachat;
    dos.apporteur = apporteur.libelle;
    dos.vendor = vendeur.nom + ' ' + vendeur.prenom;
    dos.raisonSociale = res.raisonSocialeClient;
    dos.numAffaire = Global.gets(res.infoAffaire).numeroAffaire;
    dos.dateRachat = res.dateRachat;
    dos.statutRachat = Global.gets(res.statut).libelle;
    dos.dateReception = Number(res.dateReception);
    return dos;
  }
  public updateMateriel(obj: any) {
    this.materiel = Global.convertToMap(obj);
  }
}
