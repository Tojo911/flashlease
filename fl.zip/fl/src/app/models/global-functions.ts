import { Timestamp } from 'rxjs';
import { Requestable } from './table-column-definition-model';
export default class Global {
  // this Method allow to convert an Object to a Map<key, value> type
  static convertToMap(obj: any): Map<string, any> {
    const map = new Map<string, any>();
    let result = null;

    if (obj) {
      Object.keys(obj).forEach(k => {
        result =
          typeof obj[k] === 'object'
            ? map.set(k, this.convertToMap(obj[k]))
            : map.set(k, obj[k]);
      });
    }
    return result;
  }
  static unsubscriber(obs) {
    if (obs) {
      obs.unsubscribe();
    }
  }
  static gets(obs) {
    if (obs) {
      return obs;
    } else {
      return {};
    }
  }
  static getA(obs) {
    if (obs) {
      return obs;
    } else {
      return [];
    }
  }
  // this genericType-Method allow to convert an Object to a List
  static mapKpiObjToList<T>(obj: any, type: new (...args) => T) {
    const list: T[] = [];

    if (obj) {
      Object.keys(obj).forEach(k => {
        list.push(new type(k, obj[k]));
      });
    }
    return list;
  }
  static mapTimestampToTime(timestamp: number): string {
    if (timestamp) {
      const dateObject = new Date(+timestamp);
      return (
        (dateObject.getHours() < 10
          ? '0' + dateObject.getHours()
          : dateObject.getHours()) +
        ':' +
        (dateObject.getMinutes() < 10
          ? '0' + dateObject.getMinutes()
          : dateObject.getMinutes())
      );
    }
  }
  static mapTimestampToDate(timestamp: number): string {
    if (timestamp) {
      const dateObject = new Date(+timestamp);
      return (
        (dateObject.getDate() < 10
          ? '0' + dateObject.getDate()
          : dateObject.getDate()) +
        '/' +
        (dateObject.getMonth() + 1 < 10
          ? '0' + (dateObject.getMonth() + 1)
          : dateObject.getMonth() + 1) +
        '/' +
        (dateObject.getFullYear() + '').slice(-2)
      );
    }
    return null;
  }
  static generateRandomValue(obj) {
    if (typeof obj === 'string') {
      return this.randomizedString(this.randomNumber(3, 20));
    } else if (typeof obj === 'number') {
      return this.randomNumber(0, 99999999);
    } else if (obj instanceof Date) {
      return this.randomdate(2012, 2030);
    } else if (obj instanceof Date) {
      return this.randomdate(2012, 2030);
    } else if (obj instanceof Array) {
      console.log(obj);
    }
    obj.forEach(field => (field = this.generateRandomValue(field)));
    return obj;
  }

  static randomizedString(size?) {
    return Math.random()
      .toString(36)
      .substring(size ? size : 7);
  }

  static randomNumber(min, max) {
    if (min === max) {
      return min;
    }
    return Math.floor(Math.random() * max) + min;
  }

  static randomdate(minYear, maxYEar) {
    return new Date(
      this.randomNumber(minYear, maxYEar),
      this.randomNumber(0, 11),
      this.randomNumber(1, 31)
    );
  }

  static cleanObjectJson(obj) {
    Object.keys(obj).map((field, index) => {
      if (!obj[field]) {
        delete obj[field];
      }

    });
    return obj;
  }

  static stream(obj, fn) {
    Object.keys(obj).map((key, index) => fn(key, index));
  }

  static isDefaut(f: Requestable) {
    return !f.isMultiSelect && !f.isMonoSelect && !f.isDate && !f.isDateRange && !f.isPerimetre;
  }
}
