import { ModelOption } from './option-model';
export class ContratEdition {
    label?: string;
    placeholder?: string;
    typeform?: string;
    constructor() {
    }
    static build(custom) {
      const toReturn =  {};
      if (custom) {
        Object.keys(custom).map((field, index) => {
          toReturn[field] = custom[field];
        });
      }
      return toReturn;
    }
}
/* le 10/01/2019 khaled */
export class ContratModel {

  /* Stepper 1
  //Model Info client */
  public raisonSocialClient?: string;
  public sirenClient?: number;
  public adresseClient?: string;
  public complementadresseClient?: string;
  public codepostalClient?: number;
  public villeClient?: string;
  /* model info dirigent */
  public civiliteDirigeant?: ModelOption;
  public nomDirigeant?: string;
  public prenomDirigeant?: string;
  public datedenaissanceDirigeant?: number;
  public lieudenaissanceDirigeant?: string;
  public emailDirigeant?: string;
  public telephoneDirigeant?: number;
  /* model info signtaire */
  public civiliteSigntaire?: ModelOption;
  public nomSignataire?: string;
  public prenomSignataire?: string;
  public qualiteSignataire?: string;
  public datedenaissanceSignataire?: number;
  public lieudenaissanceSignataire?: string;
  public emailSignataire?: string;
  public telephoneSignataire?: number;

  /* Stepper 2
  //model Info domiciliation bancaire */
  public iban?: string;
  public nomdelabanque?: string;
  public codeBic?: string;
  public nomdelagence?: string;
  public adresseDomicilebancaire?: string;
  public complementAdresseDomicilebancaire?: string;
  public codepostalDomicilebancaire?: number;
  public villeDomicilebancaire?: string;
  public personneajoindre?: string;
  public telephoneDomicilebancaire?: number;
  /* model Info adresse de facturation */
  public adresseFacturation?: string;
  public complementadresseFacturation ?: string;
  public codepostalFacturation?: number;
  public villeFacturation?: string;

/* Stepper3 */
/* model Info Fournisseur */
  public nomdufornisseur?: string;
  public sirenFournisseur?: number;
  public adresseFournisseur?: string;
  public complementadresseFournisseur?: string;
  public codepostalFournisseur?: number;
  public villeFournisseur?: string;
  /* model Info Materiels */
  public designationdubien?: string;
  public fournisseurdubien?: ModelOption;
  public type?: string;
  public marque?: string;
  public quantite?: number;
  public etat_mat = '1';
  public anneedemiseenservice?: number;
  public numerodeserie?: string;
 /* model info Lieu d'installation */
  public adresseLieuInstallation?: string;
  public complementadresseLieuInstallation?: string;
  public codepostalLieuInstallation?: number;
  public villeLieuInstallation?: string;
  public observationParticuliere?: string;

 /* public civilite?: ModelOption;
  public code_mat?: ModelOption;
  public etat_mat ?= '1';
  public anneeMiseEnService?: number;
  public disigantion?: string;
  public type?: string;
  public marque?: string;
  public commentObservation?: string;
  public numeroSerie?: string;
  public produit?: ModelOption;
  public montantRachat?: string;
  public files?: any;
*/
}
