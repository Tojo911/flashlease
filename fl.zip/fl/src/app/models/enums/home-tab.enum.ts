
export enum HomeTabEnum {
  DDF = 0,
  MONTAGE = 1,
  PARC = 2
}
