import { ModelOption } from './option-model';
import { Perimetre } from './perimetre';

export class RachatDemandeValidation {
    public perimetre?: Perimetre;
    public numeroContrat?: string;
    public echeanceRachat?: number;
    public condition?: ConditionRachatInfo;
    public formule?: ConditionRachatInfo;
    public montant?: string;
    public dateValidite?: number;
    public commentaireInterne?: string;
    public commentaireExterne?: string;
    public renouvelante?: string;

    constructor(input: RachatDemandeModel) {


      if (input.perimetre) {
        this.perimetre = input.perimetre;
        delete this.perimetre.vendeurDetails;
        delete this.perimetre.marcheDetails;
        delete this.perimetre.agenceDetails;
        delete this.perimetre.apporteurDetails;
      }
      if (input.numeroContrat) {
        this.numeroContrat = input.numeroContrat.trim() ;
      }
      if (input.echeanceRachat && input.echeanceRachat > 0) {
        this.echeanceRachat =  input.echeanceRachat; // Number(input.duree.value);
      }
      if (input.formule && input.formule.value) {
        console.log('rachat avancée');
        if (input.condition) {
          this.condition = input.condition.data;
        }
        if (input.formule) {
          this.formule = input.formule.data;
        }
        if (input.montant) {
          this.montant = input.montant;
        }
        if (input.dateValidite && input.dateValidite > 0) {
          this.dateValidite = input.dateValidite;
        }
        if (input.commentaireInterne) {
          this.commentaireInterne = input.commentaireInterne;
        }
        if (input.commentaireExterne) {
          this.commentaireExterne = input.commentaireExterne;
        }
      } else {
        console.log('rachat simple');
        if (input.renouvelante) {
          this.renouvelante = input.renouvelante;
        }
      }
    }
}

export class RachatDemandeModel {
  public perimetre: Perimetre;
  public numeroContrat?: string;
  public echeanceRachat?: number;
  public condition?: RachatModelOption;
  public formule?: RachatModelOption;
  public autreMontant?: string;
  public montant?: string;
  public dateValidite?: number;
  public commentaireInterne?: string;
  public commentaireExterne?: string;
  public renouvelante?: string;
}

export class RachatModelOption {
  public libelle: string;
  public value: string;
  public data: any;

}

export interface ConditionRachatInfo {
  id: number;
  libelle: string;
  conditionRachatType: string;
  }

export interface FormuleInfo {
  id: number;
  libelle: string;
  elementsOptionnelsInfo: ElementsOptionnelsFormuleInfo [];
  commentaireExterne: string;
  typeFormule: string;
  }
export interface ElementsOptionnelsFormuleInfo {
  id: number;
  oid: number;
  libelle: string;
  methode: string;
  valeur: number;
  assiette: string;
  valeurMinimale: number;
  valeurMaximale: number;
  idFormule: number;
  restitutionElement: boolean;
}
