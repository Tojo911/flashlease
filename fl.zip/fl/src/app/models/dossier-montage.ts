import { DossierMontageEntity } from './ddf';
import Global from './global-functions';
export class DossierMontageInfo {
  id: number;
  statut: string;
  numSiren: string;
  raisonSocial: string;
  montant: any;
  dateReception: number;
  pieces: string;

  constructor(response: DossierMontageEntity) {
    this.id = response.idDossier;
    this.statut = Global.gets(response.statut).libelle;
    this.numSiren = response.siren;
    this.raisonSocial = response.raisonSocialClient;
    this.montant = response.montantHT;
    this.dateReception = Global.gets(response.dateReceptionDocumentNonTraite).getTime();
    this.pieces = response.pieces ? response.pieces.join() : '';
  }
}
