export interface TableColumnDefinitionModel {
  columnDef?: string;
  forbiddenScreens?: any;
  header?: string;
  sort?: boolean;
  date?: boolean;
  time?: boolean;
  tooltip?: string;
  cell?: (row: any) => any;
  type?: string;
  isNumeric?: boolean;
  onclick?: (row: any) => {};
  requestable?: Requestable;
  hide?: boolean;
}

export interface Requestable {
  controlName?: string;
  classNames?: string[];
  possibleValues?: string[];
  placeholder?: string;
  modelName?: string;
  isNumeric?: boolean;
  isDateRange?: boolean;
  isDate?: boolean;
  isPerimetre?: boolean;
  isMonoSelect?: boolean;
  isMultiSelect?: boolean;
  isInput?: boolean;
  format?: any;
  maxLength?: any;

}

