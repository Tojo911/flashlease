import { DossierInfo } from './dossier-info';
import { DossierMontageInfo } from './dossier-montage';
import Global from './global-functions';

export class ItemTableInfo {
  numeroFL: number;
  demandeRachat: number;
  numAffaire: string;
  numeroSIREN: number;
  numContrat: string;
  numOctroi: string;
  raisonSociale: string;
  montant: number;
  dateSaisie: string;
  dateExpire: string;
  dateRachat: string;
  dateStatut: string;
  dateReception: number;
  statut: string;
  statutRachat: string;
  statutCommercial: string;
  vendeur: string;
  apporteur: string;
  agence: string;
  dateFinValidite: string;
  dateValiditeAccord: string;
  pieces: string;
  numEkip: number;
  refApporteur: string;
  loyer: number;

  // response may be DossierInfo, DossierMontage or SuiviParc
  constructor(response?: DossierInfo) {
    if (response) {
      this.numContrat = response.numeroContrat;
      this.numOctroi = response.numeroOctroi;
      this.numAffaire = response.numAffaire;
      this.dateRachat = response.dateRachat;
      this.demandeRachat = response.demandeRachat;
      this.numEkip = response.numEkip;
      this.refApporteur = response.refApporteur;
      this.loyer = response.loyer;
      this.numeroFL = response.id;
      this.numeroSIREN = response.numSiren;
      this.raisonSociale = response.raisonSociale;
      this.montant = response.montant
        ? this.getMontantFromResponse(response.montant)
        : response.montantRachat;
      this.dateSaisie = response.dateCreation
        ? <string><any>response.dateCreation
        : <string><any>response.dateSaisie;
      this.dateExpire = <string><any>response.dateExpire;
      this.dateStatut = <string><any>response.dateStatut;
      this.dateValiditeAccord = <string><any>response.dateValiditeAccord;
      if (response.dateFinValidite) {
        this.dateFinValidite = <string><any>response.dateFinValidite;
      }
      this.statut = response.statut ? response.statut.get('libelle') : null;
      this.statutRachat = response.statutRachat;
      this.statutCommercial = response.statutCommercial;
      this.vendeur = response.vendeur ? response.vendeur.nom : response.vendor;
      this.apporteur = response.vendeur
        ? response.vendeur.agence.apporteur.libelle
        : response.apporteur;
      this.agence = response.vendeur
        ? response.vendeur.agence.libelle
        : response.vendor;
    }
  }

  getMontantFromResponse(res) {
    return res ? (typeof res === 'object' ? res.montant : res) : res;
  }
}
