import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from '../services/auth/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../environments/environment';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  model: any = {};
  error = false;
  messageError = '';
  appVersion = environment.version;
  loginForm: FormGroup;
  loginSpinner = false;
  isSubmit = false;
  constructor(
    private authService: AuthService,
    private translateService: TranslateService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  isProd() {
    return environment.env === 'prod';
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.loginForm.valueChanges.subscribe(val => {
      this.error = false;
      this.messageError = '';
    });
    sessionStorage.clear();
  }

  onSubmit() {
    this.loginSpinner = true;
    this.isSubmit = true;
    this.authService.login(this.model.username, this.model.password).subscribe(
      res => {
        this.loginSpinner = false;
        if (res === true) {
          this.router.navigate(['/']);
        }
      },
      (err: HttpErrorResponse) => {
        this.loginSpinner = false;
        this.error = true;
        switch (err.status) {
          case 401: {
            this.messageError = this.translateService.instant(
              'LOGIN.ERRORS.UNAUTHORIZED'
            );
            break;
          }
          case 500: {
            this.messageError = this.translateService.instant(
              'LOGIN.ERRORS.SERVER_ERROR'
            );
            break;
          }
        }
      }
    );
  }

  public validate(field: string, error: string) {
    const control = this.loginForm.get(field);
    return control && (control.touched || control.dirty) && control.hasError(error) && this.isSubmit;
  }
}
