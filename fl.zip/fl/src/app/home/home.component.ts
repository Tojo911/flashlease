import {
  Component,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  EventEmitter,
  ElementRef,
  OnInit,
  HostListener
} from '@angular/core';
import { DdfService } from '../services/ddf/ddf.service';
import { Observable, Subscription, combineLatest } from 'rxjs';
import * as _ from 'lodash';
import * as moment from 'moment';
import { AuthService } from '../services/auth/auth.service';
import { ProduitService } from '../services/produit/produit.service';
import {
  MatTableDataSource,
  MatPaginator,
  PageEvent,
  MatSort,
  Sort,
  MatTabChangeEvent,
  MatTabGroup
} from '@angular/material';
import { KpiModel } from '../models/kpimodel';
import { DossierInfo } from '../models/dossier-info';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { SuiviParcInfo } from '../models/suivi-parc-info';
import { DossierMontageInfo } from '../models/dossier-montage';
import { Perimetre } from '../models/perimetre';
import { ModelOption } from '../models/option-model';
import { ItemTableInfo } from '../models/item-table-info';
import { HomeTabEnum } from '../models/enums/home-tab.enum';
import { map } from 'rxjs/operators';
import { Dossier } from '../dossier/dossier-bloc/dossier-bloc.component';
import { Phase } from '../dossier/suivi-dossier/suivi-dossier.component';
import { SirenFormatter } from '../classes/inputFormatter/sirenFormatter';
import { AmountFormatter } from '../classes/inputFormatter/amountFormatter';
import { RechercheService } from '../services/recherche/recherche.service';
import { PerimetreService } from '../services/perimetre/perimetre.service';
import { CritereRechercheInfo } from '../models/critere-recherche-info';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { PhaseDataListComponent } from '../shared/components/phase-data-list/phase-data-list.component';
import Global from '../models/global-functions';

// TODO: Export kpiStatusEnum
export enum kpiStatusEnum {
  accords = 'Accordé',
  refus = 'Refusé',
  etudes = "A l'étude",
  expires = 'Expirent',
  ETU = "A l'étude",
  ANN = 'Refusé',
  SSU = 'Expirent',
  RISK_DI = "A l'étude",
  GEST_GE = 'Accordé',
  ANO = 'Refus',
  recu = 'Reçu(s)',
  enTraitement = 'En traitement',
  enAnomalie = 'Anomalie(s)',
  paye = 'Payé(s)',
  saines = 'En loyer saine',
  amiables = 'Amiables',
  contentieuses = 'En loyer contentieuse',
  expirentMoins6Mois = 'Expirent'
}
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements AfterViewInit, OnDestroy, OnInit {
  public filter_ddf_status = [];
  public filter_ddf_status_com = [];
  private ddfKpiSubscription: Subscription;
  private montageKpiSubscription: Subscription;
  private parcKpiSubscription: Subscription;
  public value = '';
  public ddfListSubscription: Subscription;
  public ddfStatutSubscription: Subscription;
  private tabSubscription: Subscription;
  public ddfStatutComSubscription: Subscription;
  public critere: any = {};
  public aux: any;
  public ddfDatasource: any[];
  public userFirstname: string;
  public documentReady = false;
  public ddfTableColumns = [];
  public suiviParcTableColumns = [];
  public montTableColumns = [];
  public filterValue: string;
  public kpisDfsList: KpiModel[];
  public kpisMontageList: KpiModel[];
  public kpisSuiviParcList: KpiModel[];
  public parcDatasource: any[];
  public filter_parc_status = [];
  public filter_montage_status = [];
  public currentState: KpiModel;
  public defaultMontageState: KpiModel;
  public defaultDDfState: KpiModel;
  public defaultParcState: KpiModel;
  public kpiStatutSelected: ModelOption;
  private dataAux: any[] = undefined;
  private filterStatutParam: any;
  private filterMontantParam: any;
  public perimetre: Perimetre;
  public perimetres: Perimetre[];
  public loadingData = false;
  public loadingKpi = false;
  private statusDdf: any;
  private statusComDdf: any;
  private statusParc: any;
  private statusMontage: any;
  public appVersion = environment.version;
  private dossier: DossierInfo;
  private auxParcList: SuiviParcInfo[];
  private parcDataAux: any[] = undefined;
  private kpiStatusEnum = kpiStatusEnum;
  @ViewChild('tabulation')
  public tabulation: MatTabGroup;
  public montageDatasource;
  public isInterne: boolean;
  public isExterne: boolean;
  public isApporteur: boolean;
  public isAgence: boolean;
  public initSnackBigResult = true;
  private auxDossierMontageList;
  private montageDataAux: any[] = undefined;
  public kpiSelectedEvent: EventEmitter<ModelOption> = new EventEmitter<
    ModelOption
  >();
  public isDashMontage: boolean;
  public isDashParc: boolean;
  public tabultationIndex: number;
  public isDashMontageExcel: boolean;
  public exportRole: boolean;
  public exportRoleDdf: boolean;
  public exportRoleMontage: boolean;
  public exportRoleParc: boolean;
  public roleSirenRequired: boolean;
  public isVendeur: boolean;
  @ViewChild('#ddfCritere')
  public critereDdfFields: PhaseDataListComponent;
  @ViewChild('#montCritere')
  public critereMontFields: PhaseDataListComponent;
  @ViewChild('#parcCritere')
  public critereParcFields: PhaseDataListComponent;
  public storage = {
    ddfData: 'ddfData',
    ddfStatut: 'ddfStatut',
    ddfStatutCom: 'ddfStatutCom',
    montageData: 'montageData',
    montageStatut: 'montageStatut',
    montageStatutCom: 'montageStatutCom',
    suiviParcData: 'suiviParcData',
    suiviParcStatut: 'suiviParcStatut',
    suiviParcStatutCom: 'suiviParcStatutCom',
    ddfUrl: 'ddf',
    montageUrl: 'montage',
    suiviParcUrl: 'affaires'
  };

  public HomeTabenum = HomeTabEnum;
  private sirenFormatter = new SirenFormatter();
  private amountFormatter = new AmountFormatter();

  private crtlIsPressed = false;
  @HostListener('window:keydown', ['$event'])
  keydownEvent(event: KeyboardEvent) {
    if (event.ctrlKey) {
    this.crtlIsPressed = true;
    }
  }
  @HostListener('window:keyup', ['$event'])
  keyUpEvent(event: KeyboardEvent) {
    this.crtlIsPressed = false;
  }

  constructor(
    private ddfService: DdfService,
    private authService: AuthService,
    private translateService: TranslateService,
    private router: Router,
    private rechServ: RechercheService,
    public snackBar: MatSnackBar,
  ) {
    this.userFirstname = this.authService.getUserDataByKeyFromJWTPayload(
      'firstname'
    );
    this.perimetre = this.authService.getPerimetreFromToken();
    this.perimetres = [this.perimetre];
    this.isInterne = this.authService.isInterne();
    this.isExterne = this.authService.isExterne();
    this.isAgence = this.authService.isAgence();
    this.isVendeur = this.authService.isVendeur();
    this.isApporteur = this.authService.isApporteur();
  }

  ngOnInit() {}

  ngOnDestroy() {
    if (this.ddfListSubscription) {
      this.ddfListSubscription.unsubscribe();
    }
    if (this.ddfKpiSubscription) {
      this.ddfKpiSubscription.unsubscribe();
    }
    if (this.ddfStatutSubscription) {
      this.ddfStatutSubscription.unsubscribe();
    }
    if (this.tabSubscription) {
      this.tabSubscription.unsubscribe();
    }
    if (this.ddfStatutComSubscription) {
      this.ddfStatutComSubscription.unsubscribe();
    }
  }
  isProd() {
    return environment.env === 'prod';
  }
  isAuthMontage() {
    if (!this.authService.isDashMontage()) {
      this.isDashMontage = false;
      document
        .getElementsByClassName('mat-tab-label')
        [HomeTabEnum.MONTAGE].setAttribute('style', 'display: none');
    }
    return;
  }

  isAuthSuivi() {
    if (!this.authService.isDashParc()) {
      this.isDashParc = false;
      document
        .getElementsByClassName('mat-tab-label')
        [HomeTabEnum.PARC].setAttribute('style', 'display: none');
    }
    return;
  }

  hasRoleExportParc() {
    return this.authService.hasRoleExportParc();
  }

  hasRoleExportMontage() {
    return this.authService.hasRoleExportMontage();
  }

  hasRoleSirenRequired() {
    return this.authService.hasRoleSirenRequired();
  }

  isAuthDdf() {
    return this.authService.isAuthDdf();
  }

  linkToDossier(e) {
    this.router.navigate(['dossier/' + e.numeroFL + '/suivi/']);
  }

  resetTable() {
    // get DDFs datasource
    this.dataAux = JSON.parse(
      localStorage.getItem(this.storage.ddfData + this.perimetre.vendeur)
    );
    if (this.dataAux) {
      this.ddfDatasource = this.dataAux;
    }

    // get DDFs STATUS
    this.statusDdf = JSON.parse(localStorage.getItem(this.storage.ddfStatut));
    if (this.statusDdf) {
      this.filter_ddf_status = this.statusDdf;
    }
   // this.statusComDdf = JSON.parse(
   //   localStorage.getItem(this.storage.ddfStatutCom + this.perimetre.vendeur)
   // );
    this.statusComDdf = JSON.parse(
      localStorage.getItem(this.storage.ddfStatutCom)
    );
    if (this.statusComDdf) {
      this.filter_ddf_status_com = this.statusComDdf;
    }

    // get DOSSIERS MONTAGE datasource
    this.montageDataAux = JSON.parse(
      localStorage.getItem(this.storage.montageData + this.perimetre.vendeur)
    );
    if (this.montageDataAux) {
      this.montageDatasource = this.montageDataAux;
    }

    // get DOSSIERS MONTAGE STATUS
    this.statusMontage = JSON.parse(
      localStorage.getItem(this.storage.montageStatut)
    );
    if (this.statusMontage) {
      this.filter_montage_status = this.statusMontage;
    }

    // get SUIVI PARC datasource
    this.parcDataAux = JSON.parse(
      localStorage.getItem(this.storage.suiviParcData + this.perimetre.vendeur)
    );
    if (this.parcDataAux) {
      this.parcDatasource = this.parcDataAux;
    }
    // get SUIVI PARC STATUS
    this.statusParc = JSON.parse(
      localStorage.getItem(this.storage.suiviParcStatut)
    );
    if (this.statusParc) {
      this.filter_parc_status = this.statusParc;
    }
  }
  formatItem(its) {
    return JSON.stringify(this.rechServ.formatDataTableItem(its));
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.isAuthMontage();
      this.isAuthSuivi();

      this.tabSubscription = this.ddfService.currentDashboardTab.subscribe(
        event => {
          if (event !== undefined) {
            this.tabulation.selectedIndex = event;
          }
          this.updatePerimetre(this.tabulation.selectedIndex);
        }
      );
      this.rechServ.searchSubject.subscribe(rech => {
        if (rech.isLoading) {
          this.loadingData = true;
          if (rech.criteres && !rech.result) {
            const localStoId = this.critere2LocalStorageId(rech.criteres);
            const loclastoData = JSON.parse(localStorage.getItem(localStoId));
            const crit = rech.criteres as CritereRechercheInfo;
            if (loclastoData) {
              this.loadingData = true;
              this.setDataSource(
                loclastoData,
                this.getTypeToTabIndex(crit.phase)
              );
              if (loclastoData.length >= 100) {
                this.initSnackBigResult = false;
              //  console.log('BigResult false');
                this.openSnack(
                  this.translateService.instant('HOME.TABLE.BIG_RESULT'),
                  '',
                  5000
                );
              }
            }
          }
        } else {
          this.loadingData = false;
          if (rech.result.length >= 100 && rech.isLastRequest && this.initSnackBigResult) {
          //  console.log('BigResult true');
            this.openSnack(
              this.translateService.instant('HOME.TABLE.BIG_RESULT'),
              '',
              5000
            );
          }
          if (rech.criteres && rech.result) {
            const localStoId = this.critere2LocalStorageId(rech.criteres);
            localStorage.setItem(localStoId, this.formatItem(rech.result));
          }
        }
      });
      // get TABLEs definitions
      this.translateService.get('TABLE').subscribe(t => {
        this.ddfTableColumns = this.getDdfsColumnsDef();
        this.montTableColumns = this.getMontagesColumnDef();
        this.suiviParcTableColumns = this.getSuiviParcColumnsDef();
      });
      this.resetTable();

      this.documentReady = true;
    }, 100);
  }
  critere2LocalStorageId(crit: CritereRechercheInfo) {
    return JSON.stringify(crit);
  }

  getMontagesColumnDef() {
    const list = [
      {
        columnDef: 'onclick',
        header: '',
        sort: false,
        type: true,
        onclick: (row: ItemTableInfo) => this.montageDetail(row),
        cell: (row: ItemTableInfo) => 'visibility'
      },
      {
        columnDef: 'numDossier',
        forbiddenScreens: ['xs'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_DOSSIER'),
        sort: true,
        cell: (row: ItemTableInfo) => row.numContrat
      },
      {
        columnDef: 'numAccord',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_ACCORD'),
        sort: true,
        cell: (row: ItemTableInfo) => row.numOctroi
      },
      {
        columnDef: 'numSiren',
       // forbiddenScreens: ['xs', 'sm', 'md'],
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: ItemTableInfo) =>
          this.sirenFormatter.transform(row.numeroSIREN)
      },
      {
        columnDef: 'raisonSocial',
        forbiddenScreens: ['xs', 'largeCol'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: true,
        sort: true,
        cell: (row: ItemTableInfo) => row.raisonSociale
      },
      {
        columnDef: 'montant',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.MONTANT'),
        sort: true,
        isNumeric: true,
        cell: (row: ItemTableInfo) =>
          this.amountFormatter.transform(row.montant)
      },
      {
        columnDef: 'statut',
       // forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUT'),
        sort: true,
        tooltip: true,
        cell: (row: ItemTableInfo) => row.statut
      },
      {
        columnDef: 'DateStatut',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.DATE_STATUT'),
        sort: true,
        date: true,
        cell: (row: ItemTableInfo) => row.dateStatut
      },
      {
        columnDef: 'DocumentaTraiter',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.DOCTOTREAT'),
        sort: true,
        cell: (row: ItemTableInfo) => row.pieces
      }
    ];
    return list;
  }

  getDdfsColumnsDef() {
    let newList = [];
    const list = [
      {
        columnDef: 'onclick',
        header: '',
        sort: false,
        type: true,
        onclick: (row: ItemTableInfo) => this.ddfDetail(row),
        onmousedown : (row: ItemTableInfo) => this.ddfDetail(row),
        cell: (row: ItemTableInfo) => 'visibility'
      },
      {
        columnDef: 'numFranfinance',
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.NUM_FLASHLEASE'
        ),
        sort: true,
        cell: (row: ItemTableInfo) => row.numeroFL
      },
      {
        columnDef: 'numSiren',
        forbiddenScreens: ['xs', 'sm', 'md'],
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: ItemTableInfo) =>
          this.sirenFormatter.transform(row.numeroSIREN)
      },
      {
        columnDef: 'raisonSocial',
        forbiddenScreens: ['xs', 'largeCol'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: true,
        sort: true,
        cell: (row: ItemTableInfo) => row.raisonSociale
      },
      {
        columnDef: 'montant',
        forbiddenScreens: ['xs'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.MONTANT'),
        sort: true,
        isNumeric: true,
        cell: (row: ItemTableInfo) =>
          this.amountFormatter.transform(row.montant)
      },
      {
        columnDef: 'dateCreation',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.DATE_CREATION'
        ),
        sort: true,
        date: true,
        cell: (row: ItemTableInfo) => row.dateSaisie
      },
      {
        columnDef: 'statut',
       // forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUT'),
        sort: true,
        cell: (row: ItemTableInfo) => row.statut
      }
      // {
      //   columnDef: 'statusCo',
      //   forbiddenScreens: ['xs', 'sm'],
      //   header: this.translateService.instant(
      //     'HOME.TABLE.COLUMNS.STATUS_COMMERCIAL'
      //   ),
      //   sort: true,
      //   cell: (row: ItemTableInfo) => row.statutCommercial
      // },
       , {
         columnDef: 'expirele',
         header: this.translateService.instant(
           'HOME.TABLE.COLUMNS.ACCORD_EXPIRE_LE'
         ),
         sort: true,
         date: true,
         cell: (row: ItemTableInfo) => row.dateFinValidite
       }
    ];
    if (this.isInterne) {
      newList = [
        {
          columnDef: 'apporteur',
          forbiddenScreens: ['xs', 'sm'],
          header: this.translateService.instant('HOME.TABLE.COLUMNS.APPORTEUR'),
          sort: true,
          cell: (row: ItemTableInfo) => row.apporteur
        },
        {
          columnDef: 'vendeur',
          forbiddenScreens: ['xs', 'sm'],
          header: this.translateService.instant('HOME.TABLE.COLUMNS.VENDEUR'),
          sort: true,
          cell: (row: ItemTableInfo) => row.vendeur
        }
      ];
    }

    if (this.isExterne && this.isApporteur) {
      newList = [
        {
          columnDef: 'agence',
          forbiddenScreens: ['xs', 'sm'],
          header: this.translateService.instant('HOME.TABLE.COLUMNS.AGENCE'),
          sort: true,
          cell: (row: ItemTableInfo) => row.agence
        },
        {
          columnDef: 'vendeur',
          forbiddenScreens: ['xs', 'sm'],
          header: this.translateService.instant('HOME.TABLE.COLUMNS.VENDEUR'),
          sort: true,
          cell: (row: ItemTableInfo) => row.vendeur
        }
      ];
    }
    const newListStatutCommercial = [
      {
        columnDef: 'statutCommercial',
       // forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUS_COMMERCIAL'),
        sort: true,
        cell: (row: ItemTableInfo) => row.statutCommercial
      },
    ];
    return list.concat(newList).concat(newListStatutCommercial);
  }

  getSuiviParcColumnsDef() {
    return [
      {
        columnDef: 'onclick',
        header: '',
        sort: false,
        type: true,
        onclick: (row: ItemTableInfo) => this.parcDetail(row),
        cell: (row: ItemTableInfo) => 'visibility'
      },
      {
        columnDef: 'numEkip',
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_DOSSIER'),
        cell: (row: ItemTableInfo) => row.numEkip
      },
      {
        columnDef: 'apporteur',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.APPORTEUR'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => row.apporteur
      },
      {
        columnDef: 'agence',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.AGENCE'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => row.agence
      },
      {
        columnDef: 'reApporteur',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.REF_APPORTEUR'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => row.refApporteur
      },
      {
        columnDef: 'statut',
        forbiddenScreens: ['xs'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUT'),
        sort: true,
        cell: (row: ItemTableInfo) => row.statut
      },
      {
        columnDef: 'numSiren',
        sort: true,
       // forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: ItemTableInfo) => this.sirenFormatter.transform(row.numeroSIREN)
      },
      {
        columnDef: 'raisonSocial',
        forbiddenScreens: ['xs', 'sm', 'md', 'largeCol'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => row.raisonSociale
      },
      {
        columnDef: 'loyer',
        forbiddenScreens: ['xs'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.LOYER'),
        sort: true,
        isNumeric: true,
        cell: (row: ItemTableInfo) => this.amountFormatter.transform(row.loyer)
      },
      {
        columnDef: 'expirele',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.EXPIRE_LE'),
        sort: true,
        date: true,
        cell: (row: ItemTableInfo) => row.dateExpire
      }
    ];
  }

  closeSlider($e, any) {
    console.log(any);
  }

  itemBeenRead(item) {
    item.new = false;
  }

  getDdfList(idVendeur, dataK, statutK, tabIndex) {
    const accord = this.ddfService
      .getDDFAccordList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const etude = this.ddfService
      .getDDFEtudeList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const refus = this.ddfService
      .getDDFRefusList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const expire = this.ddfService
      .getDDFExpireList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));
    this.ddfListSubscription = combineLatest(accord, etude, refus, expire)
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(
          _.orderBy(res, ['dateSaisie'], ['asc']),
          idVendeur,
          dataK,
          statutK,
          tabIndex
        );
        this.loadingData = false;
      });
  }

  getMontageList(idVendeur, dataK, statutK, tabIndex) {
    const payes = this.ddfService
      .getMontagePayesList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const enTraitement = this.ddfService
      .getMontageEntraitementList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const recus = this.ddfService
      .getMontageRecusList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const enAnomalie = this.ddfService
      .getMontageEnAnomalieList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    this.ddfListSubscription = combineLatest(
      payes,
      enTraitement,
      recus,
      enAnomalie
    )
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(
          _.orderBy(res, ['dateSaisie'], ['asc']),
          idVendeur,
          dataK,
          statutK,
          tabIndex
        );
        this.loadingData = false;
      });
  }

  getParcList(idVendeur, dataK, statutK, tabIndex) {
    const saines = this.ddfService
      .getParcSaineList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const contentieuse = this.ddfService
      .getParcContentieuseList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const amiable = this.ddfService
      .getParcAmiableList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const expire = this.ddfService
      .geParcExpireList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    this.ddfListSubscription = combineLatest(
      saines,
      contentieuse,
      amiable,
      expire
    )
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(res, idVendeur, dataK, statutK, tabIndex);
        this.loadingData = false;
      });
  }

  public updatePerimetre(event?) {
    this.loadingKpi = true;
    this.loadingData = true;
    this.tabultationIndex = event ? event : this.tabulation.selectedIndex;
    // let datasource, datakey;
    let statutKey;
    let statutComKey;
    if (this.tabultationIndex === HomeTabEnum.DDF) {
      statutKey = this.storage.ddfStatut;
      statutComKey = this.storage.ddfStatutCom;
      // console.log('statutKey' + this.authService.getAuthorities());
      // Always true in the dashboard
      // this.exportRoleDdf = true;
      this.exportRoleDdf = true;
      /*datasource = this.ddfDatasource;
      datakey = this.storage.ddfData;
      this.getDdfList(
        this.perimetre.vendeur,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );*/
    } else if (this.tabultationIndex === HomeTabEnum.MONTAGE) {
      statutKey = this.storage.montageStatut;
      // this.exportRoleMontage = this.hasRoleExportMontage();
      this.exportRoleMontage = this.hasRoleExportMontage();
      this.currentState = this.defaultMontageState;
      /*datasource = this.montageDatasource;
      datakey = this.storage.montageData;
      this.getMontageList(
        this.perimetre.vendeur,
        datakey,
        statutKey,
        this.tabulation.selectedIndex*/
    } else if (this.tabultationIndex === HomeTabEnum.PARC) {
      statutKey = this.storage.suiviParcStatut;
      this.exportRoleParc = this.hasRoleExportParc();
      this.roleSirenRequired = this.hasRoleSirenRequired();
      /*datasource = this.parcDatasource;
      datakey = this.storage.suiviParcData;
      this.getParcList(
        this.perimetre.vendeur,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );*/
    }

    // Tojo : 26/12/2018 : correction JIRA 680 : chargement des statuts
    this.ddfStatutSubscription = this.ddfService
      .getAllStatus(this.getTypeFromTab(this.tabulation.selectedIndex))
      .subscribe(res => {
        this.populateStatus(res.content, statutKey);
        this.resetTable();
      },
      error => {
        this.resetTable();
      });

    if (this.tabultationIndex === HomeTabEnum.DDF) {
      this.ddfStatutComSubscription = this.ddfService
        .getAllStatusCom(this.getTypeFromTab(this.tabulation.selectedIndex))
        .subscribe(res => this.populateStatusCom(res.content, statutComKey));
    }

    // this.resetTable();

    switch (this.tabultationIndex) {
      case HomeTabEnum.DDF:
        {
          this.ddfKpiSubscription = this.ddfService
            .getKpi(
              this.perimetre.vendeur,
              this.getTypeFromTab(this.tabultationIndex),
              this.perimetres
            )
            .subscribe(data => {
              this.kpisDfsList = Global.mapKpiObjToList(
                data.content,
                KpiModel
              );
              const accord = this.kpisDfsList.find(
                it => it.libelle === 'accords'
              );
              const etude = this.kpisDfsList.find(
                it => it.libelle === 'etudes'
              );
              const refus = this.kpisDfsList.find(it => it.libelle === 'refus');
              const expirent = this.kpisDfsList.find(
                it => it.libelle === 'expires'
              );
              // GESTION KPI
              const datePlus30Jours = new Date();
              datePlus30Jours.setDate(datePlus30Jours.getDate() + 30);
              const dateMoins6Mois = new Date();
              dateMoins6Mois.setMonth(dateMoins6Mois.getMonth() - 6);
              etude.data = {
                statuts: [
                  new ModelOption("A l'étude", 'ETU'),
                  new ModelOption("Demande d'information", 'RISK_DI'),
                  new ModelOption('Anomalie', 'ANO')
                ],
                dateDebut: dateMoins6Mois
              };
              accord.data = {
                statuts: [
                  new ModelOption('Accord Forcé', 'AFO'),
                  new ModelOption('Accordé hors délégation', 'AHD'),
                  new ModelOption('Accordé', 'ACC'),
                  new ModelOption('Accordé sous condition', 'ASI'),
                  // new ModelOption('Signé', 'MONT_SI'),
                  new ModelOption('Accords Détaillé', 'MONT_RA'),
                  // new ModelOption('En gestion', 'GEST_GE')
                ],
                dateDebut: dateMoins6Mois
              };
              refus.data = {
                statuts: [
                  new ModelOption('Refus défavorable', 'RFD'),
                  new ModelOption('Refus rédhibitoire', 'RFR'),
                  new ModelOption('Refus', 'REF')
                ],
                dateDebut: dateMoins6Mois
              };
              expirent.data = {
                statuts: accord.data.statuts,
                dateFinValidite: datePlus30Jours
              };
              this.kpisDfsList = [accord, etude, refus, expirent];
              this.loadingKpi = false;
            });
        }
        break;
      case HomeTabEnum.MONTAGE:
        {
          this.montageKpiSubscription = this.ddfService
            .getKpi(
              this.perimetre.vendeur,
              this.getTypeFromTab(this.tabultationIndex),
              this.perimetres
            )
            .subscribe(data => {
              let montageList;
              montageList = Global.mapKpiObjToList(data.content, KpiModel);

              const recu = montageList.find(it => it.libelle === 'recu');
              const enTraitement = montageList.find(
                it => it.libelle === 'enTraitement'
              );
              const anomalie = montageList.find(
                it => it.libelle === 'enAnomalie'
              );
              this.currentState = anomalie;
              const paye = montageList.find(it => it.libelle === 'paye');

              montageList = [recu, enTraitement, anomalie, paye];

              this.kpisMontageList = montageList;
              enTraitement.data = {
                statuts: [
                  new ModelOption('Commande envoyée', 'COMMANDE_ENVOYEE'),
                  new ModelOption('Dossier en cours de vérification', 'ETUDE'),
                  new ModelOption('Dossier réglé', 'MEL_REGLE'),
                  new ModelOption('Dossier mis en loyer à régler', 'MEL_A_REGLER'),
                  new ModelOption('Règlement en cours de vérification', 'ETUDE_REGLEMENT'),
                  new ModelOption('Dossier à régler partiellement', 'PREL_A_REGLER'),
                  new ModelOption('Dossier partiellement réglé', 'PREL_REGLE'),
                  // new ModelOption('Commande en cours de vérification', 'ETUDE_COMMANDE'),
                  new ModelOption('Contrat édité', 'CONTRAT_EDITE')
                ]
              };
              anomalie.data = {
                statuts: [
                  new ModelOption('Dossier non-conforme commande', 'NC_COMMANDE'),
                  new ModelOption('Dossier non-conforme règlement', 'NC_REGLEMENT'),
                  new ModelOption('Dossier non-conforme réception', 'NC_RECEPTION')
                ]
              };
              paye.data = {
                statuts:  [
                  new ModelOption('Dossier en régulation', 'EN_REGULE'),
                  new ModelOption('Dossier mis en loyer à régler', 'MEL_A_REGLER'),
                  new ModelOption('Dossier réglé', 'MEL_REGLE'),
                ]
              };
              recu.data = {
                statuts: [
                  ...paye.data.statuts,
                  ...anomalie.data.statuts,
                  ...enTraitement.data.statuts
                ]
              };
              this.loadingKpi = false;
            });
        }
        break;
      case HomeTabEnum.PARC:
        {
          this.parcKpiSubscription = this.ddfService
            .getKpi(
              this.perimetre.vendeur,
              this.getTypeFromTab(this.tabultationIndex),
              this.perimetres
            )
            .subscribe(data => {
              this.kpisSuiviParcList = Global.mapKpiObjToList(
                data.content,
                KpiModel
              );
              const saines = this.kpisSuiviParcList.find(it => it.libelle === 'saines');
              const amiables = this.kpisSuiviParcList.find(
                it => it.libelle === 'amiables'
              );
              const contentieuses = this.kpisSuiviParcList.find(
                it => it.libelle === 'contentieuses'
              );
              const expirentMoins6Mois = this.kpisSuiviParcList.find(it => it.libelle === 'expirentMoins6Mois');
              saines.data = {
                statuts:  [
                  new ModelOption('En loyer saine', 'EL1S'),
                ]
              };
              amiables.data = {
                statuts:  [
                  new ModelOption('En loyer amiable', 'EL1A'),
                ]
              };
              contentieuses.data = {
                statuts:  [
                  // new ModelOption('En loyer contentieuse réservé', 'EL2C'),
                  new ModelOption('En loyer contentieuse', 'EL1C')
                ]
              };
              expirentMoins6Mois.data = {
                statuts:  [
                  new ModelOption('En loyer contentieuse réservé', 'EL2C'),
                ]
              };
              this.loadingKpi = false;
            });
        }
        break;
    }
  }

  handleKpi(e) {
    if (!e) {

    }
  }
  populateStatus(list, storageStatusPrefix) {
    const available_status = [];
    list.forEach((item: any) => {
      available_status.push(
        new ModelOption(item['libelle'], item['code'] ? item['code'] : item['key'], item)
      );
    });
    // chargement initial pour ddf
    this.filter_ddf_status = _.uniqBy(_.orderBy(available_status, ['libelle'], ['asc']), 'libelle');
    localStorage.setItem(
      storageStatusPrefix,
      JSON.stringify(
        this.filter_ddf_status
      )
    );
  }

  populateStatusCom(list, storageStatusComPrefix) {
    const available_status = [];
    list.forEach((item: any) => {
      available_status.push(
        new ModelOption(item['libelle'], item['oid'], item)
      );
    });
    localStorage.setItem(
      storageStatusComPrefix,
      JSON.stringify(
        _.uniqBy(_.orderBy(available_status, ['libelle'], ['asc']), 'libelle')
      )
    );
  }

  populateDatatable(
    list: DossierInfo[],
    vendeur,
    storageDataPrefix,
    storageStatusPrefix,
    type,
    storageStatusComPrefix?
  ) {
    if (!vendeur) {
      vendeur = this.perimetre.vendeur;
    }
    const items = [];

    list.forEach((item: DossierInfo) => {
      const model: ItemTableInfo = new ItemTableInfo(item);
      items.push(model);
    });

    this.aux = items;
    localStorage.setItem(storageDataPrefix + vendeur, JSON.stringify(items));
    if (vendeur === this.perimetre.vendeur) {
      const dataSrc = items.map(item => {
        if (dataSrc && dataSrc.find(it => it.id === item.id) !== undefined) {
          item.new = true;
        }
        return item;
      });
      this.setDataSource(dataSrc, type);
    }
    this.resetTable();
  }

  setDataSource(datasrc, type) {
    if (type === this.getTypeFromTab(this.tabulation.selectedIndex)) {
      if (type === this.getTypeFromTab(HomeTabEnum.DDF)) {
        this.ddfDatasource = datasrc;
      } else if (type === this.getTypeFromTab(HomeTabEnum.MONTAGE)) {
        this.montageDatasource = datasrc;
      } else if (type === this.getTypeFromTab(HomeTabEnum.PARC)) {
        this.parcDatasource = datasrc;
      }
    }
  }
  getTypeToTabIndex(type) {
    let val;
    type = type.toLocaleLowerCase();
    switch (type) {
      case 'ddf':
        val = HomeTabEnum.DDF;
        break;
      case 'mont':
        val = HomeTabEnum.MONTAGE;
        break;
      case 'parc':
        val = HomeTabEnum.PARC;
        break;
    }
    return this.getTypeFromTab(val);
  }
  getTypeFromTab(tab) {
    if (tab === HomeTabEnum.DDF) {
      return this.storage.ddfUrl;
    } else if (tab === HomeTabEnum.MONTAGE) {
      return this.storage.montageUrl;
    } else if (tab === HomeTabEnum.PARC) {
      return this.storage.suiviParcUrl;
    }
  }

  openDossierLink(url) {
    if (this.crtlIsPressed) {
      window.open(url, '_blank');
    } else {
      this.router.navigate([url]);
    }
  }

  ddfDetail(event) {
    const url = `dossier/${Phase.DDF}_${event.numeroFL}/suivi/`;
    this.openDossierLink(url);
  }
  montageDetail(event) {
    const url = `dossier/${Phase.MONTAGE}_${event.numOctroi}/suivi/`;
    this.openDossierLink(url);
  }
  parcDetail(event) {
    const url = `dossier/${Phase.PARC}_${event.numeroFL}/suivi/`;
    this.openDossierLink(url);
  }

  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
}
