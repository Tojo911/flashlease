import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { DossierComponent } from '../dossier/dossier.component';
import { SuiviDossierComponent } from '../dossier/suivi-dossier/suivi-dossier.component';
import { DdfNotificationComponent } from '../ddf/ddf-notification/ddf-notification.component';
import { DdfPageComponent } from '../ddf/ddf-page/ddf-page.component';
import { LoggedGuard } from '../services/auth/guards/logged.guard';
import { AppLayoutComponent } from '../layout/app-layout.component';
import { MonCompteComponent } from '../users/mon-compte/mon-compte.component';
import { ResultatsRechercheComponent } from '../resultats-recherche/resultats-recherche.component';
import { ModelGeneratorComponent } from '../classes/mock/model-generator/model-generator.component';
import { RefreshComponent } from '../layout/header/refresh/refresh.component';
import { RachatDemandeComponent } from '../rachat/rachat-demande/rachat-demande.component';
import { EditionContratComponent } from '../contrat/edition-contrat/edition-contrat.component';
import { FournisseurEditionComponent } from '../contrat/fournisseur-edition/fournisseur-edition.component';
import { DevGuard } from '../services/auth/guards/dev.guard';
import { RachatComponent } from '../rachat/rachat.component';
import { RachatConsultationComponent } from '../rachat/rachat-consultation/rachat-consultation.component';
import { RechercheRachatComponent } from '../rachat/recherche-rachat/recherche-rachat.component';
import { PerimetreSelectAvanceeComponent } from '../shared/components/perimetre-select-avancee/perimetre-select-avancee.component';
const routes: Routes = [
  {
    path: '',
    component: AppLayoutComponent,
    canActivate: [LoggedGuard],
    children: [
      {
        path: '',
        component: HomeComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'refresh',
        component: RefreshComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'ddfNotif',
        component: DdfNotificationComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'dossier/:did',
        component: DossierComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'ddf',
        component: DdfPageComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'dossier/:did/suivi',
        component: SuiviDossierComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'dossier/:did/suivi/rachat/:rachatId',
        component: SuiviDossierComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'monCompte',
        component: MonCompteComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'resultats-recherche',
        component: ResultatsRechercheComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'rachat/demande',
        component: RachatDemandeComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'rachat/demande/:did',
        component: RachatDemandeComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'rachat/recherche',
        component: RechercheRachatComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'rachat',
        component: RachatConsultationComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'contrat/edition',
        component: EditionContratComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'contrat/fournisseurEdition',
        component: FournisseurEditionComponent,
        canActivate: [LoggedGuard]
      },
      /*
      {
        path: 'perimetre',
        component: PerimetreSelectAvanceeComponent,
        canActivate: [LoggedGuard]
      },
      */
    ]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'tools',
    component: ModelGeneratorComponent,
    canActivate: [DevGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {}
