import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RachatWaitdialogComponent } from './rachat-waitdialog.component';

describe('RachatWaitdialogComponent', () => {
  let component: RachatWaitdialogComponent;
  let fixture: ComponentFixture<RachatWaitdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RachatWaitdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RachatWaitdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
