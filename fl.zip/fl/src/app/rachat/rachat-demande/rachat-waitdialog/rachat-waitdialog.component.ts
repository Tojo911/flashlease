import {
  Component,
  OnInit,
  Inject
} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-rachat-waitdialog',
  templateUrl: './rachat-waitdialog.component.html',
  styleUrls: ['./rachat-waitdialog.component.scss']
})
export class RachatWaitdialogComponent implements OnInit {

  constructor(
    public translate: TranslateService,
    public dialogRef: MatDialogRef<RachatWaitdialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  ngOnInit() {
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
