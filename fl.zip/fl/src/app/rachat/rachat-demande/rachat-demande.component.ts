import {
  Component,
  OnInit,
  Inject,
  DoCheck,
  OnChanges,
  SimpleChanges,
  ViewChildren,
  QueryList,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import {
  FormControl,
  FormBuilder,
  FormGroup,
  Validators,
  AsyncValidatorFn,
  AsyncValidator,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';

import { Observable, Subject } from 'rxjs';

import { ActivatedRoute } from '@angular/router';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import {
  filter,
  debounceTime,
  distinctUntilChanged,
  switchMap
} from 'rxjs/operators';

import { Router } from '@angular/router';

import { EntrepriseService } from '../../services/entreprise/entreprise.service';
import { DdfService } from '../../services/ddf/ddf.service';
import { ProduitService } from '../../services/produit/produit.service';
import { NatureProduitEnum } from '../../classes/nature-produit.enum';

import * as _ from 'lodash';
import { DdfDataSourceService } from '../../services/ddf/ddf-data-source.service';
import { CatalogueService } from '../../services/catalogue/catalogue.service';
import { MaterielService } from '../../services/materiel/materiel.service';
import { DdfValidation, DdfModel } from '../../models/ddf-validation';
import { ModelOption } from '../../models/option-model';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { FileUploader } from 'ng2-file-upload';

import { SirenFormatter } from '../../classes/inputFormatter/sirenFormatter';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { PerimetreService } from '../../services/perimetre/perimetre.service';
import { ClickedOutsideDirective } from '../../directives/clicked-outside.directive';
import { Perimetre } from '../../models/perimetre';
import { AuthService } from '../../services/auth/auth.service';
import { userInfo } from 'os';
import { UserInfo } from '../../models/ddf';


import {
  RachatDemandeValidation,
  RachatDemandeModel,
  ConditionRachatInfo,
  FormuleInfo
} from '../../models/rachat-demande-validation';
import { CriteresRechercheRachatVo, RachatVo, VendeurId } from '../../models/ddf';
import { RachatService } from '../../services/rachat/rachat.service';
import { RachatWaitdialogComponent } from './rachat-waitdialog/rachat-waitdialog.component';
import Global from '../../models/global-functions';
import { TranslateService } from '@ngx-translate/core';

export interface Produit {
  actif: boolean;
  categorie: any;
}

@Component({
  selector: 'app-rachat-demande',
  templateUrl: './rachat-demande.component.html',
  styleUrls: ['./rachat-demande.component.scss']
})
export class RachatDemandeComponent implements OnInit, OnDestroy, OnChanges {
  model = new DdfModel();
  sirenTerm$ = new Subject<string>();
  duree$ = new Subject<string>();
  anneeMat$ = new Subject<string>();
  montantError = false;
  dureeError = false;
  anneeMatError = false;
  ddfSubmitted = false;
  ddfFinished = false;
  numerofl: string;
  catalogues: any = [];
  ListeMateriels: any = [];
  ListeCatalogues: any = [];
  public produitsList: any;
  public NatureProduitEnum = NatureProduitEnum;
  DdfForm: FormGroup;
  DDfValid = false;
  validationError: any = null;

  sirenQuerying = false;
  formSubmitted = false;
  lastCall = new Date().getTime();
  lastRecall = null;
  isAbouttoValidate = false;
  waitingTime = 750;
  public dureeProduit: any;
  errorMsgType: string;
  errorMsgSize: string;
  sirenFormat = new SirenFormatter();
  amountFormat = new AmountFormatter(0, 100000000, 0, 9);
  percentFormat = new AmountFormatter(0, 100, 0, 3);
  residFormat = new AmountFormatter(0, 100000000, 0, 9);
  perimetre: Perimetre = {};
  defaultCode_mat: string;
  defaultCode_cat: string;
  disableCommentaire: boolean;
  isInterne: boolean;
  isSirenValid: boolean;
  public postDdf$;
  public materielServ$;
  public validate$;
  public materielEtat$;
  public montant$;
  public produit$;
  public catalog$;
  public sirenTer$;
  public translate2$;
  public translate1$;


  public postRachatDemande$;
  rachatDemandeForm: FormGroup;
  rachatModel = new RachatDemandeModel();
  conditionDisabled: boolean;
  conditionHidden: boolean;
  conditionPreset: any;
  conditionValue: any;
  conditionListOption: ModelOption[] = [];
  formuleDisabled: boolean;
  formuleHidden: boolean;
  formulePreset: any;
  formuleValue: any;
  formuleTypeFormule: any;
  formuleListOption: ModelOption[] = [];
  commentaireExterneReadOnly: boolean;
  commentaireExterneValue: any;
  displayModeDeRachat: boolean;
  resultNumeroAffaire: any;
  waiting = false;

  isopen: boolean;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private fb: FormBuilder,
    public snackBar: MatSnackBar,
    public translate: TranslateService,
    public perimetreService: PerimetreService,
    public rachatService: RachatService,
    public translateService: TranslateService,
  ) {
    this.conditionDisabled = true;
    this.conditionHidden = false;
    this.conditionPreset = null;
    this.formuleDisabled = true;
    this.formuleHidden = false;
    this.formulePreset = null;
    this.perimetre = this.authService.getPerimetreFromToken();
    this.rachatModel.perimetre = this.perimetre;
    this.rachatModel.echeanceRachat = this.getDateTime();
    this.isInterne = this.authService.isInterne();
    this.route.params.subscribe(params => {
      if (params.did) {
        this.rachatModel.numeroContrat = params.did;
      } else {
        this.rachatModel.numeroContrat = '';
      }
    });

    if (this.authService.isAuthRachatCreationRenouvelante() &&
    this.authService.isAuthRachatCreationNonRenouvelante()) {
      this.rachatModel.renouvelante = 'OUI';
      this.displayModeDeRachat = true;
    } else if (this.authService.isAuthRachatCreationRenouvelante()) {
      this.rachatModel.renouvelante = 'OUI';
    } else if (this.authService.isAuthRachatCreationNonRenouvelante()) {
      this.rachatModel.renouvelante = 'NON';
    }

  //  this.isInterne = false;
  }

  ngOnDestroy() {}

  ngOnChanges(changes: SimpleChanges) {}

  ngOnInit() {
    this.initRachatDemandeForm();
    this.setConditionByApporteur();
  }

  initRachatDemandeForm() {
    this.rachatDemandeForm = this.fb.group({
      numeroContrat: [
        this.rachatModel.numeroContrat,
        {
          updateOn: 'change',
          validators: [Validators.required,
          ],
          asyncValidators: [() => this.validate()]
        }
      ],
      echeanceRachat: [
        this.getDateTime(),
        {
          updateOn: 'change',
          validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      renouvelante: [
        '',
        {
          updateOn: 'change',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      condition: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      formule: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      montant: [
        '',
        {
          updateOn: 'change',
          validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      dateValidite: [
        '',
        {
          updateOn: 'change',
          validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      commentaireInterne: [
        '',
        {
          updateOn: 'change',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      commentaireExterne: [
        '',
        {
          updateOn: 'change',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
    });
  }

  perimetreApporteurChange(event) {
    console.log('perimetreApporteurChange');
    this.rachatModel.perimetre = this.perimetre;
    this.cleanCondition();
    this.cleanFormule();
    this.cleanCommentaireExterne();
    this.setConditionByApporteur();
  }

  conditionFormChange() {
    console.log('conditionFormChange');
    this.cleanFormule();
    this.cleanCommentaireExterne();
    this.setFormuleByCondition();
  }

  formuleFormChange() {
    console.log('formuleFormChange : ' + this.rachatModel.formule.libelle);
    if (this.rachatModel.formule.value) {
      console.log('formuleFormChange plein');
      this.formuleTypeFormule = Global.gets(this.rachatModel.formule.data.typeFormule);
    } else {
      console.log('formuleFormChange vide');
      this.formuleTypeFormule = null;
      delete this.rachatModel.formule;
    }
    delete this.rachatModel.montant;
    this.cleanCommentaireExterne();
    this.setCommentaireExternebyFormule();
  }
  setConditionByApporteur() {
    console.log('setConditionByApporteur : ' + this.perimetre.apporteur);
    if (this.perimetre.apporteur) {
      console.log('condition select OK');

      const apporteurId = this.perimetre.apporteur;
      this.rachatService
        .getCondition(apporteurId)
        .subscribe(
          resultat => {
            const condition = Global.gets(resultat.content.conditions) as ConditionRachatInfo[];
            const conditionTabTemp = _.orderBy(condition, ['libelle'], ['asc']
              ).map(cat => new ModelOption(cat.libelle, cat.id, cat));
            this.conditionListOption = conditionTabTemp;
            this.reInitConditionByApporteur();
          },
          err => {
            console.log('setConditionByApporteur Error Subscribe');
          }
        );
    } else {
      console.log('setFormuleByCondition No perimetre.apporteur');
    }
  }

  setFormuleByCondition() {
    console.log('setFormuleByCondition');
    console.log('setConditionByApporteur : ' + this.perimetre.apporteur);
    if (this.rachatModel.condition && this.rachatModel.condition.value) {
      console.log('formule select OK');
      const conditionId = Global.gets(this.rachatModel.condition.value);
      this.rachatService
        .getFormule(conditionId)
        .subscribe(
          resultat => {
            const formules = Global.gets(resultat.content) as FormuleInfo[];
              const formuleTabTemp = _.orderBy(formules, ['libelle'], ['asc']
              ).map(cat => new ModelOption(cat.libelle, cat.id, cat));
              this.formuleListOption = formuleTabTemp;
              this.reInitFormuleByCondition();
          },
          err => {
            console.log('setFormuleByCondition Error Subscribe');
          }
        );
    } else {
      console.log('setFormuleByCondition No rachatModel.condition');
    }
  }

  setCommentaireExternebyFormule() {
    console.log('setCommentaireExternebyFormule');
    if (this.rachatModel.formule && this.rachatModel.formule.data &&
      this.rachatModel.formule.data) {
      console.log('commentaireExterne textearea OK');
      this.rachatModel.commentaireExterne = this.rachatModel.formule.data.commentaireExterne;
    } else {
      console.log('setFormuleByCondition No rachatModel.formule');

    }

  }

  reInitConditionByApporteur() {
    console.log('reInitConditionByApporteur : ' + this.conditionListOption.length);
    if (this.conditionListOption.length === 0) {
      this.conditionDisabled = true;
    }
    if (this.conditionListOption.length === 1) {
      this.conditionDisabled = true;
      this.conditionPreset = this.conditionListOption[0].value;
      console.log(this.conditionPreset);
    }
    if (this.conditionListOption.length > 1) {
      this.conditionDisabled = false;
    }
   /* this.conditionListOption.unshift(
      new ModelOption(this.translateService.instant('RACHAT.FORM.FIELDS.CONDITION_PLACEHOLDER'), '')); */
  }

  reInitFormuleByCondition() {
    console.log('reInitFormuleByCondition : ' + this.formuleListOption.length);
    if (this.formuleListOption.length === 0) {
      this.formuleDisabled = true;
    }
    if (this.formuleListOption.length === 1) {
      this.formuleDisabled = false;
     // this.formuleDisabled = true;
     // this.formulePreset = this.formuleListOption[0].value;
    }
    if (this.formuleListOption.length > 1) {
      this.formuleDisabled = false;
    }
   this.formuleListOption.unshift(
      new ModelOption(this.translateService.instant('RACHAT.FORM.FIELDS.FORMULE_PLACEHOLDER'), null));
  }

  cleanCondition() {
    this.conditionDisabled = true;
    this.conditionListOption = [];
    this.conditionValue = null;
    delete this.rachatModel.condition;
  }

  cleanFormule() {
    this.formuleDisabled = true;
    this.formuleListOption = [];
    this.formuleValue = null;
    delete this.rachatModel.formule;
  }

  cleanCommentaireExterne() {
    delete this.rachatModel.commentaireExterne;
  }

  getDateEcheanceRachat(event) {
    const date = Number(event.datetime);
    if (date > 0) {
      this.rachatDemandeForm.controls['echeanceRachat'].setValue(date);
      this.rachatModel.echeanceRachat = date;
    } else {
      this.rachatDemandeForm.controls['echeanceRachat'].setValue(0);
      this.rachatDemandeForm.controls['echeanceRachat'].markAsTouched();
      this.rachatDemandeForm.controls['echeanceRachat'].markAsDirty();
      this.rachatModel.echeanceRachat = 0;
    }
    console.log('getDateEchangeRachat : ' + this.rachatModel.echeanceRachat);
  }

  getDateValidite(event) {
    const date = Number(event);
    if (date > 0) {
      this.rachatDemandeForm.controls['dateValidite'].setValue(date);
      this.rachatModel.dateValidite = date;
    } else {
      this.rachatDemandeForm.controls['dateValidite'].setValue(0);
      this.rachatDemandeForm.controls['dateValidite'].markAsTouched();
      this.rachatDemandeForm.controls['dateValidite'].markAsDirty();
      this.rachatModel.dateValidite = 0;
    }
    console.log('getDateValidite : ' + this.rachatModel.dateValidite);
  }

  validate(c?: AbstractControl): Observable<ValidationErrors> {
    // check des autres erreurs comme required
    if (this.rachatDemandeForm) {
      return this.validateRachat();
    }
    return new Observable();
  }

  validateRachat() {
    return new Observable<ValidationErrors>(observer => {
      this.validatorHandler();
    });
  }

  validatorHandler(recall?: number) {
    const current = new Date().getTime();
    if (!recall) {
      this.lastCall = current;
    }
    if (
      recall &&
      recall === this.lastCall &&
      this.isAlready(this.waitingTime)
    ) {
      if (this.duplicatedCalls(recall)) {
        return new Observable();
      }
      this.lastRecall = recall;
      this.isAbouttoValidate = false;
      const data = new RachatDemandeValidation(this.rachatModel);
      console.log(JSON.stringify(data));
      this.validate$ = this.rachatService
        .AsyncValidatorRachat(data)
        .subscribe(
          res => {
            console.log('Validation Demande Rachat Successful');
            this.validationError = null;
            return null;
          },
          err => {
            console.log(err);
            let errorMessages = null;
            if (err && err.error) {
                console.log(err.error.message);
               errorMessages = JSON.parse(err.error.message);

            }
            this.validationError = errorMessages;
            return errorMessages;
          }
        );
    } else {
      setTimeout(() => {
        this.isAbouttoValidate = true;
        this.validatorHandler(current);
      }, this.waitingTime);
    }
  }
  isAlready(time: number): boolean {
    return new Date().getTime() - this.lastCall >= time;
  }
  duplicatedCalls(recall) {
    return Math.abs(this.lastRecall - recall) < 100;
  }

  async submitRachatDemande(s) {
    this.formSubmitted = true;
    this.resultNumeroAffaire = null;
    if (!this.isReadyForSubmit()) {
      this.openSnack(
        this.translateService.instant('RACHAT.FORM.ERROR.NOT_READY_FOR_SUBMIT'),
        '',
        2000
      );
      return;
    }
    this.waiting = true;
    console.log(JSON.stringify(this.rachatModel));
    console.log(JSON.stringify(new RachatDemandeValidation(this.rachatModel)));
   // return;
    const data = new RachatDemandeValidation(this.rachatModel);
    this.postRachatDemande$ = this.rachatService
      .postRachatDemande(
        data
      )
      .subscribe(
        res => {
        this.waiting = false;
        const idDemandeRachat = res.content.id;
        // console.log('N° Demande RAchat : ' + idDemandeRachat);

         const dialogRef = this.dialog.open(RachatWaitdialogComponent, {
          data: {
            type : 'rachatDemandeSuccess',
            idRachatDemande : idDemandeRachat
          }
        });
        dialogRef.beforeClose().subscribe(result => {
          if (data.numeroContrat) {
            this.router.navigate(['dossier/parc_' + data.numeroContrat + '/suivi/']);
          } else {
            this.router.navigate(['/']);
          }
        });

/*
         const criteres: CriteresRechercheRachatVo = {};
         criteres.apporteur = <number>this.rachatModel.perimetre.apporteur;
         criteres.vendeurs = [{id: <string>this.rachatModel.perimetre.vendeur} as VendeurId];
         criteres.referenceRachat = idDemandeRachat;
         this.rachatService
           .search(criteres)
           .subscribe(
             res2 => {
              this.waiting = false;
              const results = res2.content.rachats as RachatVo[];
              if (results[0] && results[0].infoAffaire && results[0].infoAffaire.numeroAffaire) {
                this.resultNumeroAffaire = results[0].infoAffaire.numeroAffaire;
                console.log('N° Affaire : ' + this.resultNumeroAffaire);
              } else {
                console.log('Le numéro affaire n existe pas');
              }
              const dialogRef = this.dialog.open(RachatWaitdialogComponent, {
                data: {
                  type : 'rachatDemandeSuccess',
                  idRachatDemande : idDemandeRachat
                }
              });
              dialogRef.beforeClose().subscribe(result => {
                if (this.resultNumeroAffaire) {
                  this.router.navigate(['dossier/parc_' + this.resultNumeroAffaire + '/suivi/']);
                } else {
                 // this.router.navigate(['/']);
                }
              });
             },
             err => {
              console.log('erreur rachatService/search');
             });
*/
        },
        err => {
          console.log('erreur rachatService/postRachatDemande');
          this.waiting = false;
          if (err.error && err.error.message) {
            try {
              const errorMessages = JSON.parse(err.error.message);
              this.validationError = errorMessages;

              this.openSnack(
                this.translateService.instant('RACHAT.FORM.ERROR.ERROR_DURING_SUBMIT'),
                '',
                2000
              );
            } catch (e) {
              this.openSnack(
                this.translateService.instant('RACHAT.FORM.ERROR.' + err.error.message)
                , '', 5000);
            }
          } else {
            this.openSnack(
              this.translateService.instant('RACHAT.FORM.ERROR.' + err.message)
              , '', 5000);
          }
        }
      );
  }

  getFormGroup() {
    return this.rachatDemandeForm;
  }

  getDateTime() {
    const date = new Date();
    date.setDate(1);
    return Number(date.getTime());
  }

  isError(field: string) {
    return this.isValidateServerError(field) /*|| this.isFormError(field)*/;

  }

  isFormError(field: string) {
    if (field === 'dateValidite' && !this.rachatModel.formule) {
      return false;
    }
    if (field === 'montant' && this.formuleTypeFormule !== 'RCE') {
      return false;
    }

  if (
      this.rachatDemandeForm.controls[field].invalid &&
      (
        this.rachatDemandeForm.controls[field].touched ||
      //  this.rachatDemandeForm.controls[field].dirty ||
        this.formSubmitted)
    ) {
      return true;
    }
    return false;
  }

  isValidateServerError(field: string) {
    if (field === 'numeroContrat') {
    // console.log('touched : ' + this.rachatDemandeForm.controls[field].touched);
    // console.log('dirty : ' + this.rachatDemandeForm.controls[field].dirty);
    }
    if (
      this.validationError &&
      this.validationError[field] &&
     // this.rachatModel[field] &&
      ( this.rachatDemandeForm.controls[field].touched ||
      //  this.rachatDemandeForm.controls[field].dirty ||
        this.formSubmitted)
    ) {
      return true;
    }
    return false;
  }

  getValidateServerError(field: string, prefix = '') {
    if (this.validationError && this.validationError[field]) {
      return 'RACHAT.FORM.ERROR.' + prefix + field + this.validationError[field];
    } else {
      return ;
    }
  }

  isReadyForSubmit(): boolean {
    let isReady = true;
    Object.keys(this.rachatDemandeForm.controls).forEach(field => {
      const el = this.rachatDemandeForm.get(field);
      if (field === 'dateValidite' && !this.rachatModel.formule) {
       // console.log('Do not need dateValidite');
      } else if (field === 'montant' && this.formuleTypeFormule !== 'RCE') {
       // console.log('Do not need montant');
      } else if (el.errors) {
        isReady = false;
      }
    });
    return isReady;
  }
  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
}
