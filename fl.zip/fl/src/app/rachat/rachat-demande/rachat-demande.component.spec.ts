import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RachatDemandeComponent } from './rachat-demande.component';

describe('RachatDemandeComponent', () => {
  let component: RachatDemandeComponent;
  let fixture: ComponentFixture<RachatDemandeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RachatDemandeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RachatDemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
