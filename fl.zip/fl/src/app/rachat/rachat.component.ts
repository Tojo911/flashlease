import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormBuilder,
  FormGroup,
  Validators,
  AsyncValidatorFn,
  AsyncValidator,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';


@Component({
  selector: 'app-rachat',
  templateUrl: './rachat.component.html',
  styleUrls: ['./rachat.component.scss']
})
export class RachatComponent implements OnInit {
  rachatDemandeForm: FormGroup;
  constructor(private fb: FormBuilder) {


  }

  ngOnInit() {
    this.rachatDemandeForm = this.fb.group({
      numeroContrat: new FormControl({value: 'tetst'}, Validators.required)
    });
  }

}
