import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SirenFormatter } from '../../classes/inputFormatter/sirenFormatter';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CritereRechercheInfo } from '../../models/critere-recherche-info';
import {
  CriteresRechercheRachatVo,
  RachatVo,
  VendeurId
} from '../../models/ddf';
import { RachatService } from '../../services/rachat/rachat.service';
import Global from '../../models/global-functions';
import { DossierInfo } from '../../models/dossier-info';
import { TableColumnDefinitionModel } from '../../models/table-column-definition-model';
import { CustomSearch } from '../../shared/components/phase-data-list/CustomSearch';
import { ModelOption } from '../../models/option-model';
import { DatePipe } from '@angular/common';
import { MatSnackBarConfig, MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-recherche-rachat',
  templateUrl: './recherche-rachat.component.html',
  styleUrls: ['./recherche-rachat.component.scss']
})
export class RechercheRachatComponent implements OnInit {
  sirenFormatter = new SirenFormatter();
  tableColumns: TableColumnDefinitionModel[];
  customSearch: CustomSearch;
  status: ModelOption[];
  columnDefined = false;
  datasource: any[];
  constructor(
    private translateService: TranslateService,
    private router: Router,
    private rachatService: RachatService,
    private datePipe: DatePipe,
    private snackBar: MatSnackBar
  ) {
    this.customSearch = new CustomSearch(
      this.rachatSearchObservable,
      this.rachatCallBackfn
    );
    // definition du service à appeler par le composant de recherche
    this.customSearch.params = { service: this.rachatService };
    this.rachatService.getStatus().subscribe(res => {
      this.status = res.content.statuts.map(
        it => new ModelOption(it.libelle, it.code, it)
      );
      this.tableColumns = !this.columnDefined
        ? this.columnsDef()
        : this.tableColumns;
      this.columnDefined = true;
    });
  }

  ngOnInit() {
    /*this.translateService
      .get('HOME.TABLE.COLUMNS.DEMANDE_RACHAT')
      .subscribe(it => {
        this.tableColumns = !this.columnDefined ? this.columnsDef() : this.tableColumns;
        this.columnDefined = true;
      });*/
  }

  columnsDef() {
    return [
      {
        columnDef: 'onclick',
        header: '',
        sort: false,
        type: true,
        onclick: (row: RachatVo) => this.parcDetail(row),
        cell: (row: RachatVo) => 'visibility'
      },
      {
        columnDef: 'perimetre',
        hide: true,
        cell: (row: RachatVo) => '',
        requestable: {
          isPerimetre: true
        }
      },
      {
        columnDef: 'DemandeRachat',
        sort: true,
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.DEMANDE_RACHAT'
        ),
        cell: (row: RachatVo) => row.referenceRachat,
        requestable: {
          controlName: 'demandeRachat',
          placeholder: 'HOME.TABLE.COLUMNS.DEMANDE_RACHAT'
        }
      },
      {
        columnDef: 'apporteur',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.APPORTEUR'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: RachatVo) => row.vendeur.agence.apporteur.libelle
      },
      {
        columnDef: 'vendeur',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.VENDEUR'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: RachatVo) => row.vendeur.nom + ' ' + row.vendeur.prenom
      },
      {
        columnDef: 'raisonSocial',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: RachatVo) => row.raisonSocialeClient
      },
      {
        columnDef: 'Numaffaire',
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_AFFAIRE'),
        cell: (row: RachatVo) => row.infoAffaire.numeroAffaire,
        requestable: {
          controlName: 'affaire',
          placeholder: 'HOME.TABLE.COLUMNS.NUM_AFFAIRE'
        }
      },
      {
        columnDef: 'statut',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUT'),
        sort: true,
        cell: (row: RachatVo) => row.statut.libelle,
        requestable: {
          isMonoSelect: true,
          controlName: 'statut',
          possibleValues: this.status,
          placeholder: 'HOME.TABLE.COLUMNS.STATUT'
        }
      },
      {
        columnDef: 'numSiren',
        sort: true,
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: RachatVo) => this.sirenFormatter.transform(row.sirenClient),
        requestable: {
          isInput: true,
          controlName: 'numeroSIREN',
          placeholder: 'HOME.TABLE.COLUMNS.NUM_SIREN',
          isNumeric: true,
          format: new SirenFormatter(),
          maxLength: 9
        }
      },
      {
        columnDef: 'recule',
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.DATE_CREATION_RACHAT'
        ),
        sort: true,
        date: true,
        cell: (row: RachatVo) => row.dateReception
      },
      {
        columnDef: 'dateRachat',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.DATE_RACHAT'),
        cell: (row: RachatVo) =>
          this.datePipe.transform(row.dateRachat, 'MM/yyyy'),
        requestable: {
          isDateRange: true,
          controlName: 'dateRachat',
          placeholder: 'HOME.TABLE.COLUMNS.DATE_CREATION_RACHAT'
        }
      }
    ] as TableColumnDefinitionModel[];
  }
  parcDetail(event: RachatVo) {
    if (event.infoAffaire && event.infoAffaire.numeroAffaire) {
      this.router.navigate([
        `dossier/parc_${event.infoAffaire.numeroAffaire}/suivi/rachat/${
          event.referenceRachat
        }`
      ]);
    } else {
      console.error('Dossier non trouvé');
    }
  }

  rachatSearchObservable(
    ref: CustomSearch,
    crit: CritereRechercheInfo
  ): Observable<any> {
    const criteres: CriteresRechercheRachatVo = {};
    criteres.vendeurs = Global.getA(crit.vendeurs).map(t => {
      return {
        id: t
      } as VendeurId;
    });
    criteres.marche = crit.idMarche ? Number(crit.idMarche) : criteres.marche;
    criteres.agence = crit.idAgence ? Number(crit.idAgence) : null;
    criteres.apporteur = crit.idApporteur ? Number(crit.idApporteur) : null;
    criteres.dateCreationMin = crit.dateRachatMin
      ? crit.dateRachatMin + ''
      : null;
    criteres.dateCreationMax = crit.dateRachatMax
      ? crit.dateRachatMax + ''
      : null;
    criteres.numeroAffaire = crit.numAffaire ? crit.numAffaire : null;
    criteres.raisonSocialeClient = crit.raisonSociale
      ? crit.raisonSociale
      : null;
    criteres.statut = crit.statutRachat ? crit.statutRachat : null;
    criteres.sirenClient = crit.numeroSIREN ? crit.numeroSIREN + '' : null;
    criteres.referenceRachat = crit.demandeRachat
      ? Number(crit.demandeRachat)
      : null;

    // criteres = Global.cleanObjectJson(criteres);

    if (ref && ref.params && ref.params.service && ref.params.service.search) {
      return ref.params.service.search(criteres);
    } else {
      console.error('Configuration du WS incorrecte');
      return null;
    }
  }
  rachatCallBackfn(ref: CustomSearch, cb): any {
    cb.ref.datasource = Global.getA(cb.res.content.rachats);
    if (cb.res.content.rachats.length > 100) {
      cb.ref.openSnack( cb.ref.translateService.instant('HOME.TABLE.BIG_RESULT'), '', 5000);
    }
    cb.ref.showSpinner = false;
    cb.ref.loading = false;
  }
  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
}
