import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RechercheRachatComponent } from './recherche-rachat.component';

describe('RechercheRachatComponent', () => {
  let component: RechercheRachatComponent;
  let fixture: ComponentFixture<RechercheRachatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RechercheRachatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RechercheRachatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
