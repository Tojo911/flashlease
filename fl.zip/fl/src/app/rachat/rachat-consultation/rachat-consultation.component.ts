import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter
} from '@angular/core';
import {
  RachatDDFInfo,
  RachatVo,
  BlocAffaireVo,
  OffreRachatVo,
  VendeurVo,
  DiffusionRachat
} from '../../models/ddf';
import { Dossier } from '../../dossier/dossier-bloc/dossier-bloc.component';
import { TableColumnDefinitionModel } from '../../models/table-column-definition-model';
import { TranslateService } from '@ngx-translate/core';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { RachatService } from '../../services/rachat/rachat.service';
import Global from '../../models/global-functions';
import { AuthService } from '../../services/auth/auth.service';
import { MatDialog, MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { DossierWaitdialogComponent } from '../../dossier/dossier-waitdialog/dossier-waitdialog.component';
import { ModelOption } from '../../models/option-model';
import { duration } from 'moment';

@Component({
  selector: 'app-rachat-consultation',
  templateUrl: './rachat-consultation.component.html',
  styleUrls: ['./rachat-consultation.component.scss']
})
export class RachatConsultationComponent implements OnInit, OnChanges {
  @Input()
  idRachat: string;
  rachatContent: Dossier[];
  isDownloading;
  @Input()
  rachat: RachatVo;
  @Output()
  rachatChange: EventEmitter<any> = new EventEmitter<any>();
  nbColumns = 4;
  formatNumber = new AmountFormatter();
  columnsAffaires: TableColumnDefinitionModel[];
  columnsDestinataires: TableColumnDefinitionModel[];
  columnsRachat: TableColumnDefinitionModel[];
  affaires = [{}];
  destinataires = [{}];

  constructor(
    public transServ: TranslateService,
    private rachatService: RachatService,
    private authservice: AuthService,
    private dialog: MatDialog,
    public snackBar: MatSnackBar
  ) {
    this.transServ.get('RACHAT.TABLE.COLUMNS.DATE').subscribe(it => {
      this.columnsAffaires = this.buildColumnsAffaires();
      this.columnsDestinataires = this.buildColumnsDestinataires();
    });
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.rachat) {
      this.refresView();
    }
    if (changes.idRachat) {
      this.updateRachat();
    }
  }

  updateRachat(rachat?: RachatVo) {
    if (rachat) {
      this.rachat = rachat;
      this.refresView();
    } else {
      this.rachatService.getRachat(this.idRachat).subscribe(res => {
        this.rachat = res.content;
        this.refresView();
      });
    }
  }
  refresView() {
    this.affaires = this.rachat.offresRachat;
    this.rachatContent = [
      this.buildInfosGenerales(),
      this.buildAffaire(),
      this.buildFormuleRachat(),
      this.buildDestinataire()
    ] as Dossier[];
    this.rachatChange.emit(this.rachat);
  }
  ngOnInit() {}

  buildInfosGenerales() {
    const infos = Global.gets(this.rachat) as RachatVo;
    const dossier = this.build('Informations Générales', [
      this.set('Date de rachat', infos.dateRachatAff),
      this.set('Gestionnaire de saisie', Global.gets(infos.vendeur).nom),
      this.set('Date de réception', infos.dateReception, { isDate: true }),
      this.set('Statut courant', Global.gets(infos.statut).libelle),
      this.set('Commentaire', infos.commentaire)
    ]);
    return dossier;
  }
  buildAffaire() {
    const affaire = Global.gets(this.rachat.infoAffaire) as BlocAffaireVo;
    const dossier = this.build(
      'Affaire ' + Global.gets(affaire.numeroAffaire),
      [
        this.set('Produit financier', affaire.produitFinancier),
        this.set('Terme', affaire.terme),
        this.set('Référence risque', affaire.referenceRisque + ' '),
        this.set('Référence Externe', affaire.referenceExterne)
      ]
    );
    dossier.list.push(this.set(null, null, { custom: true }));
    return dossier;
  }
  buildFormuleRachat() {
    const formule = Global.gets(this.rachat) as RachatVo;
    return this.build(
      'Formule de rachat',
      [
        this.set('Libellé', formule.libelleFormuleRachat),
        this.set('Type de formule', formule.typeFormuleRachat)
      ],
      null,
      { hide: !this.authservice.isInterne() }
    );
  }
  buildDestinataire() {
    const vendeur = Global.gets(this.rachat.vendeur) as VendeurVo;
    const dest = this.rachat;
    const dossier = this.build('Destinataire', [
      this.set('Apporteur', Global.gets(vendeur.agence).apporteur),
      this.set('Agence', vendeur.agence),
      this.set('Adresse mail', vendeur.mail),
      this.set('Fax', vendeur.fax),
      this.set('Apporteur/Societe', dest.societeDestinataire),
      this.set('Agence/Ville', dest.agenceVilleDestinataire),
      this.set('Destinataire', dest.destinataire),
      this.set('Adresse mail', dest.mailDestinataire),
      this.set('Fax', dest.faxDestinataire)
    ]);
    // dossier.list.push(this.set(null, null, { custom: true }));
    return dossier;
  }
  buildHistoriqueDestinataire() {
    // this.columnsDestinataires = this.buildColumnsDestinataires();
    return this.bloc('Historique des destinataires', [
      this.set(null, null, { custom: true })
    ]);
  }
  set(title, value, suffix?): Dossier {
    return Dossier.set(title, value, suffix) as Dossier;
  }
  build(title, list, multi?, custom?) {
    return Dossier.build(title, list, multi, custom) as Dossier;
  }
  bloc(title, list) {
    return {
      value: null,
      title: title,
      list: list
    } as Dossier;
  }
  buildColumnsAffaires() {
    return [
      {
        columnDef: 'Avant l’échéance de',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.AVT_ECHEANCE'),
        date: true,
        cell: (row: OffreRachatVo) => row.dateRachat
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.MONTANT_HT'),
        cell: (row: OffreRachatVo) => this.formatNumber.transform(row.montantHT)
      },
      {
        columnDef: 'montant à régler',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.MONTANT_A_REGLER'),
        cell: (row: OffreRachatVo) =>
          this.formatNumber.transform(row.montantTTC)
      },
      {
        columnDef: 'Ancienneté',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.ANCIENNETE'),
        cell: (row: OffreRachatVo) => row.anciennete + ' mois'
      },
      {
        columnDef: 'duree restante',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.DUREE_RESTANTE'),
        cell: (row: OffreRachatVo) => row.dureeRestante + ' mois'
      },
      {
        columnDef: 'date validite',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.DATE_VALIDITE'),
        date: true,
        cell: (row: OffreRachatVo) => row.dateValidite
      }
    ] as TableColumnDefinitionModel[];
  }
  buildColumnsDestinataires() {
    return [
      {
        columnDef: 'Date',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.DATE'),
        date: true,
        cell: (row: any) => new Date().getTime()
      },
      {
        columnDef: 'Vendeur',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.VENDEUR'),
        cell: (row: any) => this.formatNumber.transform('Vendeur')
      },
      {
        columnDef: 'Destinataires',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.DESTINATAIRES'),
        cell: (row: any) => this.formatNumber.transform('Destinataires')
      }
    ] as TableColumnDefinitionModel[];
  }

  openWaitDialogActions(): void {
    console.log('openWaitDialogActions DDF');
    const dialogRef = this.dialog.open(DossierWaitdialogComponent, {
      width: '700px',
      data: {
        type: 'mailDestianatiares'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result as ModelOption[]) {
        console.log('closeWaitDialogActions : submit');
        const req = new DiffusionRachat(
          this.rachat.referenceRachat,
          result.map(it => it.libelle)
        );
        this.rachatService.diffuse(req).subscribe(
          res => {
            console.log(res);
          },
          err => {
            console.log(err);
            // tslint:disable-next-line:max-line-length
            this.openSnack(
              this.transServ.instant(
                'SUIVI.WAITDIALOG.CHANGEMENT_STATUT_COMMERCIAL.SNACK.ERROR'
              )
            );
          }
        );
        // this.ddf$ = this.ddfService.setStatusCommerciauxAutorises(this.numDoss).subscribe(
        //  this.ddf$ = this.ddfService.getStatusCommerciauxAutorises(this.numDoss).subscribe(
      } else {
        console.log('closeWaitDialogActions : cancel');
      }
    });
  }
  downloadPdf() {
    if (this.isDownloading) {
      this.openSnack(
        this.transServ.instant(
          'RACHAT.ACTIONS.UPLOADING'
        )
      );
    }
    this.isDownloading = true;
    this.rachatService.pdf(this.rachat.referenceRachat).subscribe(
      res => {
        const blob = new Blob([res.content], { type: 'application/pdf' });
        const filename = `rachat${this.rachat.referenceRachat}.pdf`;
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, filename);
        } else {
          const objectUrl = URL.createObjectURL(blob);
          window.open(objectUrl);
        }
        this.isDownloading = false;
      },
      err => {
        this.isDownloading = false;
        this.openSnack(
          this.transServ.instant(
            'SUIVI.WAITDIALOG.CHANGEMENT_STATUT_COMMERCIAL.SNACK.ERROR'
          )
        );
      }
    );
  }
  openSnack(msg) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = 2000;
    this.snackBar.open('Erreur', msg, mtConfig);
  }
}
