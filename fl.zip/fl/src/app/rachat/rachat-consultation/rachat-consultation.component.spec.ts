import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RachatConsultationComponent } from './rachat-consultation.component';

describe('RachatConsultationComponent', () => {
  let component: RachatConsultationComponent;
  let fixture: ComponentFixture<RachatConsultationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RachatConsultationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RachatConsultationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
