import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth/auth.service';
import { environment } from '../../../environments/environment';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogBoxComponent } from '../../shared/components/dialog-box/dialog-box.component';
import { ExportService } from '../../services/export/export.service';

@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html',
  styleUrls: ['./app-footer.component.scss']
})
export class AppFooterComponent implements OnInit {
  appVersion: string;
  constructor(public dialog: MatDialog, public exportService: ExportService) {
    this.appVersion = environment.version;
  }

  openMentionsLegales(): void {
    const url = '../../../flashlease/assets/documents/2018-12-20-mentions-legales-flashlease.pdf';
    this.exportService.downloadFile(url).subscribe(
      res => {
      const blob = new Blob([res.data], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(blob);
     // window.open(fileURL);
      const filename = 'mentions-legales-flashlease.pdf';
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, filename);
      } else {
        const objectUrl = URL.createObjectURL(blob);
        window.open(objectUrl);
      }
      }
    );


  }

openCharte(): void {
  const url = '../../../flashlease/assets/documents/2018-11-13-charte-de-protection-des-donnees-personnelles-de-Franfinance.pdf';
  this.exportService.downloadFile(url).subscribe(
    res => {
    const blob = new Blob([res.data], {type: 'application/pdf'});
    const fileURL = URL.createObjectURL(blob);
   // window.open(fileURL);
    const filename =  'charte-de-protection-des-donnees-personnelles-de-Franfinance.pdf';
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, filename);
    } else {
      const objectUrl = URL.createObjectURL(blob);
      window.open(objectUrl);
    }
    }
  );
}

  ngOnInit() {}
  isProd() {
    return environment.env === 'prod';
  }
}
