import {
  Component,
  OnInit,
  forwardRef,
  EventEmitter,
  Output
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  DefaultValueAccessor
} from '@angular/forms';
import { MatDialog, MatDialogConfig, MatSnackBar } from '@angular/material';
import * as _ from 'lodash';
import { ModelOption } from '../../../models/option-model';
import { SearchDialogComponent } from './search-dialog/search-dialog.component';
import { Router, NavigationExtras } from '@angular/router';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { Observable, of } from 'rxjs';
import { DossierInfo } from '../../../models/dossier-info';
import { map, catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-flash-search',
  templateUrl: './flash-search.component.html',
  styleUrls: ['./flash-search.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DefaultValueAccessor),
      multi: true
    }
  ]
})
export class FlashSearchComponent implements OnInit, ControlValueAccessor {
  activated = false;
  blurEnable = true;
  uniqueCriteria = new ModelOption(null, null, null); // ??? why type is ModelOption
  onChange: () => any;
  onTouched: () => any;
  @Output()
  emptySearchResultEvent: EventEmitter<any> = new EventEmitter<any>();
  public emptyResult = false;
  search = true;
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private rechercheService: RechercheService,
    private translateService: TranslateService

  ) {}

  ngOnInit() {}

  select(current: ModelOption) {
    this.writeValue(current);
  }

  activateSearch() {
    this.activated = true;
  }

  writeValue(obj: ModelOption): void {}

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  eject() {
    this.activated = false;
  }

  redirectToResultPage(expectedUrl: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '400px';
    dialogConfig.height = '270px';
    dialogConfig.data = {
      title: 'voulez vous quitter la demande de financement ?'
    };
    this.blurEnable = false;
    const dialogRef = this.dialog
      .open(SearchDialogComponent, dialogConfig)
      .afterClosed()
      .subscribe((result?: boolean) => {
        this.blurEnable = true;
        if (result) {
          this.activated = false;
          this.uniqueCriteria = new ModelOption(null, null, null);
        } else {
          this.router.navigate([expectedUrl]);
        }
      });
    return;
  }

  quickRequest() {
    this.search = false;
    if (this.uniqueCriteria.value === null) {
      this.search = true;
      return null;
    }

    this.rechercheService
      .quickSearch(this.uniqueCriteria.value)
      .pipe(map(res => res.content.dossiers as DossierInfo[]))

      .subscribe(
        (res: DossierInfo[]) => {

          this.search = true;
          if (res.length === 0) {
            this.emptySearchResultEvent.emit(this.translateService.instant('ADVANCED_SEARCH.NO_RESULT'));
          } else {
            if (res.length === 1) {
              // send quick search by Num dossier
              this.sendQuickSearchByDossierRequest();
            }

            // else {
            // send and save resultBy SIREN Result
            // this.rechercheService.sendStorage('je suis la');
            //  this.sendQuickSearchBySirenRequest(); // send quick search by Num siren
            // }
          }
        },
        (err: HttpErrorResponse) => {
          this.search = true;
          this.emptySearchResultEvent.emit(this.translateService.instant('ADVANCED_SEARCH.ERROR'));
        }
      );
  }

  sendQuickSearchByDossierRequest() {
    const resultSearchtUrl =
      'dossier/ddf_' + this.uniqueCriteria.value + '/suivi/';
    if (this.router.url === '/ddf') {
      this.redirectToResultPage(resultSearchtUrl);
    } else {
      this.router.navigate([resultSearchtUrl]);
    }
  }

  // SIREN in next Release
  sendQuickSearchBySirenRequest() {
    const resultSearchtUrl = '/resultats-recherche';
    if (this.router.url === '/ddf') {
      this.redirectToResultPage(resultSearchtUrl);
    } else {
      this.router.navigate([resultSearchtUrl]);
    }
  }

  onBlur($e: any) {
    if (this.blurEnable && this.search) {
      this.uniqueCriteria = new ModelOption(null, null, null);
      // this.reset();
    }
  }
}
