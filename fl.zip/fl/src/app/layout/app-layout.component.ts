import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { AuthService } from '../services/auth/auth.service';

import { DdfNotificationComponent } from '../ddf/ddf-notification/ddf-notification.component';
import { DdfPageComponent } from '../ddf/ddf-page/ddf-page.component';
import { DdfService } from '../services/ddf/ddf.service';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-layout',
  templateUrl: './app-layout.component.html',
  styleUrls: ['./app-layout.component.scss']
})
export class AppLayoutComponent implements OnInit {
  displayheader = false;
  model: any = {};
  isAuthorizedDDf: boolean;
  public hasDashDdfRole = false;
  public hasDashMontageRole = false;
  public hasDashParcRole = false;
  public hasRachatRechRole = false;
  public hasRachatCreaRoleNonRenouvelant = false;
  public hasRachatCreaRole = false;
  constructor(
    private authService: AuthService,
    private ddfService: DdfService,
    private router: Router,
    public dialog: MatDialog
  ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        switch (event.url) {
          case '/login':
            this.displayheader = false;
            break;
          default:
            this.displayheader = true;
        }
      }
    });
    this.isAuthorizedDDf = this.isAuthDdf();
    this.hasDashMontageRole = this.authService.isDashMontage();
    this.hasDashParcRole = this.authService.isDashParc();
    this.hasRachatRechRole = this.authService.isAuthRachatRecherche();
    this.hasRachatCreaRole = this.authService.isAuthRachatCreation();
  }
  isAuthDdf() {
    return this.authService.isAuthDdf();
  }
  ngOnInit() {
    this.model.user = this.authService.getCurrentUser();
  }

  openDdf() {
    this.router.navigate(['/ddf']);
  }

  openDashboradTab(tabIndex) {
    this.ddfService.setDashboardTabIndex(tabIndex);
    this.openPage('');
  }

  openNotifdDdf() {
    const ddfAccRef = this.dialog.open(DdfNotificationComponent, {
      width: '650px'
    });
    ddfAccRef.disableClose = true;
  }

  logout() {
    this.authService.logout();
  }
  openPage(route) {
    this.router.navigate([route]);
  }

  openMonComptePage() {
    this.router.navigate(['/monCompte']);
  }
  prepareRoute(outlet: RouterOutlet) {
    return (
      outlet &&
      outlet.activatedRouteData &&
      outlet.activatedRouteData['animation']
    );
  }
  redirectToRachatRech(sidenav) {
    if (this.hasRachatRechRole) {
      this.router.navigate(['/rachat/recherche']);
      sidenav.close();
    }
  }
  redirectToRachatDemande(sidenav) {
    if (this.hasRachatCreaRole) {
      this.router.navigate(['/rachat/demande']);
      sidenav.close();
    }
  }
}
