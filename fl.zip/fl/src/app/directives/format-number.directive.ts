import { Directive, HostListener, ElementRef, OnInit } from '@angular/core';
@Directive({
  selector: '[appFormatNumber]'
})
export class FormatNumberDirective {
  private el: HTMLInputElement;
  private DECIMAL_SEPARATOR: string;
  private THOUSANDS_SEPARATOR: string;
  private PADDING = '000000';
  constructor(private elementRef: ElementRef) {
    this.el = this.elementRef.nativeElement;
    this.DECIMAL_SEPARATOR = '.';
    this.THOUSANDS_SEPARATOR = ' ';
  }

  /*ngOnInit() {
    this.el.value = this.transform(this.el.value);
  }*/

  @HostListener('change', ['$event.target.value'])
  onFocus(value) {
    this.el.value = this.parse(value); // opossite of transform
  }

  @HostListener('blur', ['$event.target.value'])
  onBlur(value) {
    this.el.value = this.transform(value);
  }

  transform(value: number | string, fractionSize: number = 2): string {
    let [integer, fraction = ''] = (value || '')
      .toString()
      .split(this.DECIMAL_SEPARATOR);

    fraction =
      fractionSize > 0
        ? this.DECIMAL_SEPARATOR +
          (fraction + this.PADDING).substring(0, fractionSize)
        : '';

    integer = integer.replace(
      /\B(?=(\d{3})+(?!\d))/g,
      this.THOUSANDS_SEPARATOR
    );

    return integer + fraction;
  }

  parse(value: string, fractionSize: number = 2): string {
    let [integer, fraction = ''] = (value || '').split(this.DECIMAL_SEPARATOR);

    integer = integer.replace(new RegExp(this.THOUSANDS_SEPARATOR, 'g'), '');

    fraction =
      parseInt(fraction, 10) > 0 && fractionSize > 0
        ? this.DECIMAL_SEPARATOR +
          (fraction + this.PADDING).substring(0, fractionSize)
        : '';

    return integer + fraction;
  }
}
