import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClickedOutsideDirective } from './clicked-outside.directive';
import { IsNumericDirective } from './is-numeric.directive';
import { FormatNumberDirective } from './format-number.directive';
import { IsRightDureeDirective } from './is-right-duree.directive';
import { IsNameDirective } from './is-name.directive';

const list = [
  ClickedOutsideDirective,
  IsNumericDirective,
  ClickedOutsideDirective,
  FormatNumberDirective,
  IsRightDureeDirective,
  IsNameDirective
];

@NgModule({
  imports: [CommonModule],
  declarations: [...list],
  exports: list
})
export class DirectivesModule {}
