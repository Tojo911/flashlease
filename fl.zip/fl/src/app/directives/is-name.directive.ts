import {
  Directive,
  ElementRef,
  Renderer2,
  HostListener,
  Input,
  ViewContainerRef
} from '@angular/core';

@Directive({
  selector: '[appIsName]'
})
export class IsNameDirective {
  regExIsChar = new RegExp('[A-Za-z]');
  regExIsName = new RegExp("^[a-z]+([ \-']?[a-z]+[ \-']?[a-z]+[ \-']?)[a-z]+$");
  component: any;
  nextValue: string;
  isControl = false;
  constructor(private el: ViewContainerRef, private renderer: Renderer2) {

  }

  @HostListener('keydown', ['$event'])
  onkeyup($e: KeyboardEvent) {
    if (!this.regExIsChar.test($e.key) && $e.key !== ' ' && $e.key !== '-' && $e.key !== '.' && !this.isControl) {
      console.log($e.key);
      if (
        ($e.key.length === 1 ||
          $e.key === 'Multiply' ||
          $e.key === 'Subtract' ||
          $e.key === 'Add' ||
          $e.key === 'Divide')
      ) {
        $e.preventDefault();
      }
    }
    if ($e.key !== 'Control' && this.isControl) {
      this.isControl = false;
    }
    if ($e.key === 'Control') {
      this.isControl = true;
      // this.nextValue = document.execCommand('Paste');
    }
  }
  @HostListener('paste', ['$event']) blockPaste(e) {
    const val = e.clipboardData.getData('Text').split(' ').join('');
    if (e.clipboardData && !this.regExIsName.test(val)) {
      e.preventDefault();
    }
  }
}
