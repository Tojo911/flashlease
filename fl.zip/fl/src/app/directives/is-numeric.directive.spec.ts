import { IsNumericDirective } from './is-numeric.directive';

describe('IsNumericDirective', () => {
  it('should create an instance', () => {
    const directive = new IsNumericDirective();
    expect(directive).toBeTruthy();
  });
});
