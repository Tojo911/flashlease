import {
  Directive,
  ElementRef,
  Renderer2,
  HostListener,
  Input
} from '@angular/core';

@Directive({
  selector: '[appIsRightDuree]'
})
export class IsRightDureeDirective {
  @Input()
  duree;
  constructor(private el: ElementRef, private renderer: Renderer2) {}
// FIXME: to be refactored later
  @HostListener('keydown', ['$event'])
  onkeyup($e: KeyboardEvent) {
    if (this.duree && this.duree.toString().length > 4) {
      if (+$e.keyCode !== 8) {
        $e.preventDefault();
      }
    } else {
      return true;
    }
  }
}
