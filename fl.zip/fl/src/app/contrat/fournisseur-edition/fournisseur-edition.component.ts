import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';
import { FormGroup, FormGroupName, FormArray, FormArrayName } from '@angular/forms';
import { ContratModel } from '../../models/contrat-edition';
import { EditionContratComponent } from '../edition-contrat/edition-contrat.component';
@Component({
  selector: 'app-fournisseur-edition',
  templateUrl: './fournisseur-edition.component.html',
  styleUrls: ['./fournisseur-edition.component.scss']
})
export class FournisseurEditionComponent implements OnInit {
  [x: string]: any;
  @Input()
  contratModel = new ContratModel();
  @Input()
  formGroupName: FormGroupName;
  @Input()
  parentForm: FormGroup;
  @Input()
  fournisseursFormGroup: FormGroup;

  @Input()
  idx: number;

  //liste = this.parentForm.get('listFournisseurs');

   @Input()
   myForm: FormGroup;
  constructor( ) { }

  ngOnInit() {

  }
  /*deleteForm() {
    this.EditionContratComponent.removeFournisseur();
  }*/
  removeFournisseur(idx: number) {
    (<FormArray>this.parentForm.get('listFournisseurs')).removeAt(idx);

   /* console.log(this.parentForm.get('listFournisseurs.length'));
    const tab = this.parentForm.get('listFournisseurs') ;
    console.log(tab);
      for ( let i = 0; i < this.tab.length; i++ ) {
        this.idx = tab[i];
        console.log('l index à supprimer ' + this.idx);
    }*/
  }
}
