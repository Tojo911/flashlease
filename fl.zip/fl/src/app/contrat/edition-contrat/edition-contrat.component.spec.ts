import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditionContratComponent } from './edition-contrat.component';

describe('EditionContratComponent', () => {
  let component: EditionContratComponent;
  let fixture: ComponentFixture<EditionContratComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditionContratComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditionContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
