import { Component, OnInit,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
  MaxLengthValidator
} from '@angular/forms';
import { Observable } from 'rxjs';
import {MatRadioModule} from '@angular/material/radio';
import { ContratService } from '../../services/contrat/contrat.service';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { FormArray } from '@angular/forms';
import { ContratModel } from '../../models/contrat-edition';
import { AuthService } from '../../services/auth/auth.service';
import { FournisseurEditionComponent } from '../fournisseur-edition/fournisseur-edition.component';


@Component({
  selector: 'app-edition-contrat',
  templateUrl: './edition-contrat.component.html',
  styleUrls: ['./edition-contrat.component.scss']
})
export class EditionContratComponent implements OnInit {
  contratModel = new ContratModel();
  selectedIndex: number;
  formIndex: number;
  // fournisseurForm: FormArray;

  coordonneesClientFormGroup: FormGroup;
  dirigeantFormGroup: FormGroup;
  signataireFormGroup: FormGroup;
  domiciliationBancaireFormGroup: FormGroup;
  adresseDeFacturationFormGroup: FormGroup;
  fournisseursFormGroup: FormGroup;
  materielsFormGroup: FormGroup;
  lieuDInstallationFormGroup: FormGroup;
  prestationAnnexesAssurancesFormGroup: FormGroup;
  observationsParticulieresFormGroup: FormGroup;
  previsualisationsContratsFormGroup: FormGroup;
  listFournisseurs: FormArray;
  listMateriels: FormArray;

  @ViewChild('listFournisseurs') child: FournisseurEditionComponent;

  constructor(private _formBuilder: FormBuilder, contratService: ContratService, authService: AuthService) {
    this.initEditionContrat();
  }

  ngOnInit() {
  }


  // Initialiser l'édition de contrat
  initEditionContrat() {
    console.log('1. initEditionContrat');
    this.initInformationClient();
    this.initFacturation();
    this.initInformationsComplemtaires();
    /* this.editionContratHandler(); */
    this.initPrevisualisationContrat();
  }

  // Initialiser les formulaires information client
  initInformationClient() {
    console.log('1.1 initInformationClient');
    this.buildCoordonneesClient();
    this.buildDirigeant();
    this.buildSignataire();
  }
  // Initialiser les formulaires facturation
  initFacturation() {
    console.log('2. initFacturation');
    this.buildDomiciliationBancaire();
    this.buildAdresseDeFacturation();
  }
  // Initialiser les formulaires Informations completmentaires
  initInformationsComplemtaires() {
    console.log('3. initInformationsComplemtaires');
    this.buildFournisseurs();
    /*this.addFournisseurToList();*/
    /*this.addMaterielToList();*/
    this.buildMateriels();
    this.buildLieuDinstallation();
    this.buildPrestationAnnexesAssurances();
    this.buildObservationsParticulieres();
  }

  initPrevisualisationContrat() {
    console.log('4. initPrevisualisationContrat');
    this.buildPrevPrevisualiserContrat();
  }
  buildCoordonneesClient() {
    console.log('1.1 buildCoordonnéesClient');
    this.coordonneesClientFormGroup = this._formBuilder.group({
      raisonsociale: ['', { updateOn: 'change', validators: [Validators.required] }],
      siren: ['', { updateOn: 'change', validators: [Validators.required] }],
      adressedusiegesocial: ['', { updateOn: 'change', validators: [Validators.required] }],
      complementdadresse: ['', { updateOn: 'change', validators: [Validators] }],
      codepostal: ['', { updateOn: 'change', validators: [Validators.required] }],
      ville: ['', { updateOn: 'change', validators: [Validators.required] }],
    });
  }

  buildDirigeant() {
    console.log('1.2 buildDirigeant');
    this.dirigeantFormGroup = this._formBuilder.group({
      civilite: ['', { updateOn: 'change' }],
      nom: ['', { updateOn: 'change', validators: [Validators.required] }],
      prenom: ['', { updateOn: 'change', validators: [Validators.required] }],
      datedenaissance: ['', { updateOn: 'change' }],
      lieudenaissance: ['', { updateOn: 'change' }],
      email: ['', { updateOn: 'change', validators: [Validators.email] }],
      telephone: ['', { updateOn: 'change', validators: [Validators.required] }],
    });
  }

  buildSignataire() {
    console.log('1.3 buildSignataire');
    this.signataireFormGroup = this._formBuilder.group({
      civilite: ['', { updateOn: 'change' }],
      nom: ['', { updateOn: 'change', validators: [Validators.required] }],
      prenom: ['', { updateOn: 'change', validators: [Validators.required] }],
      qualite: ['', { updateOn: 'change', validators: [Validators.required] }],
      datedenaissance: ['', { updateOn: 'change' }],
      lieudenaissance: ['', { updateOn: 'change' }],
      email: ['', { updateOn: 'change', validators: [Validators.email] }],
      telephone: ['', { updateOn: 'change' }],
    });
  }
  buildDomiciliationBancaire() {
    console.log('2.1 buildDomiciliationBancaire');
    this.domiciliationBancaireFormGroup = this._formBuilder.group({
      numerocompteiban: ['', { updateOn: 'change', validators: [Validators.required] }],
      bic: ['', { updateOn: 'change', validators: [Validators.required] }],
      nomdelabanque: ['', { updateOn: 'change' }],
      nomdelagence: ['', { updateOn: 'change' }],
      adresse: ['', { updateOn: 'change', validators: [Validators.required] }],
      codepostal: ['', { updateOn: 'change', validators: [Validators.required] }],
      ville: ['', { updateOn: 'change', validators: [Validators] }],
      personneajoindre: ['', { updateOn: 'change' }],
      telephone: ['', { updateOn: 'change' }],
    });
  }
  buildAdresseDeFacturation() {
    console.log('2.2 buildAdresseDeFacturation');
    this.adresseDeFacturationFormGroup = this._formBuilder.group({
      adresse: ['', { updateOn: 'change', validators: [Validators.required] }],
      complementdadresse: ['', { updateOn: 'change' }],
      codepostal: ['', { updateOn: 'change', validators: [Validators.required] }],
      ville: ['', { updateOn: 'change', validators: [Validators.required] }],

    });
  }
  buildLieuDinstallation() {
    console.log('3.3 buildLieuDInstallation');
    this.lieuDInstallationFormGroup = this._formBuilder.group({
      adresse: ['', { updateOn: 'change', validators: [Validators.required] }],
      complementdadresse: ['', { updateOn: 'change' }],
      codepostal: ['', { updateOn: 'change', validators: [Validators.required] }],
      ville: ['', { updateOn: 'change', validators: [Validators.required] }],
    });
  }
  buildPrestationAnnexesAssurances() {
    console.log('3.4 buildPrestationAnnexesAssurances');
    this.prestationAnnexesAssurancesFormGroup = this._formBuilder.group({
      assurancealapersonne: ['', { updateOn: 'change', validators: [Validators.required] }],
      assurancealapersonne_pourcentdumontant: ['', { updateOn: 'change' }],
      assurancealapersonne_montant: ['', { updateOn: 'change' }],
      assurancedommages: ['', { updateOn: 'change' }],
      assurancedommages_pourcentdumontant: ['', { updateOn: 'change' }],
      assurancedommages_montant: ['', { updateOn: 'change' }],
      assurancespertefinanciere: ['', { updateOn: 'change' }],
      assurancespertefinanciere_pourcentdumontant: ['', { updateOn: 'change' }],
      assurancespertefinanciere_montant: ['', { updateOn: 'change' }],
      maintenanceentretien: ['', { updateOn: 'change' }],
    });
  }
  buildObservationsParticulieres() {
    console.log('3.5 buildObservationsParticulieres');
    this.observationsParticulieresFormGroup = this._formBuilder.group({
      observationsparticulieres: ['', { updateOn: 'change' }],
    });
  }

  buildPrevPrevisualiserContrat() {
    console.log('4.1 previsualisationsContratsFormGroup');
    this.previsualisationsContratsFormGroup = this._formBuilder.group({
      previsualisationsContrats: ['', { updateOn: 'change', validators: [Validators] }],
    });
  }
  public selectionChanged(event?: StepperSelectionEvent): void {
    console.log('stepper.selectedIndex: ' + this.selectedIndex
      + '; event.selectedIndex: ' + event.selectedIndex);

    this.selectedIndex = event.selectedIndex;
  }
  public goto(index: number): void {
    console.log('stepper.selectedIndex: ' + this.selectedIndex
      + '; goto index: ' + index);
    this.selectedIndex = index;
  }
/*
methode pour ajouter un nouveau fournisseur
*/
  addFornisseur(): void {
    if (this.listFournisseurs.length < 3) {
      // let item = this.items.length + 1;
      this.addFournisseurToList();
      console.log('Nombre de fournisseurs = ' + this.listFournisseurs.length);
    } else {
      alert('vous ne pouvez pas ajouter plus de 2 fournisseur !');
    }
  }

    /*  Ajouter form */
    addFournisseurToList(): void {
      this.listFournisseurs = this.fournisseursFormGroup.get('listFournisseurs') as FormArray;
      this.listFournisseurs.push(this.createFournisseurForm());
    }
    /* creation du form  */
  createFournisseurForm(): FormGroup {
    return this._formBuilder.group({
      nomdufournisseur: ['', { updateOn: 'change', validators: [Validators.required] }],
      siren: ['', { updateOn: 'change', validators: [Validators.required] }],
      adresse: ['', { updateOn: 'change', validators: [Validators.required] }],
      codepostal: ['', { updateOn: 'change', validators: [Validators.required] }],
      ville: ['', { updateOn: 'change', validators: [Validators.required] }],
      complementdadresse: ['', { updateOn: 'change' }],
    });

  }
  buildFournisseurs() {
    console.log('3.1 buildFournisseurs');
    this.fournisseursFormGroup = this._formBuilder.group({
      listFournisseurs: this._formBuilder.array([]),
    });
    this.addFournisseurToList();

  }

 /* removeFournisseur(idx: number) {
    if ( this.listFournisseurs.length > 1) {
      idx = this.listFournisseurs.length - 1;
      this.listFournisseurs.removeAt(idx);
    }
      console.log('Nombre de fournisseurs = ' + this.listFournisseurs.length);
  }*/

/*
methode pour ajouter un nouveau Materiel
*/
addMateriel(): void {
  if (this.listMateriels.length < 3) {
   // let item = this.items.length + 1;
    this.addMaterielToList();
  } else { alert('vous ne pouvez pas ajouter plus de 2 materiel !'); }
  }

  /*  Ajouter form */
  addMaterielToList(): void {
    this.listMateriels = this.materielsFormGroup.get('listMateriels') as FormArray;
    this.listMateriels.push(this.createMaterielForm());
  }
  /* creation du form  */
  createMaterielForm(): FormGroup {
    return this._formBuilder.group({
      designationdubien: ['', { updateOn: 'change', validators: [Validators.required] }],
      fournisseurdubien: ['', { updateOn: 'change' }],
      type: ['', { updateOn: 'change', validators: [Validators.required] }],
      marque: ['', { updateOn: 'change', validators: [Validators.required] }],
      quantite: ['', { updateOn: 'change', validators: [Validators.required] }],
      etat: ['', { updateOn: 'change' }],
      anneedemiseenservice: ['', { updateOn: 'change' }],
      numerodeserie: ['', { updateOn: 'change' }],
    });

  }
  buildMateriels() {
    console.log('3.2 buildMateriels');
    this.materielsFormGroup  = this._formBuilder.group({
      listMateriels: this._formBuilder.array([  ]),
    });
    this.addMaterielToList();
  }

   // Editer un contrart
   async submitEditionContrat() {
    console.log('Le contrat a été editer avec succés!');
    /* console.log(this.coordonneesClientFormGroup.value()); */
    console.log(JSON.stringify(this.coordonneesClientFormGroup.value));
    console.log(JSON.stringify(this.dirigeantFormGroup.value));
    console.log(JSON.stringify(this.fournisseursFormGroup.value));

    this.coordonneesClientFormGroup.reset();
  }

}

