import { Component, OnInit, Input } from '@angular/core';
import { FormGroupName, FormGroup, FormArray, AbstractControl} from '@angular/forms';
import { ContratModel } from '../../models/contrat-edition';

@Component({
  selector: 'app-materiel',
  templateUrl: './materiel.component.html',
  styleUrls: ['./materiel.component.scss']
})
export class MaterielComponent implements OnInit {
  contratModel = new ContratModel();
  anneeMisenservice = false;

  @Input()
  formGroupName: FormGroupName;

  @Input()
  parentFormMateriel: FormGroup;

  constructor() { }

  ngOnInit() {
  }

  openAnneeMiseEnService() {
    this.anneeMisenservice = !this.anneeMisenservice;
    this.anneeMisenservice = true;
  }
  hideAnneeMiseEnService() {
    this.anneeMisenservice = false;
  }

  /* supprimer un materiel de la list des materiels recuperer depuis le parent : editioncontrat.ts*/
  removeMateriel(idx: number) {
    (<FormArray>this.parentFormMateriel.get('listMateriels')).removeAt(idx);
  }

}

