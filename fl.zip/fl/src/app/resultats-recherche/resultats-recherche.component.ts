import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { RechercheService } from '../services/recherche/recherche.service';
import * as _ from 'lodash';
import { DossierInfo } from '../models/dossier-info';
import * as moment from 'moment';
import { DdfService } from '../services/ddf/ddf.service';

import { Subscription } from 'rxjs';
import Global from '../models/global-functions';

@Component({
  selector: 'app-resultats-recherche',
  templateUrl: './resultats-recherche.component.html',
  styleUrls: ['./resultats-recherche.component.scss']
})
export class ResultatsRechercheComponent
  implements OnInit, AfterViewInit, OnDestroy {
  aux: any[];
  public resultatRechercheColumns = [];
  public datasource: any[];
  public filter_status = [];
  public statut_param = '';
  public rangeMontant: [number, number];
  public rangeDates = [null, null];
  public value = '';
  storage: any;
  private subscription: Subscription;
  constructor(
    private ddfService: DdfService,
    private rechercheService: RechercheService
  ) {}
  ngAfterViewInit() {
    console.log('after View Init............');

    this.subscription = this.rechercheService.storage.subscribe((res: any) => {
      console.log('response ............', res);

      //   this.populateTable(storage);
    });
  }
  // this.storage = storage;
  // if (this.storage != null) {
  //   this.ddfService
  //     .searchDdf({ numeroSIREN: this.storage })
  //     .subscribe(res => {
  //       this.populateTable(
  //         (res.content as DossierInfo[]).map(item => new DossierInfo(item))
  //       );
  //       console.log('res.content : ' + res.content);
  //     });
  // } else {
  //   const today = new Date();
  //   const dateDebut = new Date();
  //   dateDebut.setDate(today.getDate() - 30);
  //   const dateFin = new Date();
  //   this.ddfService
  //     .searchDdf({ debut: dateDebut.getTime(), fin: dateFin.getTime() })
  //     .subscribe(res => {
  //       this.populateTable(
  //         (res.content as DossierInfo[]).map(item => new DossierInfo(item))
  //       );
  //     });
  // }

  ngOnInit() {
    const data = JSON.parse(localStorage.getItem('data'));
    this.resultatRechercheColumns = this.getResultatRechercheColumns();
    if (data) {
      this.datasource = data;
    }
  }

  getResultatRechercheColumns() {
    return [
      {
        columnDef: 'numFranfinance',
        header: 'N°. FranFinance',
        cell: (row: any) => row.numeroFL
      },
      {
        columnDef: 'numSiren',
        header: 'N°. SIREN',
        cell: (row: any) => row.numeroSIREN
      },
      {
        columnDef: 'raisonSocial',
        header: 'Raison Sociale',
        cell: (row: any) => row.raisonSociale
      },
      {
        columnDef: 'montant',
        header: 'Montant',
        sort: true,
        cell: (row: any) => row.montant
      },
      {
        columnDef: 'dateMaj',
        header: 'Date de MAJ',
        sort: true,
        cell: (row: any) => Global.mapTimestampToDate(row.dateSaisie)
      },
      {
        columnDef: 'status',
        header: 'Status',
        sort: true,
        cell: (row: any) => row.statut
      }
    ];
  }

  filterData(statut: any) {
    if (this.aux) {
      this.datasource = this.aux.filter((item: any) => {
        return item.statut === statut.libelle;
      });
    }
  }

  getDates(dates: any) {
    if (this.aux) {
      this.datasource = this.aux.filter((item: any) => {
        if (dates[1] === null) {
          return moment(new Date(item.dateSaisie)) >= moment(dates[0]);
        }

        return (
          new Date(item.dateSaisie) >= dates[0] &&
          moment(new Date(item.dateSaisie)) <= moment(dates[1]).add(1, 'day')
        );
      });
    }
  }

  populateTable(list: DossierInfo[]) {
    const available_status = [];
    const items = [];
    list.forEach((item: DossierInfo) => {
      console.log(item);
      const model = {};
      model['numeroFL'] = item.id;
      model['numeroSIREN'] = item.numSiren;
      model['raisonSociale'] = item.raisonSociale;
      model['montant'] = item.montant;
      model['dateSaisie'] = item.dateSaisie;
      model['statut'] = item.statut.get('libelle');

      available_status.push({
        id: list.indexOf(item),
        libelle: model['statut']
      });

      items.push(model);
    });
    this.aux = items;
    localStorage.setItem('data', JSON.stringify(items));
    this.datasource = items.map(item => {
      if (
        this.datasource &&
        this.datasource.filter(it => it.id === item.id) !== undefined
      ) {
        item.new = true;
      }
      return item;
    });
    this.filter_status = _.uniqBy(available_status, 'libelle');
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
