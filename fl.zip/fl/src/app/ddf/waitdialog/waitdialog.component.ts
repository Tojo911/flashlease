import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DdfService } from '../../services/ddf/ddf.service';
import { DdfDataSourceService } from '../../services/ddf/ddf-data-source.service';
import { retryWhen } from 'rxjs/internal/operators/retryWhen';
import { interval, throwError, of } from 'rxjs';
import { tap } from 'rxjs/internal/operators/tap';
import { Router } from '@angular/router';
import { DossierInfo } from '../../models/dossier-info';
import { map, delay, take, concat, catchError } from 'rxjs/operators';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import {
  DossierInfo2,
  PersonneInfo,
  DirigeantInfoInput
} from '../../models/ddf';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-waitdialog',
  templateUrl: './waitdialog.component.html',
  styleUrls: ['./waitdialog.component.scss']
})
export class WaitdialogComponent implements OnInit {
  amountFormat = new AmountFormatter();
  numDoss = undefined;
  ddfSubmitted = false;
  ddfNoResponse = false;
  ddfData = undefined;
  showDdfStatus = false;
  infoDiriSent = false;
  init = false;
  infoDirResult = '';
  minDate = new Date(1900, 1, 1);
  maxDate = new Date( );
  @Inject(MAT_DIALOG_DATA) public data: any;
  modeInfoDir = false;
  etat: string;
  infos: DirigeantInfoInput = {
    nom: '',
    prenom: '',
    nomJF: '',
    dateDeNaissance: new Date()
  };

  constructor(
    private ddfService: DdfService,
    private ddfDatasoucre: DdfDataSourceService,
    public dialogRef: MatDialogRef<WaitdialogComponent>,
    private router: Router,
    public translate: TranslateService
  ) {
    translate.get('DDF.FORM.FIELDS.HELP.NOM_DIRIGEANT').subscribe(it => it);
  }
  ngOnInit() {
    this.ddfDatasoucre.numfl.subscribe(message => this.setValue(message));
    this.ddfSubmitted = false;
  }
  infosDirEnded(e) {
    this.modeInfoDir = false;
    setTimeout(() => this.getDfdData(this.numDoss), 1000);
  }
  closeDialog() {
    this.dialogRef.close();
    if (this.ddfNoResponse && !this.showDdfStatus && !this.ddfSubmitted) {
      this.router.navigate(['']);
    } else {
      this.router.navigate(['dossier/ddf_' + this.numDoss + '/suivi/']);
    }
  }
  isValid() {
    this.init = true;
    return (
      this.infos.nom &&
      this.infos.nom !== '' &&
      this.infos.prenom &&
      this.infos.prenom !== '' &&
      this.infos.dateDeNaissance &&
      this.isDateValid()
    );
  }
  isDateValid() {
    return  this.infos.dateDeNaissance.getTime() < new Date().getTime();
  }
  sendInfosDirigeant() {
    if (this.isValid()) {
      this.modeInfoDir = false;
      this.ddfService.sendInfosdirigeant(this.infos, this.numDoss).subscribe(
        res => {
          console.log(`info Dirigeant sent `);
          if ( ! this.data ) {

            this.getDfdData(this.numDoss);
          }
          this.infoDiriSent = true;
          this.infoDirResult = 'SUCCESS_INFO_DIR';
        },
        err => {
          console.log('error...infos dirigeant', err);
          if ( ! this.data ) {
            this.getDfdData(this.numDoss);
          }
          this.infoDiriSent = true;
          this.infoDirResult = 'FAILED_INFO_DIR';
        }
      );
    }
  }
  setDateBirth(e) {
    this.infos.dateDeNaissance = e;
  }
  getDfdData(id: any) {
    let i = 1;
    this.ddfService
      .getDdf(id)
      .pipe(
        map(res => {
          const content = res.content as DossierInfo2;
          // console.log(`statut1: ` + content.statut.code);
          if ( content.topDirigeant ) { // } || content.topDirigeant === undefined || content.topDirigeant === null) {
            this.modeInfoDir = true;
          } else if (content.statut.code === 'ETU' && !this.data ) {
            this.ddfData = new DossierInfo(res.content);
            if (i === 10) { this.showDdfStatus = true; }
            i++;
            console.log('retry : ' + i );
            throw res;
          }
          return res;
        }),
        retryWhen(errors =>
          errors.pipe(
            delay(3000),
            take(15),
            concat(throwError('Retry limit exceeded!'))
          )
        ),
        tap(p => console.log('tap....', p))
      )
      .subscribe(
        res => {
          this.ddfData = new DossierInfo(res.content);
          // console.log(this.ddfData.statut.get('libelle'));
          // this.etat = this.ddfData.statut.get('libelle');

          this.showDdfStatus = true;
        },
        err => {
          this.ddfNoResponse = true;
          console.log('error...', err);
        }
      );
  }
  setValue(message) {
    this.ddfSubmitted = true;
    this.numDoss = message;
    if (this.numDoss) {
      this.getDfdData(this.numDoss);
    }
  }
  isError(field) {
    return !this.infos[field] && this.infos[field] === '' && this.init;
  }
  replaceStatut(it) {
    if (!it) {
      return it;
    }
    return this.translate.instant(it);
  }
}
