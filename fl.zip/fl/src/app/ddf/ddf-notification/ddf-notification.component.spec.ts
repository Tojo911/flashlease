import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DdfNotificationComponent } from './ddf-notification.component';

describe('DdfNotificationComponent', () => {
  let component: DdfNotificationComponent;
  let fixture: ComponentFixture<DdfNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DdfNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DdfNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
