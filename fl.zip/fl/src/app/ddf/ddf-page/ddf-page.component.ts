import {
  Component,
  OnInit,
  Inject,
  DoCheck,
  OnChanges,
  ViewChildren,
  QueryList,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import {
  FormControl,
  FormBuilder,
  FormGroup,
  Validators,
  AsyncValidatorFn,
  AsyncValidator,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';

import { Observable, Subject } from 'rxjs';

import { ActivatedRoute } from '@angular/router';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { WaitdialogComponent } from '../waitdialog/waitdialog.component';

import {
  filter,
  debounceTime,
  distinctUntilChanged,
  switchMap
} from 'rxjs/operators';

import { Router } from '@angular/router';

import { EntrepriseService } from '../../services/entreprise/entreprise.service';
import { DdfService } from '../../services/ddf/ddf.service';
import { ProduitService } from '../../services/produit/produit.service';
import { NatureProduitEnum } from '../../classes/nature-produit.enum';

import * as _ from 'lodash';
import { DdfDataSourceService } from '../../services/ddf/ddf-data-source.service';
import { CatalogueService } from '../../services/catalogue/catalogue.service';
import { MaterielService } from '../../services/materiel/materiel.service';
import { DdfValidation, DdfModel } from '../../models/ddf-validation';
import { ModelOption } from '../../models/option-model';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { FileUploader } from 'ng2-file-upload';
import { TranslateService } from '@ngx-translate/core';
import { SirenFormatter } from '../../classes/inputFormatter/sirenFormatter';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { PerimetreService } from '../../services/perimetre/perimetre.service';
import { ClickedOutsideDirective } from '../../directives/clicked-outside.directive';
import { Perimetre } from '../../models/perimetre';
import { AuthService } from '../../services/auth/auth.service';
import { userInfo } from 'os';
import { UserInfo } from '../../models/ddf';
import Global from '../../models/global-functions';

export interface Produit {
  actif: boolean;
  categorie: any;
}

@Component({
  selector: 'app-ddf-page',
  templateUrl: './ddf-page.component.html',
  styleUrls: ['./ddf-page.component.scss']
})
export class DdfPageComponent implements OnInit, OnDestroy {
  model = new DdfModel();
  sirenTerm$ = new Subject<string>();
  duree$ = new Subject<string>();
  anneeMat$ = new Subject<string>();
  montantError = false;
  dureeError = false;
  anneeMatError = false;
  ddfSubmitted = false;
  ddfFinished = false;
  numerofl: string;
  catalogues: any = [];
  ListeMateriels: any = [];
  ListeCatalogues: any = [];
  public produitsList: any;
  public NatureProduitEnum = NatureProduitEnum;
  DdfForm: FormGroup;
  DDfValid = false;
  validationError: any = null;
  waiting = false;
  sirenQuerying = false;
  formSubmitted = false;
  lastCall = new Date().getTime();
  lastRecall = null;
  isAbouttoValidate = false;
  waitingTime = 750;
  public dureeProduit: any;
  errorMsgType: string;
  errorMsgSize: string;
  sirenFormat = new SirenFormatter();
  amountFormat = new AmountFormatter(0, 100000000, 0, 9);
  percentFormat = new AmountFormatter(0, 100, 0, 3);
  residFormat = new AmountFormatter(0, 100000000, 0, 9);
  perimetre: Perimetre = {};
  defaultCode_mat: string;
  defaultCode_cat: string;
  disableCommentaire: boolean;
  isInterne: boolean;
  isSirenValid: boolean;
  vendeur: any;
  initBlocFinancementValue = true;
  commentairePartenaireMaxLength = 300;
  public postDdf$;
  public materielServ$;
  public validate$;
  public materielEtat$;
  public montant$;
  public produit$;
  public catalog$;
  public sirenTer$;
  public translate2$;
  public translate1$;
  public vendeur$;
  constructor(
    private entrepriseService: EntrepriseService,
    private authService: AuthService,
    private ddfService: DdfService,
    private produitService: ProduitService,
    private ddfDatasoucre: DdfDataSourceService,
    private catalogueService: CatalogueService,
    private materialService: MaterielService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private fb: FormBuilder,
    public snackBar: MatSnackBar,
    public translate: TranslateService,
    public perimetreService: PerimetreService
  ) {
    this.defaultCode_mat = this.authService.getUserDataByKeyFromJWTPayload(
      'materielDefault'
    );
    this.defaultCode_cat = this.authService.getUserDataByKeyFromJWTPayload(
      'catalogueDefault'
    );

    this.produitsList = this.produitService
      .getProduits()
      .map(produit => JSON.parse(produit));
    this.translate1$ = this.translate
      .get('DDF.FORM.ERROR.file_error_type')
      .subscribe(it => (this.errorMsgType = it));
    this.translate2$ = this.translate
      .get('DDF.FORM.ERROR.file_error_size')
      .subscribe(it => (this.errorMsgSize = it));
    this.perimetre = this.authService.getPerimetreFromToken();

  }

  ngOnDestroy() {
    if (this.postDdf$) {
      this.postDdf$.unsubscribe();
    }
    if (this.materielServ$) {
      this.materielServ$.unsubscribe();
    }
    this.validate$.unsubscribe();
    this.materielEtat$.unsubscribe();
    this.montant$.unsubscribe();
    this.produit$.unsubscribe();
    this.catalog$.unsubscribe();
    this.sirenTer$.unsubscribe();
    this.translate2$.unsubscribe();
    this.translate1$.unsubscribe();
    if (this.vendeur$) {
      this.vendeur$.unsubscribe();
    }
  }
   ngOnInit() {
    this.disableCommentaire = true;
    this.isInterne = this.authService.isInterne();
    // this.isInterne = true;
    if (this.produitsList) {
      /*this.produitsList.unsubscribe();
      this.translate1$.unsubscribe();
      this.translate2$.unsubscribe();*/
    }
    this.DdfForm = this.fb.group({
      siren: [
        '',
        {
          updateOn: 'change',
          validators: [
            Validators.required,
            Validators.minLength(9),
            Validators.maxLength(9)
          ],
          asyncValidators: [() => this.validate()]
        }
      ],
      montant: [
        '',
        {
          updateOn: 'change',
          validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      anneeMiseEnService: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      valeurResiduelle: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      premierLoyer: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      valeurResiduelleMontant: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      premierLoyerMontant: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      produit: [
        '',
        {
          updateOn: 'change',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      duree: [
        '',
        {
          updateOn: 'change',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      materiel: [
        '',
        {
          updateOn: 'change',
          asyncValidators: [() => this.validate()]
        }
      ],
      code_mat: [
        '',
        {
          updateOn: 'blur',
          // validators: [Validators.required],
          asyncValidators: [() => this.validate()]
        }
      ],
      materielEtat: ['']
    });
    this.sirenTer$ = this.sirenTerm$
      // .pipe(distinctUntilChanged())
      .pipe(debounceTime(500))
      .pipe(
        filter(val => {
          return val !== '' && val.length === 9 && this.isValidSiren(val);
        })
      )
      .subscribe(val => {
        this.entrepriseService.getEntreprise(val).subscribe(
          res => {
            this.sirenQuerying = false;
            this.model.raison = res.content.nom;
            this.model.sirenError = false;
            this.isSirenValid = true;
          },
          err => {
            this.sirenQuerying = false;
            this.model.raison = null;
            this.model.sirenError = true;
            this.isSirenValid = false;
          }
        );
      });
    this.catalog$ = this.catalogueService.getCatalogues().subscribe(
      res => {
        this.catalogues = _.orderBy(
          res.content.catalogues,
          ['libelle'],
          ['asc']
        ).map(cat => new ModelOption(cat.libelle, cat.code, cat));
      },
      err => {
        this.catalogues = '';
      }
    );
    this.produit$ = this.DdfForm.get('produit').valueChanges.subscribe(
      (produit: ModelOption) => {
        this.toggleHiddenOptionsValidator();
      }
    );
    this.montant$ = this.DdfForm.get('montant').valueChanges.subscribe(
      montant => {
        this.toggleHiddenOptionsValidator();
      }
    );
    this.materielEtat$ = this.DdfForm.get(
      'materielEtat'
    ).valueChanges.subscribe((etat: any) => {
      if (etat === '1') {
        this.DdfForm.controls['anneeMiseEnService'].reset(
          this.DdfForm.get('anneeMiseEnService').value,
          { updateOn: 'blur' }
        );
        this.DdfForm.controls['anneeMiseEnService'].setValidators([]);
        this.DdfForm.controls['anneeMiseEnService'].updateValueAndValidity();
      } else {
        const anneeControl = this.DdfForm.get('anneeMiseEnService');
        anneeControl.setValidators([Validators.required]);
        this.DdfForm.get('anneeMiseEnService').setAsyncValidators([
          () => this.validate()
        ]);
        anneeControl.updateValueAndValidity();
      }
    });
  }
  isAuthToSelectPerimetre() {
    return this.authService.getAuthorities().contains('');
  }
  isAuthToCreateDdf() {
    return this.authService.getAuthorities().contains('');
  }
  async getPerimetre() {
    let vendeur;
    if (this.perimetre.vendeur) {
      vendeur = await this.perimetreService
        .getVendeur(this.perimetre)
        .toPromise()
        .then(v => v.content);
    }
    return vendeur;
  }
  toggleHiddenOptionsValidator() {
    if (Global.gets(this.model.produit).value === 'CB' && this.isOptionToDisplay()) {
      this.DdfForm.get('valeurResiduelle').reset(
        this.DdfForm.get('valeurResiduelle').value,
        { updateOn: 'blur' }
      );
      this.DdfForm.get('premierLoyer').reset(
        this.DdfForm.get('premierLoyer').value,
        { updateOn: 'blur' }
      );

      this.DdfForm.get('valeurResiduelleMontant').reset(
        this.DdfForm.get('valeurResiduelleMontant').value,
        { updateOn: 'blur' }
      );
      this.DdfForm.get('premierLoyerMontant').reset(
        this.DdfForm.get('premierLoyerMontant').value,
        { updateOn: 'blur' }
      );

      this.DdfForm.get('valeurResiduelle').setAsyncValidators([
        () => this.validate()
      ]);
      this.DdfForm.get('premierLoyer').setAsyncValidators([
        () => this.validate()
      ]);
      this.DdfForm.get('valeurResiduelleMontant').setAsyncValidators([
        () => this.validate()
      ]);
      this.DdfForm.get('premierLoyerMontant').setAsyncValidators([
        () => this.validate()
      ]);

      this.DdfForm.get('valeurResiduelle').setValidators([Validators.required]);
      this.DdfForm.get('premierLoyer').setValidators([Validators.required]);
    } else {
      this.DdfForm.get('valeurResiduelle').reset(
        this.DdfForm.get('valeurResiduelle').value,
        { updateOn: 'blur' }
      );
      this.DdfForm.get('premierLoyer').reset(
        this.DdfForm.get('premierLoyer').value,
        { updateOn: 'blur' }
      );

      this.DdfForm.get('valeurResiduelle').setValidators([]);
      this.DdfForm.get('premierLoyer').setValidators([]);

      this.DdfForm.get('valeurResiduelle').updateValueAndValidity();
      this.DdfForm.get('premierLoyer').updateValueAndValidity();

      this.DdfForm.get('valeurResiduelleMontant').reset(
        this.DdfForm.get('valeurResiduelleMontant').value,
        { updateOn: 'blur' }
      );
      this.DdfForm.get('premierLoyerMontant').reset(
        this.DdfForm.get('premierLoyerMontant').value,
        { updateOn: 'blur' }
      );

      this.DdfForm.get('valeurResiduelleMontant').setValidators([]);
      this.DdfForm.get('premierLoyerMontant').setValidators([]);

      this.DdfForm.get('valeurResiduelleMontant').updateValueAndValidity();
      this.DdfForm.get('premierLoyerMontant').updateValueAndValidity();
    }
  }
  isValidSiren(val) {
    let pair = 0;
    let impair = 0;
    let index = 1;
    if (val.length !== 9) {
      return false;
    }
    if (val === '000000000') {
      return false;
    } else if (val === '') {
      return false;
    }
    for (let i = val.length - 1; i >= 0; i--) {
      if (index % 2 === 0) {
        const temp = 2 * Number(val[i]);
        if (temp >= 10) {
          const str = temp + '';
          pair += Number(str[0]) + Number(str[1]);
        } else {
          pair += temp;
        }
      } else {
        impair += Number(val[i]);
      }
      index++;
    }

    if ((pair + impair) % 10 !== 0) {
      return false;
    }

    return true;
  }
  onSirenModified(val: string) {
    this.sirenQuerying = true;
    this.model.raison = null;
    this.sirenTerm$.next(val);
  }
  validate(c?: AbstractControl): Observable<ValidationErrors> {
    // check des autres erreurs comme required
    if (this.DdfForm) {
      return this.validateDdf();
    }
    return new Observable();
  }
  validatorHandler(recall?: number) {
    const current = new Date().getTime();
    if (!recall) {
      this.lastCall = current;
    }
    if (
      recall &&
      recall === this.lastCall &&
      this.isAlready(this.waitingTime)
    ) {
      if (this.duplicatedCalls(recall)) {
        return new Observable();
      }
      this.lastRecall = recall;
      this.isAbouttoValidate = false;
      this.validate$ = this.ddfService
        .AsyncValidatorDdf({data: new DdfValidation(this.model), vendeur: this.vendeur})
        .subscribe(
          res => {
            console.log('Validation Ddf Successful');
            this.validationError = null;
            return null;
          },
          err => {
            console.log(err);
            let errorMessages = null;
            if (err && err.error) {
              errorMessages = JSON.parse(err.error.message);
            }
            this.validationError = errorMessages;
            return errorMessages;
          }
        );
    } else {
      setTimeout(() => {
        this.isAbouttoValidate = true;
        this.validatorHandler(current);
      }, this.waitingTime);
    }
  }
  validateDdf() {
    return new Observable<ValidationErrors>(observer => {
      this.validatorHandler();
    });
  }
  getListeMateriels() {
    const catModelEmitted: ModelOption = this.model.code_cat;
    if (catModelEmitted) {
      this.materielServ$ = this.materialService
        .getMaterielByCatalogue(catModelEmitted['value'])
        .subscribe(
          res => {
            this.ListeMateriels = _.orderBy(
              res.content.materiels,
              ['libelle'],
              ['asc']
            ).map(mat => new ModelOption(mat.libelle, mat.code, mat));
          },
          err => {
            this.ListeMateriels = '';
          }
        );
    }
  }

  isReadyForSubmit(): boolean {
    let isReady = true;
    Object.keys(this.DdfForm.controls).forEach(key => {
      const el = this.DdfForm.get(key);
      const elM = this.DdfForm.get(key + 'Montant');
      if (el.errors && !elM) {
        isReady = false;
      } else if (el.errors && elM && elM.errors) {
        isReady = false;
      }
    });
    if (this.validationError) {
      isReady = false;
    }
    if (!this.isSirenValid) {
      isReady = false;
    }
    return isReady;
  }
  async submitddf(s) {
    this.formSubmitted = true;
    if (!this.isReadyForSubmit()) {
      this.openSnack(
        'Certains champs du formulaire ne sont pas correctement remplis',
        '',
        2000
      );
      return;
    }
    this.waiting = true;
    const files = this.model.files;
    // const vendeur = await this.getPerimetre();
    this.postDdf$ = this.ddfService
      .postDdf({
        data: new DdfValidation(this.model),
        files: files,
        vendeur: this.vendeur
      })
      .subscribe(
        res => {
          this.validationError = null;
          this.waiting = false;
          this.numerofl = res.content.numeroFL;
          this.ddfFinished = true;
          this.ddfDatasoucre.getNumeroFl(this.numerofl);
          const dialogRef = this.dialog.open(WaitdialogComponent, {
            disableClose: true
          });
        },
        err => {
          this.waiting = false;
          if (err.error && err.error.message) {
            try {
              const errorMessages = JSON.parse(err.error.message);
              this.validationError = errorMessages;

              this.openSnack(
                'Certains champs du formulaire ne sont pas correctement remplis',
                '',
                2000
              );
            } catch (e) {
              this.openSnack(err.error.message, '', 15000);
            }
          } else {
            this.openSnack(err.message, '', 5000);
            this.numerofl = '';
            this.ddfFinished = false;
          }
        }
      );
  }

  cancelSirenValue(data: any) {
    this.model.raison = '';
    this.model.siren = '';
  }

  getTypesProduit() {
    let list = [];

    if (this.produitsList) {
      list = this.produitsList.map(p => {
        const opt = new ModelOption(
          this.NatureProduitEnum[p['nature']['sigle']],
          p['nature']['sigle'],
          p
        );
        return opt;
      });
    }
    return _.orderBy(_.uniqBy(list, 'libelle'), ['libelle'], ['desc']);
  }

  getDureeList() {
    const dureeList = ['36', '48', '60', '63'];
    // TODO: il faut récupérer la durée min et max du produit selectionné
    // ** Code is just temporarily commented; return only static durreList**
    // const firstProduit = this.produitsList[0];
    // const dureeMin = firstProduit.dureeMin;
    // const dureeMax = firstProduit.dureeMax;
    // const dureeOptions = [];
    // dureeOptions[0] = dureeMin + 1;
    // dureeOptions[3] = dureeMax;
    // for (let i = 1; i < 3; i++) {
    //   dureeOptions[i] =
    //     dureeOptions[i - 1] + Math.floor((dureeMax - dureeMin) / 3);
    // }
    // const temp = dureeOptions.map(
    //   d => new ModelOption(d.toString(), d.toString(), d.toString())
    // );
    // return dureeOptions.map(
    //   d => new ModelOption(d.toString(), d.toString(), d.toString())
    // );
    return dureeList;
  }

  getFormGroup() {
    return this.DdfForm;
  }

  validateSiren(e: any) {
    console.log(e);
  }

  getValidationError(field: string) {
    try {
      const customValid = this.validationError[field].split('__');
      if (customValid.length > 1) {
        const err = this.translate.instant('DDF.FORM.ERROR.' + customValid[0]);
        const variables = err.split('##');
        const values = JSON.parse(customValid[1]);
        if ( variables.length === values.length) {

          return variables.forEach((it, i) => it + ' ' + values[i] ).join();
        }
        return err;
      }
      if (this.validationError && this.validationError[field]) {
        return 'DDF.FORM.ERROR.' + this.validationError[field];
      }
    } catch (e) {
      console.log('Something Went Wrong');
    }
  }
  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }

  isError(field: string) {
    const field2 = field === 'code_mat' ? 'codeMateriel' : field;

    /*if (
        (((this.DdfForm.controls[field].invalid && !this.DdfForm.controls[field + 'Montant'])
        || (this.DdfForm.controls[field].invalid
            && this.DdfForm.controls[field + 'Montant'] && this.DdfForm.controls[field + 'Montant'].invalid))
        && (this.DdfForm.controls[field].touched ||
          this.DdfForm.controls[field].dirty ||
          this.formSubmitted))
      ) {*/
    if (
      this.DdfForm.controls[field].invalid &&
      (
        this.DdfForm.controls[field].touched ||
        this.DdfForm.controls[field].dirty ||
        this.formSubmitted)
    ) {
      return true;
    } else if (
      this.validationError &&
      this.validationError[field2] &&
      ( this.validationError[field2].touched ||
       // this.DdfForm.controls[field].dirty ||
        this.formSubmitted)
    ) {
      return true;
    }
    return false;
  }

  touched(value: any) {
    this.DdfForm.controls[value].markAsTouched();
  }
  calculateLoyerMajoreMontant(value: any) {
    this.model.premierLoyer = value;
    this.model.premierLoyerMontant = this.calculateMontant(value);
    this.resetOptValidator('premierLoyer');
  }
  calculateLoyerMajorePourcent(value: any) {
    this.model.premierLoyer = this.calculatePourcentage(value);
    this.resetOptValidator('premierLoyer');
  }
  resetOptValidator(field) {
    if (this.model.valeurResiduelle && this.model.valeurResiduelle >= 0) {
      this.DdfForm.controls[field].setValidators([]);
    } else if (
      !this.model.valeurResiduelle &&
      !this.DdfForm.controls[field].validator
    ) {
      this.DdfForm.get(field).setValidators([Validators.required]);
    }
    this.DdfForm.get(field).updateValueAndValidity();
  }
  calculateMontant(value: any) {
    return (value * this.model.montant) / 100;
  }
  calculatePourcentage(value: any) {
    return (value / this.model.montant) * 100;
  }
  calculateValeurResiduelleMontant(value: any) {
    this.model.valeurResiduelle = value;
    this.model.valeurResiduelleMontant = this.calculateMontant(value);
    this.resetOptValidator('valeurResiduelle');
  }
  calculateValeurResiduellePourcent(value: any) {
    this.model.valeurResiduelle = this.calculatePourcentage(value);
    this.resetOptValidator('valeurResiduelle');
  }

  isAlready(time: number): boolean {
    return new Date().getTime() - this.lastCall >= time;
  }
  duplicatedCalls(recall) {
    return Math.abs(this.lastRecall - recall) < 100;
  }
  isOptionToDisplay() {
    let flag = false;
    this.produitsList.forEach(it => {
      //
      if (
        this.model.produit &&
        this.model.produit.value === it.nature.sigle &&
        Number(this.model.montant) >= it.montantMin &&
        Number(this.model.montant) <= it.montantMax &&
        it.planFinancementObligatoire
      ) {
        flag = true;
      }
    });

    // Tojo : 27/12/2018 : Correction JIRA 677
    this.blocFinancementValue(flag);

    return flag;
  }

  blocFinancementValue(flag) {
    if (flag && this.initBlocFinancementValue) {
      this.initBlocFinancementValue = false;
      this.model.valeurResiduelle = 0;
      this.model.valeurResiduelleMontant = 0;
      this.model.premierLoyer = 0;
      this.model.premierLoyerMontant = 0;
    }
    if (!flag) {
      this.initBlocFinancementValue = true;
      delete this.model.valeurResiduelle;
      delete this.model.valeurResiduelleMontant;
      delete this.model.premierLoyer;
      delete this.model.premierLoyerMontant;
    }
  }

  reloadDDfConfigurations(event) {
    // this.vendeur = await this.getPerimetre();
    let code_cat = '',
      code_mat = '';
    if (this.perimetre.vendeur) {
      this.vendeur$ = this.perimetreService
        .getVendeur(this.perimetre)
        .subscribe(res => {
          const result = res.content as UserInfo;
          this.vendeur = result;
          this.produitsList = result.produits;
          code_cat = result.catalogueDefault;
          code_mat = result.materielDefault;
          this.validatorHandler();
          if (
            code_cat &&
            code_mat &&
            (code_cat !== this.defaultCode_cat ||
              code_mat !== this.defaultCode_mat)
          ) {
            this.catalog$.unsubscribe();
            this.defaultCode_cat = code_cat;
            this.defaultCode_mat = code_mat;
            this.catalog$ = this.catalogueService
              .getCatalogues(this.perimetre.apporteur + '')
              .subscribe(
                resultat => {
                  this.catalogues = _.orderBy(
                    resultat.content.catalogues,
                    ['libelle'],
                    ['asc']
                  ).map(cat => new ModelOption(cat.libelle, cat.code, cat));
                },
                err => {
                  this.catalogues = '';
                }
              );
          }
        });
    }
  }
  test() {
    this.dialog.open(WaitdialogComponent, {
      disableClose: true
    });
  }
}
