import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { CritereRechercheInfo } from '../../models/critere-recherche-info';

@Injectable({
  providedIn: 'root'
})
export class KpiService {
public criteriaHasChanged = new Subject<CritereRechercheInfo>();
  constructor() { }
}
