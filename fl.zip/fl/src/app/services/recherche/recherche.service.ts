import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { DossierInfo } from '../../models/dossier-info';
import { TranslateService } from '@ngx-translate/core';
import { ItemTableInfo } from '../../models/item-table-info';
import { PerimetreService } from '../perimetre/perimetre.service';

@Injectable({ providedIn: 'root' })
export class RechercheService {
  private API_SEARCH_ADVANCED_URL = `/flashlease/api/search/advanced`;
  private API_SEARCH_QUICK_URL = `/flashlease/api/search/quick/`;
  private emitter: any;
  public storage: Observable<any> = new Observable<any>(
    e => (this.emitter = e)
  );
  public searchSubject = new Subject<any>();
  public lastCriteria;
  constructor(private http: RequesterService, private  translateService: TranslateService, perimService: PerimetreService) {}

  sendStorage(data: any) {
    if (this.emitter) {
      this.emitter.next(data);
    }
  }

  clearStorage() {
    //   this.storage.next();
  }

  // getStorage(): Observable<any> {
  //   return this.storage.asObservable();
  // }

  advancedSearch(critere): Observable<any> {
    const api = { method: 'POST', url: this.API_SEARCH_ADVANCED_URL };
    const critStr = JSON.stringify(critere);
    this.lastCriteria = JSON.stringify(critere);
    this.searchSubject.next({
      criteres: critere,
      result: null,
      isLoading: true
    });
    console.log(critere);
    return this.http.request(api, { body: critere }).pipe(
      map(response => {
          this.searchSubject.next({
            criteres: JSON.parse(critStr),
            result: response,
            isLastRequest: this.lastCriteria === critStr
          });
          const isLastRequest  = this.lastCriteria === critStr;
        return {
          content: response,
          isLastRequest: isLastRequest,
          criteres: JSON.parse(critStr)
        };
      })
    );
  }
  replaceStatut(it) {
    if (!it) {
      return it;
    }
    return this.translateService.instant(it);
  }
  formatDataTableItem(list) {
    return list.map(item => {
      if (item && item.statut && item.statut['libelle']) {
        item.statut['libelle'] = this.replaceStatut(
          item.statut['libelle']
        );
      }
      if (!item) {
        return null;
      }
      return new ItemTableInfo( new DossierInfo(item));
    });
  }
  quickSearch(critere): Observable<any> {
    const api = { method: 'GET', url: this.API_SEARCH_QUICK_URL + critere };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
}
