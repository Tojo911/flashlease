import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';

import { AuthService } from '../auth/auth.service';

import { Observable, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { ValidationErrors } from '@angular/forms';
import { HttpRequest } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ContratService {
    public CONTRAT_API_VALID = '';
    constructor(
        private http: RequesterService
    ) {}
    AsyncValidatorContrat(data): Observable<ValidationErrors | null> {
        const api = { method: 'POST', url: this.CONTRAT_API_VALID };
        const formdata: FormData = new FormData();
        formdata.append('data', JSON.stringify(data.data));
        data = formdata;
        return this.http.request(api, { body: data }, true).pipe(
          map(response => ({
            content: response
          }))
        );
      }
}
