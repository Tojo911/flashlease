import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { map } from 'rxjs/operators';
import { HttpUrlEncodingCodec } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AffaireService {
  public PARC_API_URL = `/flashlease/api/affaire/`;
  constructor( private http: RequesterService,
    private authService: AuthService) { }

  getDossierById(did): Observable<any> {
    const api = { method: 'GET', url: this.PARC_API_URL + did };
    return this.http.request(api, null).pipe(
      map(data => ({
        content: data
      }))
    );
  }
}
