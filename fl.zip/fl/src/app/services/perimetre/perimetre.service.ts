import { Injectable } from '@angular/core';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { AuthService } from '../auth/auth.service';
import { map, catchError } from 'rxjs/operators';
import { Perimetre } from '../../models/perimetre';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PerimetreService {
  public PERIMETRE_MARCHES_URL = '/flashlease/api/organisation/marches';
  public PERIMETRE_BASE_URL = '/flashlease/api/organisation/marche/';
  public APPORTEURS = '/apporteurs';
  public APPORTEUR = '/apporteur/';
  public AGENCES = '/agences';
  public AGENCE = '/agence/';
  public VENDEURS = '/vendeurs';
  public MARCHES = '/marches';
  public VENDEUR = '/vendeur/';
  public reset = new Subject<any>();
  constructor(
    private http: RequesterService,
    private authService: AuthService
  ) {}

  getMarches() {
    const api = { method: 'GET', url: this.PERIMETRE_MARCHES_URL };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getApporteurs(marche: string) {
    const api = {
      method: 'GET',
      url: this.PERIMETRE_BASE_URL + marche + this.APPORTEURS
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  resetDefaultMode() {
    this.reset.next(true);
  }
  getAgences(req: any) {
    const api = {
      method: 'GET',
      url:
        this.PERIMETRE_BASE_URL +
        req.marche +
        this.APPORTEUR +
        req.apporteur +
        this.AGENCES
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getVendeurs(req: any) {
    const api = {
      method: 'GET',
      url:
        this.PERIMETRE_BASE_URL +
        req.marche +
        this.APPORTEUR +
        req.apporteur +
        this.AGENCE +
        req.agence +
        this.VENDEURS
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getVendeur(req: any) {
    const api = {
      method: 'GET',
      url:
        this.PERIMETRE_BASE_URL +
        req.marche +
        this.APPORTEUR +
        req.apporteur +
        this.AGENCE +
        req.agence +
        this.VENDEUR +
        req.vendeur
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  computePerimetre(perimetre) {
    if (
      perimetre.marche &&
      perimetre.agence &&
      perimetre.apporteur &&
      perimetre.vendeur
    ) {
      return perimetre;
    }
    return perimetre.map(it => {
      if (it.agence) {
        return { marche: it.agence.apporteur.marche.id,
          apporteur: it.agence.apporteur.id,
          agence: it.agence.id,
          vendeur: it.id   };
      } else if (it.apporteur) {
        return { marche: it.apporteur.marche.id,
          apporteur: it.apporteur.id,
          agence: it.id
           };
      } else if (it.marche) {
        return {
          marche: it.marche.id,
          apporteur: it.id
        };
      } else  {
        return {
          marche: it.id
        };
      }
    });
  }
  isPerimetreDifferent(array1, array2) {
    let flag = false;
    array1.forEach(it => {
      if (array2.filter(item => it.id === item.id).length === 0) {
        flag = true;
      }
    });
    array2.forEach(it => {
      if (array1.filter(item => it.id === item.id).length === 0) {
        flag = true;
      }
    });
    return flag;
  }
}
