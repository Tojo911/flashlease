import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Observable } from 'rxjs';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { map } from 'rxjs/operators';
import { ValidationErrors } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class RachatService {
  commonPath: string;
  RACHAT_CONSULTATION_API_URL: string;
  RACHATS_CONSULTATION_API_URL: string;
  RACHATS_SEARCH_API_URL: string;
  RACHATS_DIFFUSE_API_URL: string;
  RACHATS_PDF_API_URL: string;
  RACHATS_STATUS_API_URL: string;
  RACHAT_CONDITION_API_URL: string;
  RACHAT_FORMULE_API_URL: string;
  RACHAT_CREATE_DEMANDE_API_URL: string;
  RACHAT_VALIDATION_FORM_API: string;
  constructor(private authService: AuthService, private http: RequesterService) {
    this.commonPath = authService.API_URL;
    this.RACHATS_SEARCH_API_URL = `${authService.API_URL}/rachat/search`;
    this.RACHAT_CONSULTATION_API_URL = `${authService.API_URL}/rachat/`;
    this.RACHATS_CONSULTATION_API_URL = `${authService.API_URL}/rachat/dossier/`;
    this.RACHATS_STATUS_API_URL = `${authService.API_URL}/rachat/status`;
    this.RACHAT_CONDITION_API_URL = `${authService.API_URL}/rachat/conditions/`;
    this.RACHAT_FORMULE_API_URL  = `${authService.API_URL}/rachat/formules/`;
    this.RACHAT_CREATE_DEMANDE_API_URL = `${authService.API_URL}/rachat/create`;
    this.RACHATS_DIFFUSE_API_URL = `${authService.API_URL}/rachat/diffuse`;
    this.RACHAT_VALIDATION_FORM_API = `${authService.API_URL}/rachat/validate`;
    this.RACHATS_PDF_API_URL = `${authService.API_URL}/rachat/pdf`;
  }

  postRachatDemande(data): Observable<any> {
    const api = { method: 'POST', url: this.RACHAT_CREATE_DEMANDE_API_URL };
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  AsyncValidatorRachat(data): Observable<ValidationErrors | null> {
    const api = { method: 'POST', url: this.RACHAT_VALIDATION_FORM_API };
    // const formdata: FormData = new FormData();
   // formdata.append('data', JSON.stringify(data.data));
    /*
    if (data.vendeur) {
      formdata.append('vendeur', JSON.stringify(data.vendeur));
    }
    */
   // data = formdata;
    return this.http.request(api, { body: data }, true).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getCondition(id): Observable<any> {
    const api = { method: 'GET', url: this.RACHAT_CONDITION_API_URL + id };
    return this.http.request(api, { body: id }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getFormule(id): Observable<any> {
    const api = { method: 'GET', url: this.RACHAT_FORMULE_API_URL + id };
    return this.http.request(api, { body: id }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getRachat(did): Observable<any> {
    const api = { method: 'GET', url: this.RACHAT_CONSULTATION_API_URL + did };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getRachats(did): Observable<any> {
    const api = { method: 'GET', url: this.RACHATS_CONSULTATION_API_URL + did };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getStatus(): Observable<any> {
    const api = { method: 'GET', url: this.RACHATS_STATUS_API_URL };
    return this.http.request(api, null).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  search(criteres): Observable<any> {
    const api = { method: 'POST', url: this.RACHATS_SEARCH_API_URL };
    return this.http.request(api, { body: criteres }).pipe(
      map(data => ({
        content: data
      }))
    );
  }
  diffuse(criteres): Observable<any> {
    const api = { method: 'POST', url: this.RACHATS_DIFFUSE_API_URL };
    return this.http.request(api, { body: criteres }).pipe(
      map(data => ({
        content: data
      }))
    );
  }
  pdf(id): Observable<any> {
    const api = { method: 'GET', url: this.RACHATS_PDF_API_URL + `/${id}` };
      return this.http.request2(api, null, 'application/octet-stream', 'blob').pipe(
      map(data => ({
        content: data
      }))
    );
  }
}
