import { TestBed, inject } from '@angular/core/testing';

import { RachatService } from './rachat.service';

describe('RachatService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RachatService]
    });
  });

  it('should be created', inject([RachatService], (service: RachatService) => {
    expect(service).toBeTruthy();
  }));
});
