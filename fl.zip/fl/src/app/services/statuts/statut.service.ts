import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StatutService {

  STATUT_API_URL = 'flashlease/api/ddf/allstatus';
  constructor(
    private http: RequesterService,
    private authService: AuthService
  ) {}

  getAllStatut(did): Observable<any> {
    const api = { method: 'GET', url: this.STATUT_API_URL };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }
  getDdfKpiStatut() {}
  getMontageKpiStatut() {}
  getSuiviParcKpiStatut() {}
}
