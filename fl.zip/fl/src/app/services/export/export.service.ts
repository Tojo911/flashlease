import { Injectable } from '@angular/core';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { map, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import { LoadConfigurationService } from '../../shared/services/load-configuration/load-configuration.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExportService {
  private PARC_EXPORT_URL = '/flashlease/api/affaires/export';
  private MONTAGE_EXPORT_URL = '/flashlease/api/montage/export';
  private DDF_EXPORT_URL = '/flashlease/api/ddf/export';
  public BEARER = 'Bearer ';
  constructor(private http: HttpClient,
    private lconfService: LoadConfigurationService
  ) {}

  exportParc(model) {
    const cUser = JSON.parse(
      localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    );
    const token = cUser && cUser.token ? cUser.token : null;

    return this.http
      .post(this.lconfService.geturlBackEnd().concat(this.PARC_EXPORT_URL), model, {
        headers: new HttpHeaders({
          Authorization: this.BEARER + token,
          'Content-Type': 'application/octet-stream'
        }),
        responseType: 'blob'
      })
      .pipe();
  }

  exportMontage(model) {
    const cUser = JSON.parse(
      localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    );
    const token = cUser && cUser.token ? cUser.token : null;

    return this.http
      .post(this.lconfService.geturlBackEnd().concat(this.MONTAGE_EXPORT_URL), model, {
        headers: new HttpHeaders({
          Authorization: this.BEARER + token,
          'Content-Type': 'application/octet-stream'
        }),
        responseType: 'blob',
      }).pipe();

  }

  exportDdf(model) {
    const cUser = JSON.parse(
      localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    );
    const token = cUser && cUser.token ? cUser.token : null;

    return this.http
      .post(this.lconfService.geturlBackEnd().concat(this.DDF_EXPORT_URL), model, {
        headers: new HttpHeaders({
          Authorization: this.BEARER + token,
          'Content-Type': 'application/octet-stream'
        }),
        responseType: 'blob'
      })
      .pipe();
  }

  public downloadFile(url: string): Observable<any> {
    return this.http
      .get(url, {
        headers: new HttpHeaders({
          'Content-Type': 'application/octet-stream'
        }),
        responseType: 'blob'
      })
      .pipe(map((response: Blob) => ({ data: response })));
  }
}
