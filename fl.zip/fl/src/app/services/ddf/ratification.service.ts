import { Injectable } from '@angular/core';

import { AuthService } from '../auth/auth.service';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class RatificationService {

  public RATIF_LIST = '/flashlease/api/ddf/${did}/ratifications';

  constructor(
    private http: RequesterService,
    private authService: AuthService
  ) {}
  getRatifications(data) {
    const api = {
      method: 'GET',
      url: '/flashlease/api/ddf/' + data + '/ratifications'
    };
    return this.http.request(api, { data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  getEkipnum(data) {
    const api = {
      method: 'POST',
      url: '/flashlease/api/ddf/' + data.dossierId + '/ekipnum'
    };
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  getContrat(data) {
    const api = {
      method: 'GET',
      url: '/flashlease/api/ddf/' + data.dossierId + '/contrat/' + data.contratId
    };
    return this.http.request(api, { data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  getRatification(data) {
    const api = {
      method: 'GET',
      url: '/flashlease/api/ddf/' + data.dossierId + '/ratification/' + data.contratId
    };
    return this.http.request(api, { data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  getRatificationList(data) {
    const api = {
      method: 'GET',
      url: '/flashlease/api/ddf/' + data + '/ratifications'
    };
    return this.http.request(api, { data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
}
