import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';

import { AuthService } from '../auth/auth.service';

import { Observable, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { CatalogueService } from '../catalogue/catalogue.service';
import { MaterielService } from '../materiel/materiel.service';
import { ValidationErrors } from '@angular/forms';
import { HttpRequest } from '@angular/common/http';
import { Perimetre } from '../../models/perimetre';

@Injectable({
  providedIn: 'root'
})
export class DdfService {
  public DDF_API_CREATE_URL: string; // = '/flashlease/api/ddf/create';
  public DDF_API_URL: string; // = `/flashlease/api/ddf/`;
  public DDF_API_VALID: string; // = `/flashlease/api/ddf/validate`;
  public DDF_API_INFOS_DIR: string; // = `/topdirigeant`;
  public DDF_API_LIST_URL: string; // = `/flashlease/api/ddf/list`;
  public DDF_API_TICKET_STATUS_URL: string; // = '/flashlease/api/kpi/ddf';
  public DDF_API_DOSSIERS_MONTAGE_LIST_URL: string; // = '/flashlease/api/montage/list';
  public DDF_API_KPI_DOSSIERS_MONTAGE_URL: string; // = '/flashlease/api/kpi/montage';
  public DDF_API_KPI_SUIVI_PARC_URL: string; // = '/flashlease/api/kpi/affaires';
  public DDF_API_SUIVIS_PARC_LIST_URL: string; // = '/flashlease/api/affaires/list';
  public DDF_API_BASE_URL: string; // = '/flashlease/api/';
  public DDF_API_KPI_BASE_URL: string; // = '/flashlease/api/kpi/';

  public DDF_ACCORD_LIST_URL: string; // = '/flashlease/api/ddf/accords/';
  public DDF_ETUDE_LIST_URL: string; // = '/flashlease/api/ddf/etudes/';
  public DDF_REFUS_LIST_URL: string; // = '/flashlease/api/ddf/refuses/';
  public DDF_EXPIRE_LIST_URL: string; // = '/flashlease/api/ddf/expires/';

  public MONTAGE_PAYES_LIST_URL: string; // = '/flashlease/api/montage/payes/';
  public MONTAGE_ENTRAITEMENT_LIST_URL: string; // = '/flashlease/api/montage/entraitement/';
  public MONTAGE_RECUS_LIST_URL: string; // = '/flashlease/api/montage/recus/';
  public MONTAGE_ENANOMALIE_LIST_URL: string; // = '/flashlease/api/montage/enanomalie/';

  public PARC_SAINE_LIST: string; // = '/flashlease/api/affaires/saines/';
  public PARC_CONTENTIEUSE_LIST: string; // = '/flashlease/api/affaires/contentieuses/';
  public PARC_AMIABLE_LIST: string; // = '/flashlease/api/affaires/amiables/';
  public PARC_EXPIRENt_LIST: string; // = '/flashlease/api/affaires/expirent/';
  public DDF_COMMENTAIRES_URL: (_: any) => {};

  validatingData = {};

  public currentDashboardTab = new BehaviorSubject(undefined);
  constructor(
    private http: RequesterService,
    private authService: AuthService,
    private catalogueService: CatalogueService,
    private materielSetrvice: MaterielService
  ) {
    this.DDF_API_CREATE_URL = `${authService.API_URL}/ddf/create`;
    this.DDF_API_URL = `${authService.API_URL}/ddf/`;
    this.DDF_API_VALID = `${authService.API_URL}/ddf/validate`;
    this.DDF_API_INFOS_DIR = `/topdirigeant`;
    this.DDF_API_LIST_URL = `${authService.API_URL}/ddf/list`;
    this.DDF_API_TICKET_STATUS_URL = `${authService.API_URL}/kpi/ddf`;
    this.DDF_API_DOSSIERS_MONTAGE_LIST_URL = `${
      authService.API_URL
    }/montage/list`;
    this.DDF_API_KPI_DOSSIERS_MONTAGE_URL = `${
      authService.API_URL
    }/kpi/montage`;
    this.DDF_API_KPI_SUIVI_PARC_URL = `${authService.API_URL}/kpi/affaires`;
    this.DDF_API_SUIVIS_PARC_LIST_URL = `${authService.API_URL}/affaires/list`;
    this.DDF_API_BASE_URL = `${authService.API_URL}/`;
    this.DDF_API_KPI_BASE_URL = `${authService.API_URL}/kpi/`;

    this.DDF_ACCORD_LIST_URL = `${authService.API_URL}/ddf/accords/`;
    this.DDF_ETUDE_LIST_URL = `${authService.API_URL}/ddf/etudes/`;
    this.DDF_REFUS_LIST_URL = `${authService.API_URL}/ddf/refuses/`;
    this.DDF_EXPIRE_LIST_URL = `${authService.API_URL}/ddf/expires/`;

    this.MONTAGE_PAYES_LIST_URL = `${authService.API_URL}/montage/payes/`;
    this.MONTAGE_ENTRAITEMENT_LIST_URL = `${
      authService.API_URL
    }/montage/entraitement/`;
    this.MONTAGE_RECUS_LIST_URL = `${authService.API_URL}/montage/recus/`;
    this.MONTAGE_ENANOMALIE_LIST_URL = `${
      authService.API_URL
    }/montage/enanomalie/`;

    this.PARC_SAINE_LIST = `${authService.API_URL}/affaires/saines/`;
    this.PARC_CONTENTIEUSE_LIST = `${
      authService.API_URL
    }/affaires/contentieuses/`;
    this.PARC_AMIABLE_LIST = `${authService.API_URL}/affaires/amiables/`;
    this.PARC_EXPIRENt_LIST = `${authService.API_URL}/affaires/expirent/`;
    this.DDF_COMMENTAIRES_URL = _id => {
      return `${authService.API_URL}/ddf/${_id}/commentaires/partenaire`;
    };
  }

  setDashboardTabIndex(index) {
    this.currentDashboardTab.next(index);
  }
  sendInfosdirigeant(data, id) {
    const api = {
      method: 'POST',
      url: this.DDF_API_URL + `${id}${this.DDF_API_INFOS_DIR}`
    };
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  postDdf(data): Observable<any> {
    const api = { method: 'POST', url: this.DDF_API_CREATE_URL };
    const isMulti = true;
    const formdata: FormData = new FormData();
    if (data.files && data.files.length > 0) {
      data.files.forEach(it => {
        formdata.append(
          'files[]',
          it._file,
          it.formData.typeCode + '__' + it.file.name
        );
      });
    }
    formdata.append('data', JSON.stringify(data.data));
    if (data.vendeur) {
      formdata.append('vendeur', JSON.stringify(data.vendeur));
    }
    data = formdata;
    return this.http.request(api, { body: data }, isMulti).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  sendPiecesDdf(did, data): Observable<any> {
    const api = { method: 'POST', url: this.DDF_API_URL + did + '/files' };
    let isMulti = false;
    const formdata: FormData = new FormData();
    isMulti = true;
    if (data.files && data.files.length > 0) {
      data.files.forEach(it => {
        formdata.append(
          'files[]',
          it._file,
          it.formData.typeCode + '__' + it.file.name
        );
      });
    }
    data = formdata;
    return this.http.request(api, { body: data }, isMulti).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getDdf(did): Observable<any> {
    const api = { method: 'GET', url: this.DDF_API_URL + did };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getPiecesDdf(did): Observable<any> {
    const api = { method: 'GET', url: this.DDF_API_URL + did + '/pieces' };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getPiecesMontage(did): Observable<any> {
    const api = { method: 'GET', url: this.DDF_API_URL + did + '/piecesbystatut' };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );


  }

  AsyncValidatorDdf(data): Observable<ValidationErrors | null> {
    const api = { method: 'POST', url: this.DDF_API_VALID };
    const formdata: FormData = new FormData();
    formdata.append('data', JSON.stringify(data.data));
    if (data.vendeur) {
      formdata.append('vendeur', JSON.stringify(data.vendeur));
    }
    data = formdata;
    return this.http.request(api, { body: data }, true).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getStatusCommerciauxAutorises(did): Observable<any> {
    const api = {
      method: 'GET',
      url: this.DDF_API_URL + did + '/getstatuscommerciauxautorises'
    };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  setStatusCommerciauxAutorises(did, oidStatutCommercial): Observable<any> {
    const api = {
      method: 'POST',
      url: this.DDF_API_URL + did + '/setstatuscommerciauxautorises'
    };
    return this.http.request(api, { body: oidStatutCommercial }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getCatalogs(): Observable<any> {
    return this.catalogueService.getCatalogues();
  }

  getMateriels(code_cat): Observable<any> {
    return this.materielSetrvice.getMaterielByCatalogue(code_cat);
  }

  getDdfsList(id?) {
    const api = {
      method: 'GET',
      url: id ? this.DDF_API_LIST_URL + '/' + id : this.DDF_API_LIST_URL
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id
      }))
    );
  }

  setDataToValidate(data: any) {
    this.validatingData = data;
  }

  getKpiDfs() {
    const api = { method: 'GET', url: this.DDF_API_TICKET_STATUS_URL };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getKpiDfsByUser(id) {
    const api = {
      method: 'GET',
      url: this.DDF_API_TICKET_STATUS_URL + '/' + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id
      }))
    );
  }

  getKpi(ids, type, perimetres) {
    let isEmpty = false;
    if (perimetres === {}) {
      isEmpty = true;
    }
    const req = { api: null, data: null };
    req.api = {
      method: type === 'ddf' ? 'POST' : 'GET',
      url: this.DDF_API_KPI_BASE_URL + type + '/' + ids
    };
    return this.http
      .request(req.api, { body: !isEmpty ? { perimetres: perimetres } : null })
      .pipe(
        map(response => ({
          content: response,
          id: ids,
          type: type
        }))
      );
  }

  getDashboardList(id, type) {
    const api = {
      method: 'GET',
      url: this.DDF_API_BASE_URL + type + '/list/' + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id,
        type: type
      }))
    );
  }

  getAllStatus(type: string) {
    const api = {
      method: 'GET',
      url: this.DDF_API_BASE_URL + type + '/allstatus'
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        type: type
      }))
    );
  }

  getAllStatusCom(type: string) {
    const api = {
      method: 'GET',
      url: this.DDF_API_BASE_URL + type + '/allstatuscom'
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        type: type
      }))
    );
  }
  getCommentaire(id) {
    const api = {
      method: 'GET',
      url: this.DDF_COMMENTAIRES_URL(id)
    };
    console.log('API : recuperation commentaires apporteur');
    return this.http
      .request(api, null)
      .pipe(map(response => ({ content: response })));
  }

  // Récupère les commentaires du suivi de dossier
  getFicheRisqueDuClient(type: string): Observable<any> {
    const api = {
      method: 'GET',
      url: this.DDF_API_URL + type + '/syntheserisque'
    };

    return this.http
      .request2(api, null, 'application/octet-stream', 'blob')
      .pipe(map((response: Response) => ({ content: response })));
  }

  // Récupère les commentaires du suivi de dossier
  getCommentairesParSuiviDeDossier(type: string): Observable<any> {
    const api = {
      method: 'GET',
      url: this.DDF_API_URL + type + '/commentaires'
    };
    console.log('API : reception de la liste');
    return this.http
      .request(api, null)
      .pipe(map((response: Response) => ({ content: response })));
  }

  postCommentairesParSuiviDeDossier(data, numDoss: string): Observable<any> {
    const api = {
      method: 'POST',
      url: this.DDF_API_URL + numDoss + '/commentaire'
    };
    console.log('API : envoi du message : ' + JSON.stringify(data));
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  // Récupération de la liste des dossiers accordés
  getDDFAccordList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.DDF_ACCORD_LIST_URL);
    } else {
      return this.get(id, this.DDF_ACCORD_LIST_URL);
    }
  }

  getDDFEtudeList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.DDF_ETUDE_LIST_URL);
    } else {
      return this.get(id, this.DDF_ETUDE_LIST_URL);
    }
  }

  getDDFRefusList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.DDF_REFUS_LIST_URL);
    } else {
      return this.get(id, this.DDF_REFUS_LIST_URL);
    }
  }

  getDDFExpireList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.DDF_EXPIRE_LIST_URL);
    } else {
      return this.get(id, this.DDF_EXPIRE_LIST_URL);
    }
  }

  // Recuperer la liste des Dossier en Montage
  getMontagePayesList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.MONTAGE_PAYES_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_PAYES_LIST_URL);
    }
  }

  getMontageEntraitementList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.MONTAGE_ENTRAITEMENT_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_ENTRAITEMENT_LIST_URL);
    }
  }

  getMontageRecusList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.MONTAGE_RECUS_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_RECUS_LIST_URL);
    }
  }

  getMontageEnAnomalieList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.MONTAGE_ENANOMALIE_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_ENANOMALIE_LIST_URL);
    }
  }

  // Recuperer la liste des Dossier affaires
  getParcSaineList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.PARC_SAINE_LIST);
    } else {
      return this.get(id, this.PARC_SAINE_LIST);
    }
  }

  getParcContentieuseList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.PARC_CONTENTIEUSE_LIST);
    } else {
      return this.get(id, this.PARC_CONTENTIEUSE_LIST);
    }
  }

  getParcAmiableList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.PARC_AMIABLE_LIST);
    } else {
      return this.get(id, this.PARC_AMIABLE_LIST);
    }
  }

  geParcExpireList(id) {
    if (typeof id !== 'number') {
      return this.getList(id, this.PARC_EXPIRENt_LIST);
    } else {
      return this.get(id, this.PARC_EXPIRENt_LIST);
    }
  }

  getList(perimetres: Perimetre[], url) {
    const api = {
      method: 'POST',
      url: url
    };
    return this.http.request(api, { body: perimetres }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  get(id: number, url) {
    const api = {
      method: 'GET',
      url: url + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
}
