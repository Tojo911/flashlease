import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DdfDataSourceService {
  numflSource = new BehaviorSubject('');
  numfl = this.numflSource.asObservable();

  constructor() { }

  getNumeroFl(numeroFlashlease: string) {
    this.numflSource.next(numeroFlashlease);
  }
}
