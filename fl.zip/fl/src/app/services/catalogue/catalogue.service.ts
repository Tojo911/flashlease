import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { AuthService } from '../auth/auth.service';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RequesterService } from '../../shared/services/requester/requester.service';

@Injectable({
  providedIn: 'root'
})
export class CatalogueService {
  public DDF_API_CAT_URL = `/flashlease/api/cat`;

  constructor(
    private http: RequesterService,
    private authService: AuthService
  ) {}

  getCatalogues(id?: string): Observable<any> {
    const api = { method: 'GET', url: id ? this.DDF_API_CAT_URL + '/' + id : this.DDF_API_CAT_URL};

    return this.http.request(api, null).pipe(
      map(data => ({
        content: data
      }))
    );
  }
}
