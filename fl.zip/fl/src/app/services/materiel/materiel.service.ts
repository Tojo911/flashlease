import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';

import { AuthService } from '../auth/auth.service';
import { map } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MaterielService {

  public MAT_API_URL = `/flashlease/api/mat/bycat/`;

  constructor(private http: RequesterService, private authService: AuthService) {}

  getMaterielByCatalogue(code: string): Observable<any> {
    const api = { method: 'GET', url: this.MAT_API_URL + code};
    return this.http.request(api, null).pipe(
      map(data => ({
        content: data
      }))
    );
  }
}
