import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { ModelOption } from '../../../models/option-model';
import { Perimetre } from '../../../models/perimetre';
import { AuthService } from '../../../services/auth/auth.service';
import { DdfService } from '../../../services/ddf/ddf.service';
import {
  CritereRechercheInfo,
  CriteresModelToMap
} from '../../../models/critere-recherche-info';
import { map } from 'rxjs/internal/operators/map';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { ItemTableInfo } from '../../../models/item-table-info';
import { TranslateService } from '@ngx-translate/core';
import { SirenFormatter } from '../../../classes/inputFormatter/sirenFormatter';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { AmountFormatter } from '../../../classes/inputFormatter/amountFormatter';
import { DossierInfo } from '../../../models/dossier-info';
import { HomeTabEnum } from '../../../models/enums/home-tab.enum';
import { FormGroup, NgForm, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { PerimetreService } from '../../../services/perimetre/perimetre.service';
import { KpiModel } from '../../../models/kpimodel';
import { KpiService } from '../../../services/kpi/kpi.service';
import { RachatService } from '../../../services/rachat/rachat.service';
import { Requestable } from '../../../models/table-column-definition-model';
import Global from '../../../models/global-functions';

@Component({
  selector: 'app-recherche-avancee',
  templateUrl: './recherche-avancee.component.html',
  styleUrls: ['./recherche-avancee.component.scss']
})
export class RechercheAvanceeComponent implements OnInit, OnChanges {
  @Input()
  selectedTabIndex: number;
  @Input()
  requestFields: Requestable[];
  @Input()
  status: ModelOption[];
  @Input()
  statusComList: ModelOption[];
  @Input()
  public perimetre: Perimetre;
  @Input()
  public perimetres: Perimetre[];
  @Input()
  isSirenRequired = false;
  @Input()
  critereRecherche: CritereRechercheInfo;
  @Input()
  kpi: KpiModel;
  @Output()
  kpiChange = new EventEmitter<KpiModel>();
  kpiUpdated: boolean;
  public criteresModel: CriteresModelToMap = new CriteresModelToMap();
  public showSpinner: boolean;
  public hasResultData: boolean;
  public datasource: ItemTableInfo[];
  iconValidite = 'calendar_today';
  public sirenFormat = new SirenFormatter();
  public amountFormat = new AmountFormatter();
  public HomeTabEnum = HomeTabEnum;
  public validForm = false;
  private searchEmited = false;
  private perimetreRecherche: Perimetre;
  private formGroup;
  searchForm: FormGroup; // = new FormGroup({});
  perimetreFromToken: Perimetre;

  @Output()
  critereRechercheChange: EventEmitter<CritereRechercheInfo> = new EventEmitter<
    CritereRechercheInfo
  >();
  @Output()
  reinitialiseEvent: EventEmitter<void> = new EventEmitter<void>();

  @Output()
  enableExportButton: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private router: Router,
    private httpClient: HttpClient,
    private authService: AuthService,
    private rechercheService: RechercheService,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private perimServ: PerimetreService,
    private kpiService: KpiService
  ) {
    this.formGroup = {
      numeroFL: ['', [Validators.required]],
      numeroSIREN: ['', [Validators.required]],
      raisonSociale: ['', [Validators.required]],
      statut: ['', [Validators.required]],
      statutCommercial: ['', [Validators.required]],
      dateCreation: ['', [Validators.required]],
      refApporteur: ['', [Validators.required]],
      numAccord: ['', [Validators.required]],
      numDossier: ['', [Validators.required]],
      nbLoyerRestant: ['', [Validators.required]],
      finValidite: ['', [Validators.required]],
      nomMarches: ['', [Validators.required]],
      nomApporteurs: ['', [Validators.required]],
      /*demandeRachat: ['', [Validators.required]],
      affaire: ['', [Validators.required]],
      dateReception: ['', [Validators.required]],
      dateRachat: ['', [Validators.required]],*/
      nomAgences: ['', [Validators.required]],
      nomVendeurs: ['', [Validators.required]]
    };
    this.searchForm = this.fb.group(this.formGroup);

  }

  ngOnInit() {
    this.perimetreFromToken = this.authService.getPerimetreFromToken();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes['selectedTabIndex'] &&
      changes['selectedTabIndex'].previousValue &&
      changes['selectedTabIndex'].currentValue !==
        changes['selectedTabIndex'].previousValue
    ) {

      this.reinitialiser();

    }
    if (changes.kpi && this.kpi && this.kpi.data) {
      // 20/12/2018 fix ano 670
     this.searchForm.reset();

      this.criteresModel = new CriteresModelToMap();
      this.kpiUpdated = true;
      this.criteresModel.dateFinValidite = this.kpi.data.dateFinValidite;
      this.criteresModel.dateCreation = [this.kpi.data.dateDebut];
      this.kpi.data.statuts = [...this.kpi.data.statuts];

    } else if (changes.kpi && !this.kpi) {
      this.criteresModel.dateFinValidite = null;
      this.criteresModel.dateCreation = [];
    }
    if (changes.criteresModel && this.kpiUpdated) {
      this.kpiUpdated = false;
      this.search(this.selectedTabIndex);
    }
    if (changes.requestFields && changes.requestFields.currentValue) {
      this.addCustomFieldToFromGroup();
    }
  }
  addCustomFieldToFromGroup() {
    if (this.requestFields) {
      this.requestFields
        .filter(f => f.controlName)
        .forEach(f => {
          if (!this.formGroup[f.controlName]) {
            this.searchForm.addControl(
              f.controlName,
              new FormControl('', Validators.required)
            );
          }
        });
    }
    this.fb.group(this.formGroup);
  }
  kpisearch(index) {
    setTimeout(() => this.search(index), 500);
  }
  isCitereEmpty(obj) {
    for (const key in obj) {
      if (obj[key] !== null && obj[key] !== '') {
        return false;
      }
    }
    return true;
  }

  resetForm() {
    this.searchForm.reset();
  }

  search(index) {
    this.searchEmited = true;

    switch (index) {
      // DDF
      case 0:
        this.criteresModel.perimetre = this.perimetre
          ? this.perimetre
          : undefined;
        this.criteresModel.phase = this.HomeTabEnum[index];
        this.criteresModel.perimetres = this.perimetres;
        break;
      // MONTAGE
      case 1:
        this.criteresModel.perimetre = !this.isJsonEmpty(
          this.perimetreRecherche
        )
          ? this.perimetreRecherche
          : this.perimetre
          ? this.perimetre
          : undefined;
        this.criteresModel.phase = this.HomeTabEnum[index];
        this.criteresModel.perimetres = this.perimetres;
        // console.log('perimetreRecherche' + JSON.stringify(this.perimetreRecherche));
        // console.log('perimetres : ' + JSON.stringify(this.criteresModel.perimetres));
        // console.log('perimetre : ' + JSON.stringify(this.criteresModel.perimetre));
        break;
      // PARC
      case 2:
        this.criteresModel.perimetre = !this.isJsonEmpty(
          this.perimetreRecherche
        )
          ? this.perimetreRecherche
          : this.perimetre
          ? this.perimetre
          : undefined;
        this.criteresModel.phase = this.HomeTabEnum[index];
        this.criteresModel.perimetres = this.perimetres;
        break;
      case 3:
        this.criteresModel.perimetre = !this.isJsonEmpty(
          this.perimetreRecherche
        )
          ? this.perimetreRecherche
          : this.perimetre
          ? this.perimetre
          : undefined;
        this.criteresModel.perimetres = this.perimetres;
        break;
    }
    this.critereRechercheChange.emit(
      new CritereRechercheInfo(this.criteresModel)
    );
  }

  isJsonEmpty(obj) {
    if (obj && Object.keys(obj).length === 0) {
      return true;
    } else {
      return false;
    }
  }

  getPerimetreRecherche(event: Perimetre) {
    this.perimetreRecherche = event ? event : undefined;
  }

  reinitialiser() {
    this.criteresModel = {} as CriteresModelToMap;
    this.perimServ.resetDefaultMode();
    if (this.searchEmited) {
      this.reinitialiseEvent.emit();
    }
  }

  isFormValid() {
    for (const key of Object.keys(this.searchForm.controls)) {
      const field = this.searchForm.get(key);
      switch (this.selectedTabIndex) {
        case 0:
          if (field.errors === null) {
            return true;
          }
          break;
        case 1:
          if (
            key === 'nomMarches' ||
            key === 'nomApporteurs' ||
            key === 'nomAgences'
          ) {
            if (this.perimetreRecherche && field.errors === null) {
              return true;
            }
          } else if (field.errors === null) {
            return true;
          }
          break;
        case 2:
          if (
            key === 'nomMarches' ||
            key === 'nomApporteurs' ||
            key === 'nomAgences'
          ) {
            if (this.perimetreRecherche && field.errors === null) {
              return true;
            }
          } else if (field.errors === null) {
            return true;
          }
          break;
        case 3:
          if (
            key === 'nomMarches' ||
            key === 'nomApporteurs' ||
            key === 'nomAgences'
          ) {
            if (this.perimetreRecherche && field.errors === null) {
              return true;
            }
          } else if (field.errors === null) {
            return true;
          }
          break;
      }
    }
  }
  isDef(f: Requestable) {
    return Global.isDefaut(f);
  }
}
