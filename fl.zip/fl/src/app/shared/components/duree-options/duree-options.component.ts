import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, FormGroup, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { forwardRef } from '@angular/core';
import { ModelOption } from '../../../models/option-model';

// TODO try to implement duree list more general
 @Component({
  selector: 'app-duree-options',
  templateUrl: './duree-options.component.html',
  styleUrls: ['./duree-options.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    multi: true,
    useExisting: forwardRef(() => DureeOptionsComponent),
  }]
})
export class DureeOptionsComponent implements ControlValueAccessor {
  host: {
    '(blur)': 'this.onTouched( this.value )'
  };
  @Input() min = 0;
  @Input() max = 999;
  @Input() duree: ModelOption|string = null;
  @Input() preset = false;
  @Input() label: string;
  @Input() placeholder: string = undefined;
  @Input() disabled: boolean;
  @Output() dureeChange = new EventEmitter();
  @Input() public dureeList;
  @Input() hasError = false;
  onChanged = (_: any) => {};
  onTouched = (_: any) => {};

  constructor() {}

  getPlaceholder() {
    if (this.placeholder !== undefined) {
      return this.placeholder;
    } else {
      return 'MM';
    }
  }
  onDureeChange(newValue) {
    this.duree = newValue;
    this.dureeChange.emit(newValue);
    // in order to trigger update on Blur need to not call onchanged method
     this.onChanged(this.duree);
    // this.onTouched(this.duree);
  }
  writeValue(value: any): void {
    this.duree = value;
  }
  registerOnChange(fn: any): void {
    this.onChanged = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
  getValue() {
    return (typeof this.duree === 'string') ? this.duree : this.duree.value;
  }
}
