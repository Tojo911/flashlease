import { Component, Input, OnInit } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-dossier-info',
  templateUrl: './dossier-info.component.html',
  styleUrls: ['./dossier-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DossierInfoComponent implements OnInit {
   @Input() titre: string;
    // la position de contenu selon justify-content flex-start(start), flex-end(end), flex-center(center)
   @Input() position: 'end' | 'start' | 'center';

  constructor() { }

  ngOnInit() {
  }

}
