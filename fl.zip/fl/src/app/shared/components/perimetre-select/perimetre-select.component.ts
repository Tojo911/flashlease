import {
  Component,
  Input,
  OnInit,
  OnChanges,
  HostListener,
  ViewChild,
  AfterViewInit,
  ViewChildren,
  ElementRef,
  QueryList
} from '@angular/core';
import {
  trigger,
  style,
  transition,
  animate,
  group
} from '@angular/animations';
import { log } from 'util';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { PerimetreService } from '../../../services/perimetre/perimetre.service';
import { ClickedOutsideDirective } from '../../../directives/clicked-outside.directive';
import { Perimetre } from '../../../models/perimetre';
import {
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatSnackBar
} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '../../../services/auth/auth.service';

// FIXME: move interface into one model
export interface PerimetreItem {
  name?: string;
  type?: string;
  id?: string;
  perimetre?: Perimetre;
  children?: any[];
  items?: any[];
}
@Component({
  selector: 'app-perimetre-select',
  templateUrl: './perimetre-select.component.html',
  styleUrls: ['./perimetre-select.component.scss'],
  animations: [
    trigger('itemAnim', [
      transition('* => enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition('* => leave', [
        style({ transform: 'translateX(-100%)' }),
        animate(200)
      ])
    ])
  ]
})
export class PerimetreSelectComponent
  implements OnInit, OnChanges, AfterViewInit {
  DEFAULT_PERIM_KEY = 'perimetreDefault';
  defaultModePH = 'Périmêtre par défaut';
  @Input()
  saveable: boolean;
  @Input()
  isFullRange: boolean;
  @Input()
  disabled: boolean;
  @Input()
  multiple: boolean;
  @Input()
  label = '';
  @Input()
  items: any[];
  @Input()
  value = '';
  @Input()
  placeholder = '';
  @Input()
  perimetre: Perimetre;
  @Input()
  perimetres: Perimetre[];
  @Output()
  perimetreChange = new EventEmitter<any>();
  @Output()
  perimetresChange = new EventEmitter<any>();
  @Output()
  valueChange = new EventEmitter<string>();
  @ViewChild('select')
  select;
  @ViewChild(ClickedOutsideDirective)
  dirs;
  init =  false;
  currentItems: any[];
  @ViewChildren('links', { read: ElementRef })
  connectors: QueryList<ElementRef>;
  @ViewChildren(MatPseudoCheckbox)
  checkBoxs: QueryList<MatPseudoCheckbox>;
  private INIT = 'INIT';
  public focusComp = [];
  private username = '';
  public focusCheckBox = [];
  public storedPerimetres;
  lastItem: any;
  public search: string;
  public aux: any[];
  public list = [];
  public direction = '';
  public isSingle = false;
  public singleValue: string;
  public model = {};
  public lastList = [];
  public lastItems = [];
  public defaultPerimetre: Perimetre;
  public currentPerimetre: Perimetre;
  public setToPerimetre = true;
  public typePerimetre;
  public selectedPerimetres: Perimetre[] = [];
  public lastEmittedPerimeter: Perimetre[] = [];
  public isLoading = true;
  public defaultMode = false;
  public defaultUserHasRelations = false;
  perimetrePlaceholder: string;
  constructor(
    private perimetreService: PerimetreService,
    private snackBar: MatSnackBar,
    public trServ: TranslateService,
    public authService: AuthService
  ) {
    this.username = this.authService.getUserName();
    this.typePerimetre = { type: perimetreService.MARCHES };
    this.perimetreService.reset.subscribe(it => {
      this.setPerimetreDefaut();
    });
    setTimeout(async () => {
      await this.connectors.changes.subscribe(con => {
        this.focusComp = con._results ? con._results : [];
        this.dirs.compList = [...this.dirs.compList, ...this.focusComp];
      });
      await this.checkBoxs.changes.subscribe(con => {
        this.focusCheckBox = con._results ? con._results : [];
        this.dirs.compList = [...this.dirs.compList, ...this.focusCheckBox];
      });
    }, 800);
  }
  ngAfterViewInit() {
    this.select.open();
    setTimeout(() => {
      this.select.close();
      this.isLoading = false;
    }, 1500);
  }
  ngOnInit() {
    this.defaultPerimetre = this.perimetre;
    if (
      localStorage.getItem(this.DEFAULT_PERIM_KEY + this.username) &&
      this.multiple &&
      this.saveable
    ) {
      setTimeout(() => this.setPerimetreDefaut(), 1000);
    }
    this.perimetre = {};
    this.model = {}; /* localStorage.getItem('organisation')
      ? JSON.parse(localStorage.getItem('organisation'))
      : {}; */
    this.init = true;
    this.loadChild({ type: this.INIT });
  }
  clearPerimetre() {
    if ( this.multiple) {
      console.log('clear perimetre start');
      // this.selectedPerimetres = [];
       this.loadChild({ type: this.INIT });
    }
    // this.sele
  }
  async onBlur($event) {
    // console.log('blur detected');
    if (!this.select.panelOpen) {
      // this.select.open();
      this.currentItems = this.lastItems;
      this.resetSearch();
      // this.goToselectedValue();
      this.setValueForMultipleOption();
      setTimeout(this.select.close(), 2800);
    }
    if (this.multiple) {
      if (
        this.isPerimetreDifferent(
          this.lastEmittedPerimeter,
          this.selectedPerimetres
        )
      ) {
        const res = this.selectedPerimetres.map(it => {
          const result: Perimetre = {};
          result.agence = it.agence;
          result.marche = it.marche;
          result.apporteur = it.apporteur;
          result.vendeur = it.vendeur;
          return result;
        });
        this.perimetresChange.emit(res);
        this.lastEmittedPerimeter = this.selectedPerimetres.map(it => it);
      }
    }
  }
  isPerimetreDifferent(array1: Perimetre[], array2: Perimetre[]) {
    let flag = false;
    array1.forEach(it => {
      // tslint:disable-next-line:max-line-length
      if (
        array2.filter(
          item =>
            it.marche === item.marche &&
            it.apporteur === item.apporteur &&
            it.agence === item.agence &&
            it.vendeur === item.vendeur
        ).length === 0
      ) {
        flag = true;
      }
      console.log(array2);
    });
    if (flag) {
      return flag;
    }
    array2.forEach(it => {
      // tslint:disable-next-line:max-line-length
      if (
        array1.filter(
          item =>
            it.marche === item.marche &&
            it.apporteur === item.apporteur &&
            it.agence === item.agence &&
            it.vendeur === item.vendeur
        ).length === 0
      ) {
        flag = true;
      }
    });
    console.log(flag);
    return flag;
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes['items']) {
      if (this.isSingleton(this.items)) {
        this.isSingle = true;
        this.value = this.getSingleValue(this.items);
      }
      this.aux = this.items;
    }
  }
  filterList() {
    if (!this.search || this.search === '') {
      this.items = this.currentItems;
    }
    if (!this.items) {
      return;
    }
    this.items = this.currentItems.filter(
      it =>
        it.name.toLocaleLowerCase().indexOf(this.search.toLocaleLowerCase()) >
        -1
    );
  }
  selectRange(item) {
    if (this.isFullRange) {
      this.setRef(item);
      this.onUpdatePerimetre(item);
    } else {
      this.animate(item);
    }
  }
  isSingleton(item: Perimetre[]) {
    if (item.length === 0) {
      this.list.pop();
      return true;
    } else if (item.length > 1) {
      return false;
    } else {
      this.list = [...this.list, item[0]];
      return this.isSingleton(item[0].children);
    }
  }

  getSingleValue(items: Perimetre[]): string {
    // FIXME: try to add Enumeration for string
    if (items[0].type === 'vendeur') {
      return items[0].name;
    } else {
      return this.getSingleValue(items[0].children);
    }
  }

  async animate(item, reset?) {
    this.resetSearch();
    this.list.push(item);
    await this.loadChild(item);
    // }

    this.items = [];
    this.direction = 'enter';
  }

  searchItem(item: any) {
    this.resetSearch();
    this.direction = 'leave';
    this.isSingle = false;
    if (this.list.length === 1) {
      this.list = this.list.slice(0, this.list.indexOf(item));
      this.ngOnInit();
    } else {
      this.list = this.list.slice(0, this.list.indexOf(item) + 1);
      this.items = [];
      this.loadChild(item);
      this.setPlaceHolder(item);
      console.log('Nombre d elements selectionnés: ' + this.list.indexOf(item));
    }
  }
  setPlaceHolder(item: PerimetreItem, leaving?) {
    if (!leaving) {
      switch (item.type) {
        case this.perimetreService.MARCHES:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_MARCHE';
          break;
        case this.perimetreService.APPORTEURS:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_APPORTEURS';
          break;
        case this.perimetreService.AGENCES:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_AGENCES';
          break;
        case this.perimetreService.VENDEURS:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_VENDEURS';
          break;
      }
    }
    if (leaving) {
      switch (item.type) {
        case this.perimetreService.APPORTEURS:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_MARCHES';
          break;
        case this.perimetreService.AGENCES:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_APPORTEURS';
          break;
        case this.perimetreService.VENDEURS:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_AGENCES';
          break;
        case this.perimetreService.VENDEUR:
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_VENDEURS';
          break;
      }
    }
  }
  public clickOnName(item?: any) {
    this.setRef(item);
    if (!this.multiple) {
      this.onUpdatePerimetre(item);
      this.select.value = item.name;

      console.log( this.select.value = item.name);
    }
  }
  public onUpdatePerimetre(item?: any) {
    if (!this.perimetre) {
      this.perimetre = {};
    }
    if (item) {
      if (item.type === this.perimetreService.VENDEUR) {
        this.perimetre.vendeur = item.id;
      } else if (item.type === this.perimetreService.VENDEURS) {
        this.perimetre.agence = item.id;
        delete this.perimetre.vendeur;
      } else if (item.type === this.perimetreService.AGENCES) {
        this.perimetre.apporteur = item.id;
        delete this.perimetre.agence;
        delete this.perimetre.vendeur;
      } else if (item.type === this.perimetreService.APPORTEURS) {
        this.perimetre.marche = item.id;
        delete this.perimetre.apporteur;
        delete this.perimetre.agence;
        delete this.perimetre.vendeur;
      }
    }
    this.perimetreChange.emit(this.perimetre);
    this.onUpdateValue(item.name);
  }
  public onUpdateValue(name: any) {
    this.value = name;
    this.select.value = name;
    this.valueChange.emit(this.value);

    // this.perimetreChange.emit(this.perimetre);
  }
  setValueForMultipleOption(arr?) {
    if (this.multiple) {
      arr = arr ? arr : this.selectedPerimetres;
      const listCommonItem = this.items.filter(it =>
        arr.find(res => res.id === it.id)
      );
      if (listCommonItem && listCommonItem.length > 0) {
        this.select.value = listCommonItem.map(perim => perim.name);
      }
    }
  }
  getPlaceHolder() {
    if (this.value === '' || this.value === undefined) {
      return this.placeholder;
    } else {
      return '';
    }
  }
  async loadChild(ref?: Perimetre) {
    switch (ref.type) {
      case this.perimetreService.AGENCES:
        this.perimetre.apporteur = ref.id;
        await this.perimetreService.getAgences(this.perimetre).subscribe(it => {
          this.setItems(it, this.perimetreService.VENDEURS, ref);
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_AGENCES';
        });
        break;
      case this.perimetreService.APPORTEURS:
        this.perimetre = { marche: ref.id };
        await this.perimetreService.getApporteurs(ref.id).subscribe(it => {
          this.setItems(it, this.perimetreService.AGENCES, ref);
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_APPORTEURS';
        });
        break;
      case this.perimetreService.VENDEURS:
        this.perimetre.agence = ref.id;
        await this.perimetreService
          .getVendeurs(this.perimetre)
          .subscribe(it => {
            this.setItems(it, this.perimetreService.VENDEUR, ref);
            this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_VENDEURS';
          });
        break;
      case this.perimetreService.MARCHES:
        this.perimetre = {};
        this.perimetreService.getMarches().subscribe(it => {
          this.setItems(it, this.perimetreService.APPORTEURS, ref);
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_MARCHES';
        });
        break;
      case this.INIT:
        await this.perimetreService
        .getVendeurs(this.defaultPerimetre)
        .subscribe(it => {
          this.setItems(it, this.perimetreService.VENDEUR, ref);
          this.perimetrePlaceholder = 'APP.PERIMETRE.SEARCH_VENDEURS';
        });
      break;
      default:
        console.log(ref);
        break;
    }
  }
  setItems(it, perimetre, ref) {
    this.items = (it.content as any[]).map(item => {
      return this.setPerimetre(item, perimetre, it);
    });
    if (this.items.length > 1) {
      this.defaultUserHasRelations = true;
    }
    /* if (!this.model[perimetre]) {
      this.model[perimetre] = {};
    }
    if (ref.id) {
      this.model[perimetre][ref.id] = this.items;
    } else {
      this.model[perimetre] = this.items;
    }
    localStorage.setItem('organisation', JSON.stringify(this.model));*/
    this.currentItems = this.items;
    const defaultVal = this.matchWithPerimetre([this.defaultPerimetre]);
    this.setValueForMultipleOption();
    if (this.setToPerimetre && defaultVal) {
      if (perimetre === this.perimetreService.VENDEUR) {
        if (!this.defaultUserHasRelations && !this.init) {
          this.disabled = true;
        } else {
          this.init = false;
        }
        this.perimetre = this.defaultPerimetre;
        this.value = defaultVal.map(perim => perim.name).join(',');
        if (this.multiple) {
          // this.selectedPerimetres = defaultVal;
          this.setValueForMultipleOption([...defaultVal]);
        } else {
          this.select.value = defaultVal[0].name;
        }
        this.lastItem = defaultVal;
        this.lastList = this.list;
        this.lastItems = this.items;
        // setToPerimetre INITIALISE COMponent to default flag
        this.setToPerimetre = false;
      } else {
        this.animate(defaultVal[0]);
      }
    } else if (this.items.length === 1 && !this.isFullRange) {
      if (perimetre === this.perimetreService.VENDEUR) {
      } else {
        this.animate(this.items[0]);
      }
    }
  }
  setPerimetre(input: any, groupe, list) {
    return groupe === this.perimetreService.VENDEUR
      ? {
          name: input.nom + ' ' + input.prenom,
          type: groupe,
          id: input.id,
          items: list
        }
      : {
          name: input.libelle,
          type: groupe,
          id: input.id,
          children: [1],
          items: list
        };
  }
  selectedPerimeter(item) {
    this.value = item.name;
  }
  perimetreYetSetted() {
    return this.perimetre ? this.matchWithPerimetre([this.perimetre]) : false;
  }
  goToselectedValue() {
    if (
      this.lastList.length > 0 &&
      this.lastItems.length > 0 &&
      !this.multiple
    ) {
      this.list = this.lastList;
      this.items = this.lastItems;
    } else if (
      this.multiple &&
      this.selectedPerimetres &&
      this.selectedPerimetres.length > 0
    ) {
      this.list = this.selectedPerimetres[
        this.selectedPerimetres.length - 1
      ].list;
      this.items = this.selectedPerimetres[
        this.selectedPerimetres.length - 1
      ].items;
    }
    if (this.items && this.items.length > 0) {
      this.setPlaceHolder(this.items[0], true);
    }
  }
  matchWithPerimetre(perimetres: Perimetre[]) {
    return this.items.filter(
      it =>
        perimetres.filter(
          perimetre =>
            perimetre.agence === it.id ||
            perimetre.apporteur === it.id ||
            perimetre.vendeur === it.id ||
            perimetre.marche === it.id
        ).length > 0
    );
  }

  setRef(item) {
    this.resetSearch();
    if (!this.multiple) {
      this.lastItems = this.items;
      this.lastItem = item;
      this.lastList = this.list;
    }
  }
  resetSearch() {
    this.search = '';
    if (this.currentItems) {
      this.items = this.currentItems;
    }
  }
  selected(event: MatOptionSelectionChange, item) {
    const perim: Perimetre = {};
    perim.items = this.items;
    perim.list = this.list;
    if (item.type === this.perimetreService.VENDEUR) {
      perim.vendeur = item.id;
      perim.agence = this.perimetre.agence;
      perim.apporteur = this.perimetre.apporteur;
      perim.marche = this.perimetre.marche;
    } else if (item.type === this.perimetreService.VENDEURS) {
      perim.agence = item.id;
      perim.apporteur = this.perimetre.apporteur;
      perim.marche = this.perimetre.marche;
    } else if (item.type === this.perimetreService.AGENCES) {
      perim.apporteur = item.id;
      perim.marche = this.perimetre.marche;
    } else if (item.type === this.perimetreService.APPORTEURS) {
      perim.marche = item.id;
    }
    if (this.multiple && event.source.selected) {
      this.selectedPerimetres.push(perim);
      this.lastItems = this.items;
      this.lastItem = item;
      this.lastList = this.list;
    } else {
      // this.clickOnName(item);
      this.selectedPerimetres = this.selectedPerimetres.filter(
        it =>
          it.marche !== perim.marche ||
          it.apporteur !== perim.apporteur ||
          it.agence !== perim.agence ||
          it.vendeur !== perim.vendeur
      );
      // this.select.close();
      // A modifier lorsque le périmètre est sauvegarder
    }
    // this.select.value = this.matchWithPerimetre(this.selectedPerimetres).map(perim => perim.name);
    // console.log(JSON.stringify(this.selectedPerimetres));
  }
  save() {
    /* const conf = {
      perimetre: this.perimetres,
      items: this.items.map(it => {
        delete it.items;
        delete it.perimetre.items;
      }),
      list: this.list,
      selected: this.selectedPerimetres
    };*/
    localStorage.setItem(
      this.DEFAULT_PERIM_KEY + this.username,
      JSON.stringify(this.perimetres)
    );
    this.setPerimetreDefaut();
    this.snackBar.open(this.trServ.instant('PERIMETRE.SAVEMSG'));
  }
  setPerimetreDefaut() {
    if (localStorage.getItem(this.DEFAULT_PERIM_KEY + this.username)) {
      this.perimetresChange.emit(
        JSON.parse(localStorage.getItem(this.DEFAULT_PERIM_KEY + this.username))
      );
      this.defaultMode = true;
    }
    /*this.perimetres = conf.perimetre;
    this.items = conf.items;
    this.list = conf.list;
    this.selectedPerimetres = conf.selected;*/
  }
  closeDefaultMode() {
    if (this.defaultMode) {
      this.perimetresChange.emit(this.selectedPerimetres);
      this.defaultMode = false;
    }
  }
}
