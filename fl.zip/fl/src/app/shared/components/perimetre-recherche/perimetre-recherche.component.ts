import * as _ from 'lodash';
import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit,
  OnChanges, SimpleChanges, ViewEncapsulation} from '@angular/core';
import { PerimetreService } from '../../../services/perimetre/perimetre.service';
import { Perimetre } from '../../../models/perimetre';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '../../../services/auth/auth.service';
import { ModelOption } from '../../../models/option-model';
import { PerimetreItem } from '../perimetre-select/perimetre-select.component';
import { FormGroup, FormBuilder} from '@angular/forms';


@Component({
  selector: 'app-perimetre-recherche',
  templateUrl: './perimetre-recherche.component.html',
  styleUrls: ['./perimetre-recherche.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PerimetreRechercheComponent implements OnInit, AfterViewInit, OnChanges {
  @Input()
  perimetre: Perimetre;
  @Input()
  perimetres: Perimetre[];
  @Input()
  parentForm: FormGroup;
  @Output()
  perimetreEmit = new EventEmitter<Perimetre>();
  @Input()
  marchesInactive;
  @Input()
  apporteursInactive;
  @Input()
  agencesInactive;
  @Input()
  vendeursInactive;
  @Input()
  perimetreByDefault: Perimetre;
  @Input()
  kpiUpdated: boolean;


  perimetreRechercheIsReady: boolean;
  marchesList: ModelOption[] = [];
  apporteursList: ModelOption[] = [];
  agencesList: ModelOption[] = [];
  vendeursList: ModelOption[] = [];
  marchesValue: any;
  apporteursValue: any;
  agencesValue: any;
  vendeursValue: any;
  autoSelectMarches: any;
  autoSelectApporteurs: any;
  autoSelectAgences: any;
  autoSelectVendeurs: any;
  disabledMarches = true;
  disabledApporteurs = true;
  disabledAgences = true;
  disabledVendeurs = true;
  hiddenMarches = false;
  hiddenApporteurs = false;
  hiddenAgences = false;
  hiddenVendeurs = false;
  perimetreByDefaultMarche = true;
  perimetreByDefaultApporteur = true;
  perimetreByDefaultAgence = true;
  perimetreByDefaultVendeur = true;

  username: string;

  constructor(
    private perimetreService: PerimetreService,
    public translateService: TranslateService,
    public authService: AuthService) {
      this.username = this.authService.getUserName();
    //  console.log('perimetreByDefault' + JSON.stringify(this.perimetreByDefault));
    }

  ngOnInit() {

   // console.log(JSON.stringify(this.authService.getPerimetreFromToken()));
  }
  ngAfterViewInit() {
   // console.log('lancement du périmetre recherche' + this.username);
   this.loadChild({ type: this.perimetreService.MARCHES });
  }
  ngOnChanges(changes: SimpleChanges) {}
  loadChild(ref?: Perimetre) {
    switch (ref.type) {
      case this.perimetreService.MARCHES:
        this.perimetre = {};
          const keyMarches = this.username + 'perimetrerecherche' + ref.type;
          const sessionStorageMarches = this.getSessionStoragePerimetre(keyMarches);
          if (sessionStorageMarches) {
           // console.log('sessionStorage');
            this.marchesList = sessionStorageMarches;
            this.cleanApporteurs();
            this.cleanAgences();
            this.cleanVendeurs();
            this.reInitMarches();
          } else {
            this.perimetreService.getMarches().subscribe(it => {
                const tabMarches = <any>it.content;
                const tabMarchesTemp = [];
                tabMarches.map(element => tabMarchesTemp.push(new ModelOption(element.libelle, element.id)));
                this.marchesList = tabMarchesTemp;
                this.setSessionStoragePerimetre(tabMarchesTemp, keyMarches);
                this.cleanApporteurs();
                this.cleanAgences();
                this.cleanVendeurs();
                this.reInitMarches();
            });
          }

        break;
        case this.perimetreService.APPORTEURS:
        this.perimetre = { marche: ref.id };
        const keyApporteurs = this.username + 'perimetrerecherche' + ref.type + ref.id;
        const sessionStorageApporteurs = this.getSessionStoragePerimetre(keyApporteurs);
       // console.log(sessionStorageApporteurs);
        if (sessionStorageApporteurs) {
          this.apporteursList = sessionStorageApporteurs;
          this.cleanAgences();
          this.cleanVendeurs();
          this.reInitApporteurs();
        } else {
            this.perimetreService.getApporteurs(ref.id).subscribe(it => {
              const tabApporteurs = <any>it.content;
              const tabApporteursTemp = [];
              tabApporteurs.map(element => tabApporteursTemp.push(new ModelOption(element.libelle, element.id)));
              this.apporteursList = tabApporteursTemp;
              this.setSessionStoragePerimetre(tabApporteursTemp, keyApporteurs);
              this.cleanAgences();
              this.cleanVendeurs();
              this.reInitApporteurs();
            });
        }
        break;
        case this.perimetreService.AGENCES:
        this.perimetre.apporteur = ref.id;
        const keyAgences = this.username + 'perimetrerecherche' + ref.type + ref.id;
        const sessionStorageAgences = this.getSessionStoragePerimetre(keyAgences);
      // console.log('sessionStorageAgences');
        if (sessionStorageAgences) {
          this.agencesList = sessionStorageAgences;
          this.cleanVendeurs();
          this.reInitAgences();
        } else {
            this.perimetreService.getAgences(this.perimetre).subscribe(it => {
              const tabAgences = <any>it.content;
              const tabAgencesTemp = [];
              tabAgences.map(element => tabAgencesTemp.push(new ModelOption(element.libelle, element.id)));
              this.agencesList = tabAgencesTemp;
              this.setSessionStoragePerimetre(tabAgencesTemp, keyAgences);
              this.cleanVendeurs();
              this.reInitAgences();
            });
        }
        break;
      case this.perimetreService.VENDEURS:
        this.perimetre.agence = ref.id;
        const keyVendeurs = this.username + 'perimetrerecherche' + ref.type + ref.id;
        const sessionStorageVendeurs = this.getSessionStoragePerimetre(keyVendeurs);
      // console.log('sessionStorageVendeurs');
        if (sessionStorageVendeurs) {
          this.vendeursList = sessionStorageVendeurs;
          this.reInitVendeurs();
        } else {
            this.perimetreService.getVendeurs(this.perimetre).subscribe(it => {
              const tabVendeurs = <any>it.content;
              const tabVendeursTemp = [];
              tabVendeurs.map(element => tabVendeursTemp.push(new ModelOption(element.prenom + ' ' + element.nom, element.id)));
              this.vendeursList = tabVendeursTemp;
              this.setSessionStoragePerimetre(tabVendeursTemp, keyVendeurs);
              this.reInitVendeurs();
            });
        }
        break;
      default:
        console.log(ref);
        break;
    }
  }

  setSessionStoragePerimetre(list, storageStatusPrefix) {
   if (list.length > 0) {
    // console.log('setSessionStoragePerimetre : ' + storageStatusPrefix);
      sessionStorage.setItem(
        storageStatusPrefix,
        JSON.stringify(list)
      );
    }

  }

  getSessionStoragePerimetre(key) {
   // return null;
   return JSON.parse(sessionStorage.getItem(key));

  }

  reInitMarches() {
  // console.log('1-tabMarches.length' + this.marchesList.length);
    if (this.marchesList.length === 1) {
      this.disabledMarches = true;
      this.autoSelectMarches = this.marchesList[0].value;
      this.hiddenMarches = true;
    }
    if (this.marchesList.length > 1) {
      this.disabledMarches = false;
      this.perimetreRechercheIsReady = true;
    }

  //  console.log('this.perimetreByDefault : ' + JSON.stringify(this.perimetreByDefault));
  //  console.log('this.perimetreByDefaultMarche : ' + JSON.stringify(this.perimetreByDefaultMarche));

    if (this.perimetreByDefault !== undefined && this.perimetreByDefaultMarche) {
     this.autoSelectMarches = this.perimetreByDefault.marche;
      // delete this.perimetreByDefault.marche;
      this.perimetreByDefaultMarche = false;
    }
    if (this.isMarchesHidden()) {
      this.marchesInactive = true;
    }
    this.marchesList.unshift(new ModelOption(this.translateService.instant('HOME.TABLE.COLUMNS.MARCHES'), ''));
  }

  reInitApporteurs() {
   // console.log('2-tabApporteurs.length' + this.apporteursList.length);
    if (this.apporteursList.length === 1) {
      this.disabledApporteurs = true;
      this.autoSelectApporteurs = this.apporteursList[0].value;
      // console.log('this.autoSelectApporteurs' + this.autoSelectApporteurs);
      this.hiddenApporteurs = true;
    }
    if (this.apporteursList.length > 1) {
      this.disabledApporteurs = false;
      this.perimetreRechercheIsReady = true;
    }
    if (this.perimetreByDefault !== undefined && this.perimetreByDefaultApporteur) {
    this.autoSelectApporteurs = this.perimetreByDefault.apporteur;
      // delete this.perimetreByDefault.apporteur;
      this.perimetreByDefaultApporteur = false;

    }
    if (this.isApporteursHidden()) {
      this.apporteursInactive = true;
    }
    this.apporteursList.unshift(new ModelOption(this.translateService.instant('HOME.TABLE.COLUMNS.PARTENAIRES'), ''));
  }

  reInitAgences() {
   // console.log('3-tabAgences.length' + this.agencesList.length);
    if (this.agencesList.length === 1) {
      this.disabledAgences = true;
      this.autoSelectAgences = this.agencesList[0].value;
      this.hiddenAgences = true;
    }
    if (this.agencesList.length > 1) {
      this.disabledAgences = false;
      this.perimetreRechercheIsReady = true;
    //  console.log('perimetreRechercheIsReady for Agence');
    }
    if (this.perimetreByDefault !== undefined && this.perimetreByDefaultAgence) {
    this.autoSelectAgences = this.perimetreByDefault.agence;
      this.perimetreByDefaultAgence = false;
      // delete this.perimetreByDefault.agence;
    }
    if (this.isAgencesHidden()) {
      this.agencesInactive = true;
    }
    this.agencesList.unshift(new ModelOption(this.translateService.instant('HOME.TABLE.COLUMNS.AGENCES'), ''));
  }

  reInitVendeurs() {
  //  console.log('4-tabVendeurs.length' + this.vendeursList.length);
    if (this.vendeursList.length === 1) {
      this.disabledVendeurs = true;
      this.autoSelectVendeurs = this.vendeursList[0].value;
      this.hiddenVendeurs = true;
    }
    if (this.vendeursList.length > 1) {
      this.disabledVendeurs = false;
      this.perimetreRechercheIsReady = true;
    //  console.log('perimetreRechercheIsReady for Vendeur');
    }
    if (this.perimetreByDefault !== undefined && this.perimetreByDefaultVendeur) {
     this.autoSelectVendeurs = this.perimetreByDefault.vendeur;
      this.perimetreByDefaultVendeur = false;
     // delete this.perimetreByDefault.vendeur;
    }
    if (this.isVendeursHidden()) {
      this.vendeursInactive = true;
    }
    this.vendeursList.unshift(new ModelOption(this.translateService.instant('HOME.TABLE.COLUMNS.VENDEURS'), ''));
  }

  cleanApporteurs() {
    this.autoSelectMarches = null;
    this.apporteursList = [];
    this.apporteursValue = null;
    delete this.perimetre.apporteur;
    this.disabledApporteurs = true;
    this.autoSelectApporteurs = null;
    this.hiddenApporteurs = false;
  }

  cleanAgences() {
    this.autoSelectAgences = null;
    this.agencesValue = null;
    this.agencesList = [];
    delete this.perimetre.agence;
    this.disabledAgences = true;
    this.autoSelectAgences = null;
    this.hiddenAgences = false;
  }

  cleanVendeurs() {
    this.autoSelectVendeurs = null;
    this.vendeursValue = null;
    this.vendeursList = [];
    delete this.perimetre.vendeur;
    this.disabledVendeurs = true;
    this.autoSelectVendeurs = null;
    this.hiddenVendeurs = false;
  }

  getMarchesChange() {
  //  console.log('1-getMarchesChange()');
    delete this.perimetre.marche;
    this.cleanApporteurs();
    this.cleanAgences();
    this.cleanVendeurs();
    if (this.marchesValue !== undefined && this.marchesValue.value) {
      this.loadChild({ type: this.perimetreService.APPORTEURS, id: this.marchesValue.value });
    } else {
      this.loadChild({ type: this.perimetreService.MARCHES });
    }
    this.perimetreEmitFunction();
  }
  getApporteursChange() {
  //  console.log('2-getApporteursChange()');
    delete this.perimetre.apporteur;
    this.cleanAgences();
    this.cleanVendeurs();
    if (this.apporteursValue !== undefined && this.apporteursValue.value) {
     this.loadChild({ type: this.perimetreService.AGENCES, id: this.apporteursValue.value });
    }
    this.perimetreEmitFunction();
  }
  getAgencesChange() {
  //  console.log('3-getAgencesChange()');
   delete this.perimetre.agence;
   this.cleanVendeurs();
   if (this.agencesValue !== undefined && this.agencesValue.value) {
     this.loadChild({ type: this.perimetreService.VENDEURS, id: this.agencesValue.value });
   }
   this.perimetreEmitFunction();
  }
  getVendeursChange() {
  //  console.log('4-getVendeursChange()');
   delete this.perimetre.vendeur;
   if (this.vendeursValue !== undefined && this.vendeursValue.value) {
     this.perimetre.vendeur = this.vendeursValue.value;
    // this.loadChild({ type: this.perimetreService.VENDEURS, id: this.agencesValue.value });
   }
   this.perimetreEmitFunction();
  }

  isMarchesHidden() {
    if (this.hiddenMarches) {
      return true;
    } else {
      return false;
    }
  }
  isApporteursHidden() {
    if (this.hiddenMarches && this.hiddenApporteurs) {
      return true;
    } else {
      return false;
    }
  }
  isAgencesHidden() {
    if (this.hiddenMarches && this.hiddenApporteurs && this.hiddenAgences) {
      return true;
    } else {
      return false;
    }
  }
  isVendeursHidden() {
   if (this.hiddenMarches && this.hiddenApporteurs && this.hiddenAgences && this.hiddenVendeurs) {
    return true;
   } else {
    return false;
   }
  }

  perimetreEmitFunction() {
    if (this.isVendeursHidden()) {
      this.perimetreEmit.emit(undefined);
    } else if (this.isAgencesHidden()
      && !(this.vendeursValue && this.vendeursValue.value)) {
      this.perimetreEmit.emit(undefined);
    } else if (this.isApporteursHidden()
        && !(this.agencesValue && this.agencesValue.value)) {
      this.perimetreEmit.emit(undefined);
    } else if (this.isMarchesHidden()
       && !(this.apporteursValue && this.apporteursValue.value)) {
      this.perimetreEmit.emit(undefined);
    } else {
    //  console.log(this.perimetre);
      this.perimetreEmit.emit(this.perimetre);
    }

  }
}
