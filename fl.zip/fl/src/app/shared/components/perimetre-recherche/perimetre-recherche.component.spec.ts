import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerimetreRechercheComponent } from './perimetre-recherche.component';

describe('PerimetreRechercheComponent', () => {
  let component: PerimetreRechercheComponent;
  let fixture: ComponentFixture<PerimetreRechercheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerimetreRechercheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerimetreRechercheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
