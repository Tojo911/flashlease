import { Component, OnInit } from '@angular/core';
import { PerimetreService } from '../../../services/perimetre/perimetre.service';
import { Perimetre } from '../../../models/perimetre';
import { ModelOption } from '../../../models/option-model';
import Global from '../../../models/global-functions';

// https://www-homo.flashlease.com/flashlease/ddf

@Component({
  selector: 'app-perimetre-select-avancee',
  templateUrl: './perimetre-select-avancee.component.html',
  styleUrls: ['./perimetre-select-avancee.component.scss']
})
export class PerimetreSelectAvanceeComponent implements OnInit {

  perimetreCurrent: PerimetreModelOption;
  perimetreSelectedList: PerimetreModelOption[] = [];
  marchesList: PerimetreModelOption[] = [];
  apporteursList: PerimetreModelOption[] = [];
  agencesList: PerimetreModelOption[] = [];
  vendeursList: PerimetreModelOption[] = [];

  constructor(
    public perimetreService: PerimetreService,
  ) {}

  ngOnInit() {
    const periCurTmp: PerimetreModelOption = {
      marcheLibelle: 'FRANFINANCE',
      marche: '19',
      type: '/marches'
    };
    this.perimetreSelectedList = [periCurTmp];
    this.loadChild({ type: this.perimetreService.MARCHES });
  }

  loadChild(ref?: PerimetreModelOption) {
    switch (ref.type) {
      case this.perimetreService.MARCHES:
        console.log('loadChild Marches');
        this.perimetreCurrent = ref;
        this.perimetreService.getMarches().subscribe(it => {
          const tabMarches = <any>it.content;
          const tabMarchesTemp = [];
          tabMarches.map(element => {
            const unMarches: PerimetreModelOption = {
              marcheLibelle : element.libelle,
              marche : element.id + '',
              type : this.perimetreService.MARCHES
            };
            tabMarchesTemp.push(unMarches);
          });
          this.marchesList = this.updateList(tabMarchesTemp);
      });
        break;
        case this.perimetreService.APPORTEURS:
        console.log('loadChild Apporteur');
        this.perimetreCurrent = ref;
        this.perimetreService.getApporteurs(ref.marche).subscribe(it => {
          const tabApporteurs = <any>it.content;
         const tabApporteursTemp = [];
          tabApporteurs.map(element => {
            const unApporteur: PerimetreModelOption = {
              marcheLibelle : ref.marcheLibelle,
              marche : ref.marche,
              apporteurLibelle : element.libelle,
              apporteur : element.id + '',
              /*
              checked : this.isChecked(element),
              indeterminate : this.isIndeterminate(element),
              opened : this.isOpened(element),
              disabled : this.isDisabled(element),*/
              type : this.perimetreService.APPORTEURS
            };
            tabApporteursTemp.push(unApporteur);
          });
          this.apporteursList = this.updateList(tabApporteursTemp);

        });
        break;
        case this.perimetreService.AGENCES:
        console.log('loadChild Agence');
        this.perimetreCurrent = ref;
        this.perimetreService.getAgences(ref).subscribe(it => {
          const tabAgences = <any>it.content;
          const tabAgencesTemp = [];
          tabAgences.map(element => {
            const uneAgence: PerimetreModelOption = {
              marcheLibelle : ref.marcheLibelle,
              marche : ref.marche,
              apporteurLibelle : ref.apporteurLibelle,
              apporteur : ref.apporteur,
              agenceLibelle : element.libelle,
              agence : element.id + '',
              /*
              checked : this.isChecked(element),
              indeterminate : this.isIndeterminate(element),
              opened : this.isOpened(element),
              disabled : this.isDisabled(element),*/
              type : this.perimetreService.AGENCES
            };
            tabAgencesTemp.push(uneAgence);
          });
          this.agencesList = tabAgencesTemp;
        });
        break;
        case this.perimetreService.VENDEURS:
        console.log('loadChild Vendeur');
        this.perimetreCurrent = ref;
        this.perimetreService.getVendeurs(ref).subscribe(it => {
          const tabVendeurs = <any>it.content;
          const tabVendeursTemp = [];
          tabVendeurs.map(element => {
            const unVendeur: PerimetreModelOption = {
              marcheLibelle : ref.marcheLibelle,
              marche : ref.marche,
              apporteurLibelle : ref.apporteurLibelle,
              apporteur : ref.apporteur,
              agenceLibelle : ref.agenceLibelle,
              agence : ref.agence,
              vendeurLibelle : element.prenom + ' ' + element.nom,
              vendeur : element.id + '',
              /*
              checked : this.isChecked(element),
              indeterminate : this.isIndeterminate(element),
              opened : this.isOpened(element),
              disabled : this.isDisabled(element),*/
              type : this.perimetreService.VENDEURS
            };
            tabVendeursTemp.push(unVendeur);
          });
          this.vendeursList = tabVendeursTemp;
        });
        break;
      default:
        console.log(ref);
        break;
    }
  }

  getApporteursListByMarche(item: PerimetreModelOption) {
      console.log('1-getApporteurListByMarcheId()');
      this.cleanApporteurs();
      this.cleanAgences();
      this.cleanVendeurs();
      if (item) {
        this.perimetreCurrent.type = this.perimetreService.APPORTEURS;
        this.perimetreCurrent.marche = item.marche;
        this.perimetreCurrent.marcheLibelle = item.marcheLibelle;
        this.loadChild(this.perimetreCurrent);
      // this.perimetreEmitFunction();
    }
  }
  getAgencesListByApporteur(item: PerimetreModelOption) {
    console.log('2-getAgencesListByApporteur()');
    this.cleanAgences();
    this.cleanVendeurs();
    if (item) {
      this.perimetreCurrent.type = this.perimetreService.AGENCES;
      this.perimetreCurrent.apporteur = item.apporteur;
      this.perimetreCurrent.apporteurLibelle = item.apporteurLibelle;
      this.loadChild(this.perimetreCurrent);
    // this.perimetreEmitFunction();
    }
  }

  getVendeursListByAgence(item: PerimetreModelOption) {
    console.log('3-getVendeursListByAgence()');
    this.cleanVendeurs();
    if (item) {
      this.perimetreCurrent.type = this.perimetreService.VENDEURS;
      this.perimetreCurrent.agence = item.agence;
      this.perimetreCurrent.agenceLibelle = item.agenceLibelle;
      this.loadChild(this.perimetreCurrent);
    // this.perimetreEmitFunction();
    }
  }

  verifCheck(item: PerimetreModelOption) {
    console.log('verifCheck ' + item.type + ' ' + JSON.stringify(item));
    if (item.checked) {
      console.log('uncheck');
      // on met à jour le périmètre sélectionné
      this.updateSelectedListByUncheck(item);
      // on met à jour les listes affichées : marches / apporteurs / agences / vendeurs
       const list = this.marchesList;
       this.marchesList = this.updateListByUncheck(list);

    } else {
      console.log('check');
      // on ajoute l élément selectionné
      this.perimetreSelectedList.push(item);
      // on met à jour le périmètre sélectionné : les enfants à décocher
      this.updateSelectedListByCheck(item);
      // on met à jour les listes affichées : marches / apporteurs / agences / vendeurs

      this.marchesList = this.updateListByCheck(this.marchesList);
   // this.apporteursList = this.updateList(this.apporteursList);
   // this.agencesList = this.updateList(this.agencesList);
   // this.vendeursList = this.updateList(this.vendeursList);
    }
  }
  updateSelectedListByUncheck(item: PerimetreModelOption) {
    console.log('uncheck : ' + item.type);
    // on récupère la liste des items à décocher
    let list: PerimetreModelOption[] = [];
    switch (item.type) {
      case this.perimetreService.MARCHES:
        list = this.perimetreSelectedList.filter(x => x.marche === item.marche).map(x => x);
      break;
      case this.perimetreService.APPORTEURS:
      list = this.perimetreSelectedList.filter(x => x.apporteur === item.apporteur).map(x => x);
      break;
      case this.perimetreService.AGENCES:
      list = this.perimetreSelectedList.filter(x => x.agence === item.agence).map(x => x);
      break;
      case this.perimetreService.VENDEURS:
      list = this.perimetreSelectedList.filter(x => x.vendeur === item.vendeur).map(x => x);
      break;
      default:
        console.log('uncheck : No Type');
        break;
    }
    // on supprime la liste des items à décocher
    list.map(x => {
      const i = this.perimetreSelectedList.indexOf(x);
      if (i !== -1) { this.perimetreSelectedList.splice(i, 1); }
    });
  }

  updateSelectedListByCheck(item: PerimetreModelOption) {
    let list: PerimetreModelOption[] = [];
    switch (item.type) {
      case this.perimetreService.MARCHES:
        list = this.perimetreSelectedList.filter(x => x.marche === item.marche && x.type !== item.type).map(x => x);
      break;
      case this.perimetreService.APPORTEURS:
      list = this.perimetreSelectedList.filter(x => x.apporteur === item.apporteur && x.type !== item.type).map(x => x);
      break;
      case this.perimetreService.AGENCES:
      list = this.perimetreSelectedList.filter(x => x.agence === item.agence && x.type !== item.type).map(x => x);
      break;
      case this.perimetreService.VENDEURS:
      list = this.perimetreSelectedList.filter(x => x.vendeur === item.vendeur && x.type !== item.type).map(x => x);
      break;
      default:
        console.log('uncheck : No Type');
        break;
    }
    list.map(x => {
      const i = this.perimetreSelectedList.indexOf(x);
      if (i !== -1) { this.perimetreSelectedList.splice(i, 1); }
    });
  }

  updateList(list: PerimetreModelOption[]): PerimetreModelOption[] {
    list.map(x => {
     x.checked = this.isChecked(x);
      x.indeterminate = this.isIndeterminate(x);
      x.opened = this.isOpened(x);
      x.disabled = this.isDisabled(x);
    });
    return list;
  }

  updateListByCheck(list: PerimetreModelOption[]): PerimetreModelOption[] {
    list.map(x => {
      x.indeterminate = this.isIndeterminate(x);
      x.opened = this.isOpened(x);
      x.disabled = this.isDisabled(x);
    });
    return list;
  }

  updateListByUncheck(list: PerimetreModelOption[]): PerimetreModelOption[] {
    list.map(x => {
      x.indeterminate = this.isIndeterminate(x);
      x.opened = this.isOpened(x);
      x.disabled = this.isDisabled(x);
    });
    return list;
  }

  isChecked(item: PerimetreModelOption) {
    switch (item.type) {
      case this.perimetreService.MARCHES:
         const i = this.perimetreSelectedList.findIndex(x => x.marche === item.marche && x.type === item.type);
         if (i !== -1) { return true; }
      break;
      case this.perimetreService.APPORTEURS:
     // list = this.perimetreSelectedList.filter(x => x.apporteur === item.apporteur).map(x => x);
      break;
      case this.perimetreService.AGENCES:
     // list = this.perimetreSelectedList.filter(x => x.agence === item.agence).map(x => x);
      break;
      default:
        console.log('isChecked : No Type');
   //     return false;
    }

  }
  isIndeterminate(item: PerimetreModelOption) {
    switch (item.type) {
      case this.perimetreService.MARCHES:
         const i = this.perimetreSelectedList.findIndex(x => x.marche === item.marche && x.type !== item.type);
         if (i !== -1) { return true; } else { return false; }
      case this.perimetreService.APPORTEURS:
     // list = this.perimetreSelectedList.filter(x => x.apporteur === item.apporteur).map(x => x);
      break;
      case this.perimetreService.AGENCES:
     // list = this.perimetreSelectedList.filter(x => x.agence === item.agence).map(x => x);
      break;
      default:
        console.log('isIndeterminate : No Type');
        return false;
    }
  }
  isOpened(item: PerimetreModelOption) {
    switch (item.type) {
      case this.perimetreService.MARCHES:
        if (this.perimetreCurrent.marche === item.marche) {
          return true;
        } else {
          return false;
        }
      case this.perimetreService.APPORTEURS:
     // list = this.perimetreSelectedList.filter(x => x.apporteur === item.apporteur).map(x => x);
      break;
      case this.perimetreService.AGENCES:
     // list = this.perimetreSelectedList.filter(x => x.agence === item.agence).map(x => x);
      break;
      default:
        console.log('isIndeterminate : No Type');
        return false;
    }
  }
  isDisabled(item: PerimetreModelOption) {
    return false;
  }

  cleanApporteurs() {
    delete this.perimetreCurrent.apporteur;
    delete this.perimetreCurrent.apporteurLibelle;
    this.apporteursList = [];
  }

  cleanAgences() {
    delete this.perimetreCurrent.agence;
    delete this.perimetreCurrent.agenceLibelle;
    this.agencesList = [];
  }

  cleanVendeurs() {
    delete this.perimetreCurrent.vendeur;
    delete this.perimetreCurrent.vendeurLibelle;
    this.vendeursList = [];
  }
}


export class PerimetreModelOption {
  public marche?: string;
  public marcheLibelle?: string;
  public apporteur?: string;
  public apporteurLibelle?: string;
  public agence?: string;
  public agenceLibelle?: string;
  public vendeur?: string;
  public vendeurLibelle?: string;
  public checked?: boolean;
  public indeterminate?: boolean;
  public opened?: boolean;
  public disabled?: boolean;
  public type?: string;
}

