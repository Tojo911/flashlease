import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerimetreSelectAvanceeComponent } from './perimetre-select-avancee.component';

describe('PerimetreSelectAvanceeComponent', () => {
  let component: PerimetreSelectAvanceeComponent;
  let fixture: ComponentFixture<PerimetreSelectAvanceeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerimetreSelectAvanceeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerimetreSelectAvanceeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
