import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  AfterViewChecked,
  Inject
} from '@angular/core';
import * as func from '../../../models/global-functions';
import { TranslateService } from '@ngx-translate/core';
// import { AuthService } from '../../../services/auth/auth.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.scss']
})
export class DialogBoxComponent implements OnInit {

  private commentaire: string;
  private currentDate = new Date();

  constructor(
    public dialogRef: MatDialogRef<DialogBoxComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData)  {}

  ngOnInit() {
      this.currentDate = new Date();
    }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

export interface DialogData {
  title: number;
  content: any;
}

