import { NgModule } from '@angular/core';
import { AssuranceComponent } from './assurance/assurance.component';
import { MaterialModule } from '../modules/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { WidgetsModule } from '../widgets/widgets.module';
import { DossierInfoComponent } from './dossier-info/dossier-info.component';
import { PerimetreSelectComponent } from './perimetre-select/perimetre-select.component';
import { DureeOptionsComponent } from './duree-options/duree-options.component';
import { DirectivesModule } from '../../directives/directives.module';

import { TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { TableComponent } from './table/table.component';
import { PhaseDataListComponent } from './phase-data-list/phase-data-list.component';
import { AppModule } from '../../app.module';
import { RechercheAvanceeComponent } from './recherche-avancee/recherche-avancee.component';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
import { PerimetreRechercheComponent } from './perimetre-recherche/perimetre-recherche.component';
import { PerimetreSelectAvanceeComponent } from './perimetre-select-avancee/perimetre-select-avancee.component';


export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient);
}

const list = [
  AssuranceComponent,
  DossierInfoComponent,
  PerimetreSelectComponent,
  DureeOptionsComponent,
  PhaseDataListComponent,
  TableComponent,
  RechercheAvanceeComponent
];

@NgModule({
  declarations: [...list, DialogBoxComponent, PerimetreRechercheComponent, PerimetreSelectAvanceeComponent],
  imports: [
    MaterialModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DirectivesModule,
    WidgetsModule,

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  exports: list
})
export class ComponentsModule {}
