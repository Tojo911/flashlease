import {
  Component,
  OnInit,
  Input,
  Output,
  SimpleChanges,
  OnChanges,
  EventEmitter,
  OnDestroy,
  ViewChild
} from '@angular/core';
import saveAs from 'file-saver';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { ModelOption } from '../../../models/option-model';
import { ItemTableInfo } from '../../../models/item-table-info';

import {
  TableColumnDefinitionModel,
  Requestable
} from '../../../models/table-column-definition-model';
import { KpiModel } from '../../../models/kpimodel';
import {
  CritereRechercheInfo,
  CriteresModelToMap
} from '../../../models/critere-recherche-info';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { map } from 'rxjs/internal/operators/map';
import { DossierInfo } from '../../../models/dossier-info';
import { Subscription, Subject, Observable } from 'rxjs';
import { AuthService } from '../../../services/auth/auth.service';
import { Perimetre } from '../../../models/perimetre';
import { HomeTabEnum } from '../../../models/enums/home-tab.enum';
import { ExportService } from '../../../services/export/export.service';
import { KpiService } from '../../../services/kpi/kpi.service';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { RachatService } from '../../../services/rachat/rachat.service';
import { CustomSearch } from './CustomSearch';

@Component({
  selector: 'app-phase-data-list',
  templateUrl: './phase-data-list.component.html',
  styleUrls: ['./phase-data-list.component.scss']
})
export class PhaseDataListComponent implements OnInit, OnChanges, OnDestroy {
  @Input()
  title: string;
  @Input()
  customSearch: CustomSearch;
  @Input()
  isExportAuth: boolean;
  @Input()
  selectedKpiStatut: KpiModel;
  @Output()
  selectedKpiStatutChange = new EventEmitter<KpiModel>();
  @Input()
  tableColumnsDefinition: TableColumnDefinitionModel[];
  @Input()
  datasource: any[];
  @Input()
  statusList: ModelOption[];
  @Input()
  perimetres: Perimetre[];
  @Input()
  statusComList: ModelOption[];
  @Input()
  tabIndex: number;
  @Input()
  isExportRole = false;
  @Input()
  isSirenRequired = false;
  @Output()
  reinitialiseClickEvent: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  rowClicked: EventEmitter<any> = new EventEmitter<any>();

  private hasFilterParam = false;
  private dataAux: any[] = undefined;
  public showSearchBox = false;
  public showSearchBlock = false;
  public filterValue;
  public statut_param: ModelOption;
  public statut_com_param: ModelOption;
  public min = 0;
  public max = 1000;
  public requestFields: Requestable[];
  public montant_param = [this.min, this.max];
  public date_param: any[];
  public showSpinner = false;
  public showAdvancedCriteres = false;
  public expandedSearchPanel = false;
  private critereRechercheModelExport: CritereRechercheInfo;
  public kpiCriteres: CriteresModelToMap;
  private searchSubscribe: Subscription;
  private criteresModelEmitted: CritereRechercheInfo = new CritereRechercheInfo();
  public show = false;
  public loading = false;
  // permet de détecter que les kpi ont été setté recemment pour differencier d'une requete induite par une modif autre que les kpi.
  private kpiClicked = false;
  private buttonExportDisabled = false;
  @ViewChild('collapsePanel')
  collapsePanel: any;
  subscriptionAdvancedSearch: Subscription;

  constructor(
    private translateService: TranslateService,
    private rechercheService: RechercheService,
    private authService: AuthService,
    private exportService: ExportService,
    private kpiService: KpiService,
    private router: Router,
    public snackBar: MatSnackBar
  ) {
    this.rechercheService.searchSubject.subscribe(rech => {
      if (rech.isLoading || rech.isLastRequest) {
        this.loading = rech.isLoading;
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['selectedKpiStatut']) {
      this.kpiClicked = !changes['selectedKpiStatut'].firstChange
        ? true
        : false;
      if (!changes.selectedKpiStatut.currentValue) {
        this.initialiseData();
      }
    }
    if (
      changes['datasource'] &&
      changes['datasource'].firstChange &&
      this.tabIndex === 3
    ) {
      // Affichage par défaut du mode custom
      this.datasource = [];
      this.showSpinner = false;
      this.show = true;
    }
    if (changes['datasource'] && changes['datasource'].currentValue) {
      this.dataAux = this.datasource;
      if (this.dataAux && this.dataAux.length > 0) {
        this.showSpinner = false;
      }
    }

    if (
      changes['tabIndex'] &&
      changes['tabIndex'].currentValue !== changes['tabIndex'].previousValue
    ) {
      // this.collapsePanel.close();
      this.resetSearch();
    }
    if (
      changes['perimetres'] &&
      changes['perimetres'].currentValue !== changes['perimetres'].previousValue
    ) {
      this.criteresModelEmitted.phase = HomeTabEnum[this.tabIndex];
      this.criteresModelEmitted.perimetres = this.perimetres;
      if (!changes['perimetres'].firstChange) {
        this.search(this.criteresModelEmitted);
      }
    }
    if (
      changes.tableColumnsDefinition &&
      changes.tableColumnsDefinition.currentValue
    ) {
      this.requestFields = this.tableColumnsDefinition
        .filter(it => it.requestable)
        .map(it => it.requestable);
    }
  }
  ngOnInit() {}

  applyFilter(value: string) {
    this.filterValue = value;
  }

  resetSearch() {
    this.filterValue = '';
    this.showSearchBox = false;
    // this.datasource = this.dataAux;
  }

  actionOnClick(item) {
    this.rowClicked.emit(item);
  }

  initialiseData(event?) {
    this.criteresModelEmitted = new CritereRechercheInfo();
    this.criteresModelEmitted.phase = HomeTabEnum[this.tabIndex];
    this.criteresModelEmitted.perimetres = this.perimetres;
    this.selectedKpiStatut = null;
    if (this.searchSubscribe) {
      this.searchSubscribe.unsubscribe();
      this.search(this.criteresModelEmitted);
    }
    // this.datasource = this.dataAux;
  }
  search(critereModel: CritereRechercheInfo) {
    if (this.tabIndex === HomeTabEnum.PARC) {
    //  console.log('isSirenRequired : ' + this.isSirenRequired);
    }
    if (this.kpiClicked) {
      this.kpiClicked = false;
    } else {
      this.kpiService.criteriaHasChanged.next(critereModel);
    }
    this.criteresModelEmitted = critereModel;
   // console.log('criteresModelEmitted : ' + JSON.stringify(this.criteresModelEmitted));
    let filteredList;
    if (critereModel) {
      if (this.searchSubscribe) {
        this.searchSubscribe.unsubscribe();
      }


      this.showSpinner = true;
      this.searchSubscribe = (!this.customSearch
        ? this.rechercheService.advancedSearch(critereModel).pipe(
            map(res => {
              return {
                list: this.rechercheService.formatDataTableItem(
                  res.content as DossierInfo[]
                ),
                isLastRequest: res.isLastRequest,
                criteres: res.criteres
              };
            })
          )
        : (this.customSearch.searchMeth(
            this.customSearch,
            critereModel
          ) as Observable<any>)
      ).subscribe(
        res => {

          if (this.customSearch) {
            this.customSearch.callBackMeth(this.customSearch, {
              res: res,
              ref: this
            });
          } else {
            filteredList = res.list;
            if (filteredList !== undefined && res.isLastRequest) {
              console.log(filteredList);
              this.datasource = filteredList;
              this.showSpinner = false;
              this.loading = false;
            }
          }
        },
        error => {
          console.log('error');
          this.showSpinner = false;
          this.loading = false;
          this.datasource = [];
        }
      );
    }
  }

  export() {
    switch (this.tabIndex) {
      case HomeTabEnum.DDF:
        {
          this.exportService.exportDdf(this.criteresModelEmitted).subscribe(
            res => {
              const blob = new Blob([res], {
                type: 'application/vnd.ms-excel'
              });
              // const file = new File([blob], this.getFileNameExport(), { type: 'application/vnd.ms-excel' });
              saveAs(blob, this.getFileNameExport());
              // saveAs(file);
            },
            error => {
              console.log(error);
              if (error.status === 417) {
                this.openSnack(
                  this.translateService.instant('HOME.SEUIL_DEPASSE'),
                  '',
                  5000
                );
              }
            }
          );
        }
        break;
      case HomeTabEnum.MONTAGE:
        {
          if (
            !this.criteresModelEmitted.numeroAccord &&
            !this.criteresModelEmitted.numeroSIREN &&
            !this.criteresModelEmitted.statuts &&
            !this.criteresModelEmitted.idMarche &&
            !this.criteresModelEmitted.idApporteur &&
            !this.criteresModelEmitted.idAgence
          ) {
            this.openSnack(
              this.translateService.instant('HOME.SELECT_CRITERIA'),
              '',
              5000
            );
          }
          delete this.criteresModelEmitted.perimetres;
          this.exportService.exportMontage(this.criteresModelEmitted).subscribe(
            res => {
              const blob = new Blob([res], {
                type: 'application/vnd.ms-excel'
              });
              /*  const file = new File([blob], this.getFileNameExport(), { type: 'application/vnd.ms-excel' });
             saveAs(file);*/
              saveAs(blob, this.getFileNameExport());
            },
            error => {
              console.log(error);
              if (error.status === 417) {
                this.openSnack(
                  this.translateService.instant('HOME.SEUIL_DEPASSE'),
                  '',
                  5000
                );
              }
            }
          );
        }
        break;
      case HomeTabEnum.PARC: {
        delete this.criteresModelEmitted.perimetres;
        this.exportService.exportParc(this.criteresModelEmitted).subscribe(
          res => {
            const blob = new Blob(['\ufeff', res], { type: 'text/csv' });
            // const file = new File([blob], this.getFileNameExport(), { type: 'text/csv' });
            saveAs(blob, this.getFileNameExport());
          },
          error => {
            console.log(error);
            if (error.status === 417) {
              this.openSnack(
                this.translateService.instant('HOME.SEUIL_DEPASSE'),
                '',
                5000
              );
            }
          }
        );
      }
    }
  }

  getFileNameExport() {
    const date = new Date();
    const time = date.getTime();
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    switch (this.tabIndex) {
      case HomeTabEnum.DDF:
        return (
          'Dashboard_' + day + '_' + month + '_' + year + '_' + time + '.xlsx'
        );
      case HomeTabEnum.MONTAGE:
        return (
          'Liste_de_travail_' +
          day +
          '_' +
          month +
          '_' +
          year +
          '_' +
          time +
          '.xlsx'
        );
      case HomeTabEnum.PARC:
        return (
          'Etat_de_parc_' + day + '_' + month + '_' + year + '_' + time + '.csv'
        );
    }
  }

  ngOnDestroy() {
    if (this.searchSubscribe) {
      this.searchSubscribe.unsubscribe();
    }
  }

  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
}
