import { Observable } from 'rxjs';

export class CustomSearch {
  public searchMeth: (ref: CustomSearch, _: any) => {};
  public callBackMeth: (ref: CustomSearch, _: any) => {};
  public params?: any;
  constructor(
    meth1: (ref: CustomSearch, _: any) => {},
    meth2: (ref: CustomSearch, _: any) => {}
  ) {
    this.searchMeth = meth1;
    this.callBackMeth = meth2;
  }
}
