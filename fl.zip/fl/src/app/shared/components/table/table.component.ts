import {
  Component,
  OnInit,
  Input,
  OnChanges,
  AfterViewInit
} from '@angular/core';
import {
  MatTableDataSource,
  MatSort,
  Sort,
  PageEvent,
  MatPaginator
} from '@angular/material';
import { ViewChild } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ItemTableInfo } from '../../../models/item-table-info';
import { AfterContentInit } from '@angular/core';
import { TableColumnDefinitionModel } from '../../../models/table-column-definition-model';
import { Observable, of, merge } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import Global from '../../../models/global-functions';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnChanges, OnInit, AfterViewInit {
  @Input()
  source: any[];
  @Input()
  pageSize = 10;
  @Input()
  selected: () => {};
  @Input()
  noPagination: boolean;
  @Input()
  loading: boolean;
  @Input()
  dynamicColumns: TableColumnDefinitionModel[];
  @Input()
  filterValue: string;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Output()
  rowClicked = new EventEmitter();
  @Output()
  rowDblClicked = new EventEmitter();
  @Output()
  sourceChange = new EventEmitter();
  @Input()
  isTitleOnTop: boolean;
  titleOnTop = '';
  public dataIsReady = false;
  public colsDefIsReady = false;
  public pageEvent: PageEvent;
  public displayedColumns: any[];
  public datasource = new MatTableDataSource([]);

  constructor(private trServ: TranslateService) {
    trServ.get(' ').subscribe(it => it);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes['filterValue'] &&
      changes['filterValue'].currentValue !== undefined &&
      changes['filterValue'].currentValue !==
        changes['filterValue'].previousValue
    ) {
      if (this.datasource.data.length > 0) {
        this.datasource.filter = this.filterValue.trim().toLowerCase();
      }
    }

    if (changes['source'] && changes['source'].currentValue !== undefined) {
      if (
        this.datasource.paginator &&
        this.datasource.paginator.pageIndex >= Global.getA(this.source).length / 10
      ) {
        this.datasource.paginator.pageIndex = 0;
      }
      this.dataIsReady = true;
      // this.datasource.data = changes['source'].currentValue.slice(0, 100);
      this.datasource = new MatTableDataSource(Global.getA(this.source).slice(0, 100));
      if (this.filterValue) {
        this.datasource.filter = this.filterValue.trim().toLowerCase();
      }
      setTimeout(() => {
        this.datasource.paginator = this.paginator;
      }, 0);
    }

    if (changes['dynamicColumns'] && changes['dynamicColumns'].currentValue) {
      this.colsDefIsReady = true;
      this.displayedColumns = this.dynamicColumns.filter(it => !it.hide).map(row => row.columnDef);
    }
    if (changes.isTitleOnTop && changes.isTitleOnTop.currentValue) {
      if (this.isTitleOnTop) {
        this.titleOnTop = 'titleUpperTable';
      }
    }
    /*if ( changes.pageSize && changes.pageSize.currentValue) {
      this.datasource.paginator.pageSize = this.pageSize;
      console.log(` this.datasource.paginator.pageSize: ${ this.datasource.paginator.pageSize}`);
    }*/
  }

  isValidDate(str) {
    const d = moment(str, 'DD/MM/YYYY');

    if (d == null || !d.isValid()) {
      return false;
    }

    return (
      str.indexOf(d.format('D/M/YYYY')) >= 0 ||
      str.indexOf(d.format('DD/MM/YYYY')) >= 0 ||
      str.indexOf(d.format('D/M/YY')) >= 0 ||
      str.indexOf(d.format('DD/MM/YY')) >= 0
    );
  }

  filterdishit(data, filter): boolean {
    if (data) {
      if (typeof data === 'string') {
        return data.indexOf(filter) !== -1;
      }
      if (typeof data === 'number') {
        const flag = (data + '').indexOf(filter) !== -1;
        try {
          const date = new Date(data);
          const day = date.getDate();
          const monthIndex = date.getMonth();
          const year = date.getFullYear();
          const minutes = date.getMinutes();
          const hours = date.getHours();
          const seconds = date.getSeconds();
          const myFormattedDate =
            day +
            '/' +
            (monthIndex + 1) +
            '/' +
            year +
            ' ' +
            hours +
            ':' +
            minutes +
            ':' +
            seconds;
          return myFormattedDate === '1/1/1970 1:1:52'
            ? flag
            : myFormattedDate.indexOf(filter) !== -1;
        } catch {
          return flag;
        }
      }
    }
  }
  ngOnInit() {}

  ngAfterViewInit() {
    this.datasource.sort = this.sort;
  }
  getClass(arr) {
    return arr.join(' ') + ' ' + this.titleOnTop;
  }
  _onRowClicked(row) {
    this.rowClicked.emit(row);
  }
  _onRowDblClicked(row) {
    this.rowDblClicked.emit(row);
  }
  oncellclick(column, row) {
    if (column && column.onclick) {
      column.onclick(row);
    }
  }
  itemBeenRead(item) {
    item.new = false;
  }

  getColumnValue(column: TableColumnDefinitionModel, row: any) {
    let val = column.cell(row);
    if (!val) {
      return '';
    }
    if (column.date) {
      val = Global.mapTimestampToDate(column.cell(row));
    }
    if (column.time) {
      if (column.date) {
        val +=
          this.trServ.instant('TIME_SEPARATOR') +
          Global.mapTimestampToTime(column.cell(row));
      } else {
        val = Global.mapTimestampToTime(column.cell(row));
      }
    }
    return val;
  }

  compareFunction(a: string, b: string) {
    a = a ? a : '';
    b = b ? b : '';
    if (!isNaN(+a) && !isNaN(+b)) {
      return +a < +b ? -1 : 1;
    }
    return a.toLowerCase() < b.toLowerCase() ? -1 : 1;
  }

  compare(a: string, b: string, d: string) {
    return this.compareFunction(a, b) * (d === 'asc' ? 1 : -1);
  }
  string2number(int) {
    const processed = int.replace(/ /g, '');
    return parseFloat(processed);
  }

  compareNumber(a, b, d) {
    return (
      (this.string2number(a) < this.string2number(b) ? -1 : 1) *
      (d === 'asc' ? 1 : -1)
    );
  }

  sortData(sort: Sort) {
    const data = this.datasource.data.slice();
    if (!sort.active || sort.direction === '') {
      this.datasource.data = data;
      return;
    }

    // Tri par default sur numéro de Siren pour le dashboard. Tojo 15/11/2018
    if (sort.active !== 'numSiren') {
      this.datasource.data = data.sort((a, b) => {
        if (a.numeroFL) {
          if (a.numeroFL < b.numeroFL) {
            return -1;
          } else if (a.numeroFL > b.numeroFL) {
            return 1;
          }
        }
      });
    }

    for (const element of this.dynamicColumns) {
      if (sort.active === element.columnDef) {
       // console.log(element.isNumeric);
        if (element.isNumeric) {
          this.datasource.data = data.sort((a, b) => {
            return this.compareNumber(
              element.cell(a),
              element.cell(b),
              sort.direction
            );
          });
        } else {
          this.datasource.data = data.sort((a, b) => {
            return this.compare(
              element.cell(a),
              element.cell(b),
              sort.direction
            );
          });
        }
        break;
      }
    }
  }
}
