import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-assurance',
  templateUrl: './assurance.component.html',
  styleUrls: ['./assurance.component.scss']
})
export class AssuranceComponent implements OnInit {
  @Input() list: any[];
  @Input() valueAssur: any;
  @Input() placeholder  = '';
  @Input() label = '';

  pourcentage = '';
  public pourcentageList = [
    { 'code': '332', 'id': 167, 'apporteur': null, 'libelle': '% du montant' },
    { 'code': '332', 'id': 168, 'apporteur': null, 'libelle': '% du ...' }
  ];

  constructor() { }

  ngOnInit() {
  }

}
