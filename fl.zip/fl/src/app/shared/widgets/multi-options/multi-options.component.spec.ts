import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiOptionsComponent } from './multi-options.component';

describe('MultiOptionsComponent', () => {
  let component: MultiOptionsComponent;
  let fixture: ComponentFixture<MultiOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
