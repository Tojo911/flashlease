import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  ViewChild,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { KpiModel } from '../../../models/kpimodel';
import { kpiStatusEnum } from '../../../models/enums/kpi-status.enum';
import { TranslateService } from '@ngx-translate/core';
import { KpiService } from '../../../services/kpi/kpi.service';

@Component({
  selector: 'app-kpi-number',
  templateUrl: './kpi-number.component.html',
  styleUrls: ['./kpi-number.component.scss']
})
export class KpiNumberComponent implements OnInit, OnChanges {
  @ViewChild('container')
  container;
  @Input()
  kpiModel: KpiModel;
  @Input()
  currentState: KpiModel;
  @Output()
  currentStateChange = new EventEmitter();
  public kpiStatusEnum = kpiStatusEnum;
  public statutValue;
  @Output()
  clicked = new EventEmitter();
  initCriteriaHasChanged = false;
  constructor(
    private translateService: TranslateService,
    private kpiService: KpiService
  ) {
    kpiService.criteriaHasChanged.subscribe(crit => {
      if (this.currentState && this.currentState === this.kpiModel) {
        this.currentState = null;
        this.clicked.emit(null);
        this.initCriteriaHasChanged = true;
       // this.currentStateChange.emit({data: {statuts: 'noChange'}});
        this.getSelectedClass();
        if (crit && !crit.statuts) {
          this.currentStateChange.emit(this.currentState);
        }
      }
    });
  }
  emitter() {
    if (this.currentState && this.currentState === this.kpiModel) {
      this.currentState = null;
      this.clicked.emit(null);
      this.getSelectedClass();
    } else {
      this.currentState = this.kpiModel;
      this.clicked.emit(this.kpiModel);
      this.getSelectedClass();
    }

    // Tojo : 26/12/2018 : correction JIRA 670 : forcer la mise a jour des KPI
    if (this.initCriteriaHasChanged) {
      this.initCriteriaHasChanged = false;
      this.currentStateChange.emit(null);
      setTimeout(() => {
        this.currentStateChange.emit(this.kpiModel);
      }, 10);
    } else {
      this.currentStateChange.emit(this.currentState);
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.currentState) {
      this.getSelectedClass();
    }
    if (changes.kpiModel) {
      this.getKpiValue(this.kpiStatusEnum[this.kpiModel.libelle]);
    }
  }
  ngOnInit() {}

  getSelectedClass() {
    /*if (!this.currentState) {
      return ;
    }*/
    if (
      this.kpiModel &&
      this.currentState &&
      this.currentState.libelle === this.kpiModel.libelle
    ) {
      this.container.nativeElement.className +=
        ' ' + this.kpiModel.libelle + 'Selected';
    } else {
      this.container.nativeElement.className = this.container.nativeElement.className.split(
        ' '
      )[0];
    }
  }

  getKpiValue(kpi: kpiStatusEnum) {
    this.translateService.get('KPIS').subscribe(t => {
      switch (kpi) {
        case kpiStatusEnum.saines:
          this.statutValue = this.translateService.instant(
            'HOME.TABS.PARC.KPIS.SAINS'
          );
          break;
        case kpiStatusEnum.amiables:
          this.statutValue = this.translateService.instant(
            'HOME.TABS.PARC.KPIS.AMIABLE'
          );
          break;
        case kpiStatusEnum.expirentMoins6Mois:
          this.statutValue = this.translateService.instant(
            'HOME.TABS.PARC.KPIS.EXPIRENT'
          );
          break;

        case kpiStatusEnum.contentieuses:
          this.statutValue = this.translateService.instant(
            'HOME.TABS.PARC.KPIS.IMPAYES'
          );
          break;
        default:
          return;
      }
    });
  }

  // export const KpiMap: Map<string, string> = new Map([
  //   ['saines', b.instant('TABS.PARC.KPIS.SAINS')],
  //   ['amiables', b.instant('TABS.PARC.KPIS.AMIABLE')],
  //   ['expirentMoins6Mois', b.instant('TABS.PARC.KPIS.EXPIRENT')],
  //   ['contentieuses', b.instant('TABS.PARC.KPIS.IMPAYES')]
  // ]);
}
