/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { KpiNumberComponent } from './kpi-number.component';

describe('KpiNumberComponent', () => {
  let component: KpiNumberComponent;
  let fixture: ComponentFixture<KpiNumberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiNumberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
