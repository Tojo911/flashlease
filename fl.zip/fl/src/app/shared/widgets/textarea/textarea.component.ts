import { Component, Input, Output, EventEmitter } from '@angular/core';

/**
 * Composant Textarea
 * @param label (optionnel)	Saisie d'un label
 * @param placeholder (optionnel) Saisie d'un placeholder
 * @param description (optionnel) Saisie d'une description
 *
 * @attr label-on-left (optionnel) Force le placement du label sur la gauche du champ de saisie
 */

@Component({
  selector: 'app-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.scss']
})
export class TextareaComponent {
  @Input() label: string = null;
  @Input() placeholder: string = null;
  @Input() description: string = null;
  @Input() value: string = null;
  @Input() readonly: boolean;
  @Input() innerHTML: string;
  @Input() isTextArea = true;
  @Output() valueChange = new EventEmitter();
  @Input() maxLength: number;

  change(newValue) {
    this.value = newValue;
    // this.value = newValue;
    this.valueChange.emit(newValue);
  }
  changeTextAreaValue() {
    this.valueChange.emit(this.value);
  }
}
