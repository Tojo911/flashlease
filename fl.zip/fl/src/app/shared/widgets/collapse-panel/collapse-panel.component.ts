import { Component, Input, ViewChild } from '@angular/core';
import { MatExpansionPanel } from '@angular/material';

@Component({
  selector: 'app-collapse-panel',
  templateUrl: './collapse-panel.component.html',
  styleUrls: ['./collapse-panel.component.scss']
})
export class CollapsePanelComponent {
  @Input()
  title: string;
  @Input()
  icon: string;
  @Input()
  expanded = true;

  @ViewChild('panel')
  panel: MatExpansionPanel;

  close() {
    this.panel.close();
  }
}
