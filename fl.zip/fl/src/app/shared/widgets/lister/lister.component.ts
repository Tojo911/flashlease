import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { ModelOption } from '../../../models/option-model';

@Component({
  selector: 'app-lister',
  templateUrl: './lister.component.html',
  styleUrls: ['./lister.component.scss']
})
export class ListerComponent implements OnInit, OnChanges {
  @Input() values: ModelOption[] = [];
  @Input() validator: (_: any) => {};
  @Output() valuesChange = new EventEmitter<ModelOption[]>();
  @Output() errorValidation = new EventEmitter<any>();
  item: string;
  @Input() title: string;
  @Input() icon: string;
  constructor() {}
  ngOnInit() {}
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.values && changes.values.currentValue) {
      this.valuesChange.emit(this.values);
    }
  }
  add(e: Event) {
    if (e) {
      e.preventDefault();
    }
    console.log('add');
    if (this.item && this.item !== '') {
      if (this.validator && !this.validator(this.item)) {
        this.errorValidation.emit(this.item);
        return;
      }
      this.values = this.values
        ? [...this.values, ModelOption.setUniqueValue(this.item)]
        : [ModelOption.setUniqueValue(this.item)];
      this.item = null;
      this.valuesChange.emit(this.values);
    }
  }

  delete(val) {
    this.values = this.values.filter(it => it.libelle !== val);
    console.log('delete');
    this.valuesChange.emit(this.values);
  }
}
