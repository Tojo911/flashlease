import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputDatePickerMonthYearComponent } from './input-date-picker-month-year.component';

describe('InputDatePickerMonthYearComponent', () => {
  let component: InputDatePickerMonthYearComponent;
  let fixture: ComponentFixture<InputDatePickerMonthYearComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputDatePickerMonthYearComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputDatePickerMonthYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
