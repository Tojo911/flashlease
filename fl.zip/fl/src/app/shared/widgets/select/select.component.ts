import {
  Component,
  Input,
  ViewChild,
  EventEmitter,
  Output,
  ChangeDetectionStrategy,
  forwardRef,
  ViewEncapsulation,
  OnChanges,
  SimpleChanges,
  OnInit,
  AfterViewInit
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { ModelOption } from '../../../models/option-model';
import { TranslateService } from '@ngx-translate/core';
import { MatSelect } from '@angular/material';
/**
 * Composant Select
 * @param value	valeur selectionné par défaut
 * @param list tableau d'options envoyé directement au composant matérial mat-option
 * @param placeholder (optionnel) valeur affiché si aucunes valeur de sélectionnée
 * @param label (optionnel)	affichage d'un label au mpême principe que dans les inputs
 * @param description (optionnel) affichage d'une description au mpême principe que dans les inputs
 * @param multiple (optionnel) option pour autoriser le multi choix
 *
 * @Output valueChange two-way binding pour la valeur "value" avec possiblité de n'écouter que le retour.
 */
@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => SelectComponent)
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.Emulated
})
export class SelectComponent
  implements ControlValueAccessor, OnChanges, OnInit, AfterViewInit {
  @Input()
  value: ModelOption = null;
  @Input()
  defaultValue = true;
  @Input()
  values: ModelOption[] = [];
  @Input()
  forced: ModelOption[] = null;
  @Input()
  list: ModelOption[] = null;
  @Input()
  placeholder: string;
  @Input()
  disablePlaceHolder = true;
  @Input()
  label: string = null;
  @Input()
  description: string = null;
  @Input()
  multiple = false;
  @Input()
  defaultSort = true;
  @Input()
  selectedValue: string;
  @Input()
  disabled: boolean;
  @Input()
  direction: string;
  @Input()
  preset;
  @Input()
  autoClosedAfter: number;
  @Output()
  valueChange = new EventEmitter<string>();
  @Output()
  valuesChange = new EventEmitter<ModelOption[]>();
  @Output()
  beenForced = new EventEmitter<ModelOption[]>();
  @ViewChild('formField')
  formField;
  @ViewChild('select')
  select: MatSelect;
  private isBeingForced: boolean;
  onChange = (_: any) => {};
  onTouched = (_: any) => {};
  constructor(public translate: TranslateService) {}

  ngAfterViewInit() {
  }
  ngOnInit() {}
  ngOnChanges(changes: SimpleChanges) {
    // ajouté par Tojo 16/11/2018 traduction des listes + tri dans l'ordre croissant
    if (changes['list'] && changes['list'].currentValue) {
      if (this.list) {
        if (this.list.length > 0) {
          this.list.map(value => {
            value.libelle = this.translate.instant(value.libelle);
            // console.log(value.libelle);
          });
          if (this.defaultSort) {
            this.list = this.list.sort((a, b) =>
              a.libelle < b.libelle ? -1 : a.libelle > b.libelle ? 1 : 0
            );
          }
        }
      }
      if (this.list) {
        if (
          this.list.length > 0 &&
          this.preset &&
          (!this.value || !this.getListValue(this.value))
        ) {
          if (
            this.list.length > 0 &&
            this.preset &&
            (!this.value || !this.getListValue(this.value))
          ) {
            this.onUpdateValue(this.getPresetValue());
            this.onTouched(true);
          }
        }
      }
    }

    if (changes['value'] && this.getListValue(changes['value'].currentValue)) {
      this.value = this.getListValue(changes['value'].currentValue);
    }

    if (changes['forced']) {
      this.isBeingForced = true;
      this.resetMultiple();
      if (this.forced) {
        this.values = this.forced.map(it => this.getListValue(it));
        this.values = this.values.filter(it => it);
      } else {
        this.values = [];
      }
      this.valuesChange.emit(this.values);
      this.beenForced.emit(this.values);
      this.onUpdateValue(this.values);
      this.isBeingForced = false;
    }
    if (changes['forced'] && !changes['forced'].currentValue) {
      /* this.select.options.map(it => {
        it.deselect();
      } );
      // this.values = [];
     /* if (this.select) {
        this.select.selected = null;
        this.select.options.map(it => it.deselect());
      }*/
    }
  }
  resetMultiple() {
    if (this.select && this.select.options) {
      this.select.options.map(it => {
        it.deselect();
      });
    }
  }
  getListValue(val) {
    return this.isValInList(val, this.list);
  }
  isAlreadySelected(val) {
    return this.isValInList(val, this.values);
  }
  isValInList(val, list) {
    if (!val) {
      return null;
    }
    const res = list.find(
      it => val.value === it.value || val.libelle === it.libelle
    );
    if (res) {
      return res;
    } else {
      return null;
    }
  }
  getPresetValue() {
    const res = this.list.find(
      it => this.preset === it.value || this.preset === it.libelle
    );
    if (res) {
      return res;
    } else {
      return this.list[0];
    }
  }

  onUpdateValue(item) {
    this.value = item;
    this.onChange(item);
    this.valueChange.emit(item);
  }

  getPlaceHolder() {
    if (
      this.disablePlaceHolder &&
      this.value !== null &&
      this.value !== undefined &&
      !this.multiple
    ) {
      return '';
    } else {
      return this.placeholder;
    }

    /*if (this.multiple) {
      if (
        this.values === null ||
        this.values === undefined ||
        this.values.length === 0
      ) {
        return this.placeholder;
      } else {
        return '';
      }
    }
    if (this.value === null || this.value === undefined) {
      return this.placeholder;
    } else {
      return '';
    }*/
  }

  writeValue(value: any): void {
    if (!value) {
      this.resetMultiple();
    }
    if (this.multiple && value) {
      this.values = this.values ? this.values : [];
      if (!this.isAlreadySelected(value)) {
        this.values.push(value);
      }
      this.valuesChange.emit(this.values);
      this.onUpdateValue(this.values);
    }
    if (this.value && !this.multiple) {
      this.value = value;
    }
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  itemSelected(e, item) {
    if (e.source.selected) {
      this.writeValue(item);
    } else {
      if (this.values) {
        this.values = this.values.filter(it => it.libelle !== item.libelle);
      }
      this.valuesChange.emit(this.values);
      this.onUpdateValue(item);
    }
  }
}
