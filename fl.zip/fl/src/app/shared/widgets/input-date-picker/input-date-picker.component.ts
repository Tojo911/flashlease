import {
  Component,
  Input,
  ViewEncapsulation,
  Output,
  EventEmitter,
  forwardRef
} from '@angular/core';

import { FormControl, ReactiveFormsModule, ControlValueAccessor, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';

import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core';

/**
 * Composant Date picker
 * @param date (optionnel) Saisie d'une date
 * @param placeholder (optionnel) Saisie d'un placeholder
 *
 */
@Component({
  selector: 'app-input-date-picker',
  templateUrl: './input-date-picker.component.html',
  styleUrls: ['./input-date-picker.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => InputDatePickerComponent),
    }
  ],
  encapsulation: ViewEncapsulation.None
})
export class InputDatePickerComponent implements ControlValueAccessor {
  @Input() label: string;
  @Input() placeholder = 'Date';
  @Input() minDate = null;
  @Input() maxDate = null;
  @Output() dateChange = new EventEmitter();
  popupVisible = false;
  formControlDate = new FormControl();
  localDate = null;
  disabledf = false;
  onTouched: () => {};
  onChanged: () => {};

  @Input()
  value: Date;
  @Output()
  valueChange: EventEmitter<Date> = new EventEmitter();

  constructor(private dateAdapter: DateAdapter<any>) {
    dateAdapter.setLocale('fr');
  }

  writeValue(obj: any): void {
    this.value = obj;
    // this.onChanged();
  }
  registerOnChange(fn: any): void {
   this.onChanged = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
  @Input()
  set required(required: boolean) {
    if (required) {
      this.formControlDate.setValidators(Validators.required);
    }
  }

  @Input() // getter and setter de la date
  set date(date) {
    if (date !== null) {
      this.localDate = new Date(date);
    } else {
      this.localDate = null;
    }
    this.formControlDate = new FormControl(this.localDate);
  }
  get date() {
    return this.localDate;
  }

  @Input()
  set disabled(disabled) {
    this.disabledf = disabled;
    if (this.disabledf) {
      this.formControlDate.disable();
    } else {
      this.formControlDate.enable();
    }
  }

  get disabled() {
    return this.disabledf;
  }

  // détection de changement et renvoi automatique de la nouvelle valeur.
  onChange() {
    if (this.formControlDate.value === null) {
      this.localDate = null;
    } else {
      this.localDate = new Date(this.formControlDate.value);
    }
    this.writeValue(this.localDate);
    this.dateChange.emit(this.localDate);
  }
}
