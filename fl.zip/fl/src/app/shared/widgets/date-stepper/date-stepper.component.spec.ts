import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DateStepperComponent } from './date-stepper.component';

describe('DateStepperComponent', () => {
  let component: DateStepperComponent;
  let fixture: ComponentFixture<DateStepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DateStepperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
