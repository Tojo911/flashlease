import { Component, OnInit, Input, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';

@Component({
  selector: 'app-date-stepper',
  templateUrl: './date-stepper.component.html',
  styleUrls: ['./date-stepper.component.scss'],
})
export class DateStepperComponent implements OnInit {
  @Input()
  min: number;
  @Input()
  max: number;
  @Input()
  from: number;
  @Input()
  to: number;
  @Input()
  step: number;
  constructor() { }

  ngOnInit() {
  }

}
