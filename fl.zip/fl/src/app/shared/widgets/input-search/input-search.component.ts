import { Component, Output, EventEmitter, HostBinding } from '@angular/core';

/**
 * Composant Input Search
 * @Output valueChange (optionnel)	Renvoi de la nouvelle valeure de recherche
 */

@Component({
  selector: 'app-input-search',
  templateUrl: './input-search.component.html',
  styleUrls: ['./input-search.component.scss']
})
export class InputSearchComponent {
  @Output() valueChange = new EventEmitter();
  @HostBinding('class.has-input') hasInput = false;
  @HostBinding('class.is-on-focus') isOnFocus = false;

  onValueChange(input) {
    this.valueChange.emit(input.value);
  }
}
