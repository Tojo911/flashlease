import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-date-picker-input',
  templateUrl: './date-picker-input.component.html',
  styleUrls: ['./date-picker-input.component.scss']
})
export class DatePickerInputComponent  {

  @Input() label: string = null;
  @Input() placeholder: string = null;
}
