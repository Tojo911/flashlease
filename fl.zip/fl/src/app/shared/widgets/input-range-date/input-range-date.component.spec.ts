import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputRangeDateComponent } from './input-range-date.component';

describe('InputRangeDateComponent', () => {
  let component: InputRangeDateComponent;
  let fixture: ComponentFixture<InputRangeDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputRangeDateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputRangeDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
