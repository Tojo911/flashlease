import { Injectable } from '@angular/core';


@Injectable()
export class UtilsService {

  public static buildApi(method, apiUrl) {
    return {method : method, url : apiUrl };
  }

  constructor() {
  }

}
