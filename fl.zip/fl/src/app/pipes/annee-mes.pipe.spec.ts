import { AnneeMESPipe } from './annee-mes.pipe';

describe('AnneeMESPipe', () => {
  it('create an instance', () => {
    const pipe = new AnneeMESPipe();
    expect(pipe).toBeTruthy();
  });
});
