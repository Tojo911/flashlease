import { DureeProduitPipe } from './duree-produit.pipe';

describe('DureeProduitPipe', () => {
  it('create an instance', () => {
    const pipe = new DureeProduitPipe();
    expect(pipe).toBeTruthy();
  });
});
