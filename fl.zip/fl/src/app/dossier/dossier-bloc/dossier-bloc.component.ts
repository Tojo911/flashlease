import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { isDefined } from '@angular/compiler/src/util';
import { ExportService } from '../../services/export/export.service';
import { DdfService } from '../../services/ddf/ddf.service';
import { MontantInfo } from '../../models/ddf';
import Global from '../../models/global-functions';

export class Dossier {
  static service?: TranslateService;
  static amountFormatter = new AmountFormatter();
  static prefix = '';
  linkParam?: number;
  onclick?: (_: any) => {};
  title: string;
  list: Dossier[];
  custom?: boolean;
  model?: any;
  data?: any;
  value: string | number;
  isNumber?: boolean;
  isDate?: boolean;
  hide?: boolean;
  suffix?: string;
  constructor(title, list, value) {
    this.title = title;
    this.list = list;
    this.value = value;
  }
  static getEmptyDossier() {
    return {
      title: '####',
      value: null
    } as Dossier;
  }
  static set(title, value, custom?) {
    if (value && typeof value !== 'string') {
      value = value['libelle'] ? value['libelle'] : value;
      if ((<MontantInfo>value).montant) {
        value = (<MontantInfo>value).montant;
        if ((<MontantInfo>value).devise) {
          custom =
            custom && typeof custom !== 'string'
              ? () => (custom.suffix = (<MontantInfo>value).devise)
              : custom;
        }
      }
      value =
        value && custom && custom.isDate && typeof value !== 'number'
          ? (<Date>value).getTime()
          : value;
      value =
        value && typeof value === 'number' && (!custom || !custom.isDate)
          ? this.amountFormatter.transform(value)
          : value;
      // si aucun match trouvé on afiche une valeur vide
      value =
        value && typeof value !== 'string' && typeof value !== 'number'
          ? ''
          : value;
    }
    if (custom && typeof custom !== 'string') {
      const toReturn = { title: title, value: value };
      Object.keys(custom).map((field, index) => {
        toReturn[field] = custom[field];
      });
      return toReturn;
    } else if (custom) {
      return {
        title: title,
        value: value,
        suffix: this.service.instant(custom)
          ? this.service.instant(this.prefix + custom)
          : custom
      };
    } else {
      return {
        title: title,
        value: value
      };
    }
  }
  static build(title, list, multi?, custom?) {
    const toReturn = {
      value: null,
      title: title,
      list: multi
        ? multi
        : [
            {
              value: null,
              title: null,
              list: list
            }
          ]
    };
    if (custom) {
      Object.keys(custom).map((field, index) => {
        toReturn[field] = custom[field];
      });
    }
    return toReturn;
  }
}

@Component({
  selector: 'app-dossier-bloc',
  templateUrl: './dossier-bloc.component.html',
  styleUrls: ['./dossier-bloc.component.scss']
})
export class DossierBlocComponent implements OnInit, OnChanges {
  amountFormat = new AmountFormatter();
  @Input()
  disabled;
  @Input()
  translateSuffix: string;
  @Input()
  nbColumns: number;
  @Input()
  items: Dossier[];
  constructor(
    public transServ: TranslateService,
    public exportService: ExportService,
    private ddfService: DdfService
  ) {}
  ngOnChanges(changes: SimpleChanges) {
    if (changes['items'] && changes['items'].currentValue) {
      if (this.items) {
        this.transServ.get(this.translateSuffix + 'SIREN').subscribe(t => {
          this.items.forEach(it => {
            it = this.translator(it);
            if (this.nbColumns && this.nbColumns > 0 && it.list) {
              it.list = it.list.filter(entity => entity.hide !== true);

              while (it.list.length % this.nbColumns !== 0) {
                it.list.push(Dossier.getEmptyDossier() as Dossier);
              }
            }
            if (it.list) {
              it.list.forEach(item => (item = this.translator(item)));
            }
          });
        });
      }
    }
  }
  translator(it: Dossier) {
    if (
      it.title &&
      isDefined(this.getIntName(it.title)) &&
      this.translateSuffix &&
      this.transServ.instant(this.getIntName(it.title)) &&
      this.getIntName(it.title) !==
        this.transServ.instant(this.getIntName(it.title))
    ) {
      it.title = this.transServ.instant(this.getIntName(it.title));
    }
    return it;
  }
  mapTimestampToDate(date) {
    return Global.mapTimestampToDate(date);
  }
  ngOnInit() {}
  getIntName(str) {
    return (
      this.translateSuffix +
      str
        .split(' ')
        .filter(s => s.length > 2)
        .join()
    //    .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]+/g, '')
        .toUpperCase()
    );
  }
  onclick(item) {
    if (item.onclick) {
      item.onclick(item);
    }
  }
}
