import { Component, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { StatutCommercialAutoriseInfo } from '../../models/ddf';
import { TranslateService } from '@ngx-translate/core';
import { ModelOption } from '../../models/option-model';

@Component({
  selector: 'app-dossier-waitdialog',
  templateUrl: './dossier-waitdialog.component.html',
  styleUrls: ['./dossier-waitdialog.component.scss']
})
export class DossierWaitdialogComponent implements OnInit {
  stepChangementStatutCommercial = 0;
  destinataires: ModelOption[];
  constructor(
    public translate: TranslateService,
    public dialogRef: MatDialogRef<DossierWaitdialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}
  emailValidation(item: string) {
    // tslint:disable-next-line:max-line-length
    const reg = new RegExp('^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$');
    return reg.test(item);
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
