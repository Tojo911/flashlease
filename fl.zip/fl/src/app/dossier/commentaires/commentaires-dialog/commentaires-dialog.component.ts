
import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  AfterViewChecked,
  Inject
} from '@angular/core';
import { CommentaireDecisionCommerciale, User } from '../../../models/ddf';
import * as func from '../../../models/global-functions';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '../../../services/auth/auth.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-commentaires-dialog',
  templateUrl: './commentaires-dialog.component.html',
  styleUrls: ['./commentaires-dialog.component.scss']
})
export class CommentairesDialogComponent implements OnInit {

  private commentaire: string;
  public currentDate = new Date();

  constructor(
    public dialogRef: MatDialogRef<CommentairesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData)  {}

  ngOnInit() {
      this.currentDate = new Date();
    }
  onNoClick(): void {
    this.dialogRef.close();
  //  console.log(this.currentDate);
  }
}

export interface DialogData {
  selectedVisibilityComment: number;
  listVisibilityComment: any;
  commentaire: string;
}
