import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentairesDialogComponent } from './commentaires-dialog.component';

describe('CommentairesDialogComponent', () => {
  let component: CommentairesDialogComponent;
  let fixture: ComponentFixture<CommentairesDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommentairesDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommentairesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
