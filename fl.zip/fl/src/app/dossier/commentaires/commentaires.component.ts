import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  AfterViewChecked,
  Inject,
  SimpleChanges,
  OnChanges
} from '@angular/core';
import { CommentaireDecisionCommerciale, User } from '../../models/ddf';
import * as func from '../../models/global-functions';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '../../services/auth/auth.service';
import {MatDialog } from '@angular/material';
import { CommentairesDialogComponent } from './commentaires-dialog/commentaires-dialog.component';
@Component({
  selector: 'app-commentaires',
  templateUrl: './commentaires.component.html',
  styleUrls: ['./commentaires.component.scss']
})
export class CommentairesComponent implements OnInit, AfterViewChecked, OnChanges {
  @Input()
  commentaires: CommentaireDecisionCommerciale;
  commentaire: string;

  @Output()
  commentAdded = new EventEmitter();
  @Input()
  isOptDisable: boolean;
  @Input()
  user: User;
  placeholder: string;
  currentDate: Date;
  isUserToDisplay: boolean;
  func = func;
  @Input()
  disableCommentaire: boolean;
  @Input()
  isInterne: boolean;
  @Input()
  buttonCommentaire: boolean;
  initButtonCommentaire = false;

  constructor(public transServ: TranslateService, private authService: AuthService, public dialog: MatDialog) {
    this.isUserToDisplay = this.isUser();
    transServ.get('COMMENTAIRES.PLACEHOLDER').subscribe(val => {
      this.placeholder = val;
    });
  }
  ngAfterViewChecked() {
    this.currentDate = new Date();
  }
  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    if (this.initButtonCommentaire && changes.buttonCommentaire !== undefined) {
      this.openCommentaires();
    }
    if (!this.initButtonCommentaire) {
      this.initButtonCommentaire = true;
    }
    // console.log('etat bouton : ' + changes.buttonCommentaire);
  }

  send() {}

  isRemovable(commentaire) {
    if (
      this.isUser() &&
      this.user.identifiant === commentaire.user.identifiant
    ) {
      return false; // return true;
    }
    return false;
  }

  isSendable(commentaire) {
    if (
      this.isUser() &&
      this.user.identifiant === commentaire.user.identifiant
    ) {
      return false; // return true;
    }
    return false;
  }

  isEditable(commentaire: CommentaireDecisionCommerciale) {
    if (
      this.isUser() &&
      this.user.identifiant === commentaire.user.identifiant
    ) {
      return false; // return true;
    }
    return false;
  }
  isUser() {
    return this.user ? true : false;
  }
  isOptAvailable(comment: CommentaireDecisionCommerciale) {
    return !this.isOptDisable && this.isUser() && this.isCurrentUser(comment);
  }
  isCurrentUser(comment: CommentaireDecisionCommerciale) {
    return this.user.identifiant === comment.user.identifiant;
  }
  openCommentaires(): void {

    let selectedVisibilityComment = 0;
    const listVisibilityComment = [
      {value: 0, viewValue: 'COMMENTAIRES.FRANFINANCE', viewValueFull: 'COMMENTAIRES.VISIBLE_PAR_FRANFINANCE'},
      {value: 1, viewValue: 'COMMENTAIRES.TOUS_LES_UTILISATEURS', viewValueFull: 'COMMENTAIRES.VISIBLE_PAR_TOUS_LES_UTILISATEURS'},
    ];

    const dialogRef = this.dialog.open(CommentairesDialogComponent, {
      width: '700px',
      data: { selectedVisibilityComment : selectedVisibilityComment,
        listVisibilityComment : listVisibilityComment,
        commentaire : this.commentaire}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.buttonCommentaire = false;
      if (result) {
        // clean HTML Tag and Special Charater
        this.commentaire = result.commentaire;
        selectedVisibilityComment = result.selectedVisibilityComment;
      }
      if (this.commentaire) {
       // console.log('envoi du commentaire : ' + this.commentaire + 'selectedVisibilityComment : ' + selectedVisibilityComment);
        /*let externe: boolean;*/
        let interne: boolean;
        if (selectedVisibilityComment === 0) { /*externe = false; */ interne = true; /*console.log('Externe : ' + this.commentaire);*/ }
        if (selectedVisibilityComment === 1) { /*externe = true; */ interne = false; /*console.log('Interne : ' + this.commentaire);*/ }
        this.commentAdded.emit({comment: this.commentaire, /*ext: externe,*/ int: interne});
        this.commentaire = '';
      } else {
       // console.log('pas de message');
      }
    });
  }
}



