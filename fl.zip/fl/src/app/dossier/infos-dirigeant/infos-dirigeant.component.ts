import { Component, OnInit, Input, Inject, OnDestroy, EventEmitter, Output } from '@angular/core';
import { DirigeantInfoInput } from '../../models/ddf';
import { TranslateService } from '@ngx-translate/core';
import { DdfService } from '../../services/ddf/ddf.service';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-infos-dirigeant',
  templateUrl: './infos-dirigeant.component.html',
  styleUrls: ['./infos-dirigeant.component.scss']
})
export class InfosDirigeantComponent implements OnInit, OnDestroy {
  infos: DirigeantInfoInput = {
    nom: '',
    prenom: '',
    nomJF: '',
    dateDeNaissance: new Date(2999, 12, 12)
  };
  @Input()
  numDoss: string;
  infoDiriSent: boolean;
  infoDirResult: string;
  minDate = new Date(1900, 1, 1);
  maxDate = new Date();
  @Output()
  isDone = new EventEmitter();
  init: boolean;
  constructor(
    public translate: TranslateService,
    private ddfService: DdfService,
    @Inject(MAT_DIALOG_DATA) private data
  ) {}
  ngOnDestroy(): void {
  }
  ngOnInit() {
    if (!this.numDoss && this.data) {
      this.numDoss = this.data.id;
    }
  }
  isValid() {
    return (
      this.infos.nom &&
      this.infos.nom !== '' &&
      this.infos.prenom &&
      this.infos.prenom !== '' &&
      this.infos.dateDeNaissance &&
      this.isDateValid()
    );
  }
  isDateValid() {
    return this.infos.dateDeNaissance.getTime() < new Date().getTime();
  }
  setDateBirth(e) {
    this.infos.dateDeNaissance = e;
  }
  sendInfosDirigeant() {
    if (this.isValid()) {
      this.ddfService.sendInfosdirigeant(this.infos, this.numDoss).subscribe(
        res => {
          console.log(`info Dirigeant sent `);
          this.infoDiriSent = true;
          this.infoDirResult = 'SUCCESS_INFO_DIR';
          this.isDone.emit();
        },
        err => {
          console.log('error...infos dirigeant', err);
          this.infoDiriSent = true;
          this.infoDirResult = 'FAILED_INFO_DIR';
          this.isDone.emit();
        }
      );
    }
  }
}
