import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfosDirigeantComponent } from './infos-dirigeant.component';

describe('InfosDirigeantComponent', () => {
  let component: InfosDirigeantComponent;
  let fixture: ComponentFixture<InfosDirigeantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfosDirigeantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfosDirigeantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
