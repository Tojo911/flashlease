import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { Router } from '@angular/router';
import {
  AffaireInfo,
  BienInfo,
  ContratInfo,
  DossierInfo,
  DossierInfo2,
  DossierRatifieInfo,
  ElementInfo,
  MaterielFinancementInfo,
  PalierInfo,
  RatificationInfo,
  CommentaireDecisionCommerciale,
  HistoriqueStatutCommercialInfo,
  MontantInfo,
  ClientInfo,
  EtablissementClientInfo,
  AdresseCompleteInfo,
  PersonneInfo,
  RepresentantClientInfo,
  LivraisonInfo,
  FacturationInfo,
  BanqueInfo,
  RibInfo,
  PrestationInfo,
  MaterielContratInfo,
  HistoEditionContratInfo,
  RachatVo,
  StatutCommercialAutoriseInfo,
  PieceMontageEntity
} from '../../models/ddf';
import Global, * as func from '../../models/global-functions';
import { TableColumnDefinitionModel } from '../../models/table-column-definition-model';
import { AffaireService } from '../../services/affaires/affaire.service';
import { DdfService } from '../../services/ddf/ddf.service';
import { RatificationService } from '../../services/ddf/ratification.service';
import { MockService } from '../../services/mock/mock-service.service';
import { Dossier } from '../dossier-bloc/dossier-bloc.component';
import saveAs from 'file-saver';
import {
  DossierHeader,
  DossierHeaderBuilder
} from '../dossier-header/dossier-header.component';
import { TemporalFreezeItem } from './temporal-freeze/temporal-freeze.component';
import { AuthService } from '../../services/auth/auth.service';
// import { ContratInfoClass } from '../../models/modelClass';
import { MatDialog, MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { DdfDataSourceService } from '../../services/ddf/ddf-data-source.service';
import { DossierStepper } from '../dossier-stepper/dossier-stepper.component';

import { DossierWaitdialogComponent } from '../dossier-waitdialog/dossier-waitdialog.component';
import { InfosDirigeantComponent } from '../infos-dirigeant/infos-dirigeant.component';
import { UploadComponent } from '../../shared/widgets/upload/upload.component';
import { RachatService } from '../../services/rachat/rachat.service';
export enum Phase {
  DDF = 'ddf',
  MONTAGE = 'mont',
  PARC = 'parc'
}
@Component({
  selector: 'app-suivi-dossier',
  templateUrl: './suivi-dossier.component.html',
  styleUrls: ['./suivi-dossier.component.scss']
})
export class SuiviDossierComponent implements OnInit, OnDestroy {
  numDoss: any;
  pieces$;
  ddf$;
  nbColumns = 4;
  type: string;
  typesEnum = Phase;
  affaires: AffaireInfo;
  dossierLoading = false;
  route$;
  labelDossier = 'Informations générales';
  data: any = 26288;
  pjLoading = false;
  ddfData: DossierInfo;
  dossierHeader: DossierHeader;
  dossierDates: TemporalFreezeItem[] = [];
  montageFreezeDates: TemporalFreezeItem[] = [];
  parcFreezeDates: TemporalFreezeItem[] = [];
  ratifications: RatificationInfo[];
  ratificationsloaded = false;
  loaded = false;
  public dossierRatifie: DossierRatifieInfo = {};
  DossierRatifiable = false;
  ddfRetrived = false;
  paliers: PalierInfo[];
  historiqueStatutCommercial: HistoriqueStatutCommercialInfo[];
  historiqueStatutCommercialValid = false;
  paliersValid = false;
  materielFinancesValid = false;
  selectedRatification: RatificationInfo;
  selectedContrat: ContratInfo;
  affaireElements: Dossier[];
  commentairesDecisionCommerciale: any;
  rachats: RachatVo[];
  rachat: RachatVo;
  memory: {
    dossier: DossierRatifieInfo;
    contrat: ContratInfo;
    ratification: RatificationInfo;
  } = {
    dossier: null,
    contrat: null,
    ratification: null
  };
  steps: any[];
  pieces: any;
  PJadded = {};
  piecesJointe: any;
  dossierSelector: any;
  ratificationSelector: any;
  palierColumns: TableColumnDefinitionModel[];
  columns: TableColumnDefinitionModel[];
  elementColumns: TableColumnDefinitionModel[];
  dossierColumns: TableColumnDefinitionModel[];
  histoColumns: TableColumnDefinitionModel[];
  histoDossier: HistoEditionContratInfo[];
  private formatNumber = new AmountFormatter();
  contratContent: Dossier[];
  dossierContent: Dossier[];
  affairesContent: Dossier[];
  materielFinances: MaterielFinancementInfo[];
  materielColumns: TableColumnDefinitionModel[];
  historiqueStatutCommercialColumns: TableColumnDefinitionModel[];
  incorrectColumns: TableColumnDefinitionModel[];
  manquanteColumns: TableColumnDefinitionModel[];
  attenduColumns: TableColumnDefinitionModel[];
  columnsRachat: TableColumnDefinitionModel[];
  isPJUploadable: boolean;
  isInterne: boolean;
  errorMsgType: string;
  errorMsgSize: string;
  mock = require('../../classes/mock/suividossier.json');
  currentTabulation: number;
  ratificationsMontantRestant: number;
  suiviDeDossierMontant: number;
  buttonCommentaire = false;
  commentaireApporteurDossier: Dossier[];
  listContratContent: Dossier[][] = [null, null, null];
  listDossierStepper = [
    new DossierStepper(),
    new DossierStepper(),
    new DossierStepper()
  ];
  selectedIndexStepper: number;
  rachatId: string;
  commentaireApporteur: string;
  @ViewChild('uploader')
  uploader: UploadComponent;
  numEkip = '';
  browseFileLength = 0;
  isAuthconsultRachat = false;
  isAuthCreaRachat = false;

  isRachatSelected = (row: RachatVo) =>
    row.referenceRachat === this.rachat.referenceRachat;

  constructor(
    private ratifservice: RatificationService,
    private ddfDatasoucre: DdfDataSourceService,
    private route: ActivatedRoute,
    private ddfService: DdfService,
    public transServ: TranslateService,
    private mockService: MockService,
    private affaireService: AffaireService,
    private authService: AuthService,
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private router: Router,
    private rachatService: RachatService
  ) {
    this.mock[1] = require('../../classes/mock/EnsRatification.json');
    this.mock[2] = null; // Global.generateRandomValue(new ContratInfoClass());
    this.mock[3] = require('../../classes/mock/ratification.json');
    this.mock[4] = require('../../classes/mock/suiviParc.json');
    this.mock[5] = require('../../classes/mock/commentaires.json');

    this.dossierSelector = row =>
      !this.selectedRatification && !this.selectedContrat;
    this.ratificationSelector = row =>
      (this.selectedRatification &&
        !this.selectedContrat &&
        row.chrono === this.selectedRatification.chrono) ||
      (this.selectedContrat &&
        row.chrono === this.selectedContrat.ratification.chrono);
    this.transServ.get('DDF.FORM.ERROR.file_error_type').subscribe(it => {
      this.columnsRachat = this.buildColumnsRachat();
      this.errorMsgType = it;
      this.errorMsgSize = this.transServ.instant(
        'DDF.FORM.ERROR.file_error_size'
      );
    });
    this.isInterne = this.authService.isInterne();
    // this.isInterne = false;
    console.log('isInterne : ' + this.isInterne);
    Dossier.service = this.transServ;
    Dossier.prefix = '';
    this.route.params.subscribe(params => {
      if (params.did.indexOf('_') === -1) {
        throw new Error('Id Incorrect');
      }
      this.numDoss = params.did.split('_')[1];
      this.type = params.did.split('_')[0];
      this.getDossierInfo();
    });
    this.isAuthconsultRachat = this.authService.isAuthRachatConsultation();
    this.isAuthCreaRachat = this.authService.isAuthRachatCreation();
  }
  buildColumnsRachat() {
    return [
      {
        header: '',
        type: true,
        columnDef: 'onclick',
        onclick: (row: RachatVo) => (this.rachat = row),
        cell: (row: RachatVo) => 'visibility'
      },
      {
        columnDef: 'Nb demande rachat',
        header: this.transServ.instant(
          'RACHAT.TABLE.COLUMNS.NB_DEMANDE_RACHAT'
        ),
        cell: (row: RachatVo) => row.referenceRachat
      },
      {
        columnDef: 'date de rachat',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.DATE_RACHAT'),
        date: true,
        cell: (row: RachatVo) => row.dateRachat
      },
      {
        columnDef: 'statut',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.STATUT'),
        cell: (row: RachatVo) => Global.gets(row.statut).libelle
      },
      {
        columnDef: 'recu le',
        header: this.transServ.instant('RACHAT.TABLE.COLUMNS.RECU_LE'),
        date: true,
        cell: (row: RachatVo) => row.dateReception
      }
    ] as TableColumnDefinitionModel[];
  }
  getDdfsColumnsDef() {
    return [
      /*
      {
        columnDef: 'indent',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.INDENT'),
        cell: (row: RatificationInfo) => `attach_file`,
        type: 'icon'
      },
      */
      {
        columnDef: 'Fl',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NBFL'),
        cell: (row: RatificationInfo) =>
          `${this.dossierRatifie.numeroFL}/${row.chrono}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        forbiddenScreens: ['xs', 'sm'],
        cell: (row: RatificationInfo) =>
          this.formatNumber.transform(
            row.planFinancement
              ? row.planFinancement.montantFinancement
              : row.montant
          )
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DUREE'),
        cell: (row: RatificationInfo) =>
          `${row.planFinancement ? row.planFinancement.duree : row.duree}`
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs'],
        tooltip: 'hasTooltip',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUT'),
        cell: (row: RatificationInfo) => row.statutRatification.libelle
      }
    ] as TableColumnDefinitionModel[];
  }

  getDossierColumnsDef() {
    return [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.CHRONO'),
        cell: (row: DossierRatifieInfo) =>
          Number(this.ratificationsMontantRestant) +
          ' / ' +
          Number(this.suiviDeDossierMontant) +
          ' €'
      }
    ] as TableColumnDefinitionModel[];

    /*
    return [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.CHRONO'),
        cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: DossierRatifieInfo) =>
          `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DUREE'),
        cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUT_COMMERCIAL'),
        date: true,
        cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUS'),
        cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];
*/
  }
  setMontageColumnsDef() {
    this.incorrectColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NON_CONFORME')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status5',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.manquanteColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.FORM.PCS_MANQUANTES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.incorrectColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.PCS_INCORRECTES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.attenduColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.PCS_ATTENDUES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status5',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];
  }
  replaceStatut(it) {
    if (!it) {
      return it;
    }
    return this.transServ.instant(it);
  }
  ngOnDestroy() {
    Global.unsubscriber(this.pieces$);
    Global.unsubscriber(this.ddf$);
    Global.unsubscriber(this.route$);
  }
  initDossier(res) {
    this.ddfData = res as DossierInfo2;
    if (this.ddfData.statut) {
      this.ddfData.statut.libelle = this.replaceStatut(
        this.ddfData.statut.libelle
      );
    }
    this.dossierHeader = DossierHeaderBuilder.setDossier(this.ddfData);
    this.DossierRatifiable = false;
    this.ddfRetrived = true;
    this.setView();

    this.selectedRatification = null;
    this.selectedContrat = null;
    this.currentTabulation = 0;
  }
  initDossierRatifie(res) {
    this.dossierRatifie = res as DossierRatifieInfo;
    this.dossierRatifie.statut.libelle = this.replaceStatut(
      this.dossierRatifie.statut.libelle
    );
    this.dossierRatifie.ratifications.map(it => {
      if (it.statut) {
        it.statut.libelle = this.replaceStatut(it.statut.libelle);
      }
      if (it.statutRatification) {
        it.statutRatification.libelle = this.replaceStatut(
          it.statutRatification.libelle
        );
      }
    });
    this.dossierRatifie.ratifications = this.dossierRatifie.ratifications.sort(
      (a, b) => {
        if (a.chrono < b.chrono) {
          return -1;
        } else if (a.chrono > b.chrono) {
          return 1;
        }
      }
    );

    this.memory.dossier = this.dossierRatifie;
    console.log(
      'Nombre de Ratifications : ' + this.dossierRatifie.ratifications.length
    );
    if (this.dossierRatifie.ratifications.length > 0) {
      this.DossierRatifiable = true;
    }

    this.loaded = true;
    this.getSumRatifications();
  }

  getSumRatifications() {
    this.ratificationsMontantRestant = 0;
    this.suiviDeDossierMontant = this.dossierRatifie.montant;
    // console.log('montant : ' + this.dossierRatifie.montant);

    let sum = 0;
    this.dossierRatifie.ratifications.forEach(ratif => {
      if (
        !(
          ratif.statutRatification.libelle === 'Annulé' ||
          ratif.statutRatification.libelle === 'Brouillon'
        )
      ) {
        sum += ratif.planFinancement.montantFinancement;
      }
    });
    // console.log('suiviDeDossierMontant : ' + this.suiviDeDossierMontant + 'sum : ' + sum);
    this.ratificationsMontantRestant = this.suiviDeDossierMontant - sum;
  }

  ngOnInit() {}

  getDossierInfo() {
    console.log('numeroFlashlease........ ', this.numDoss);
    console.log('this.type...... ', this.type);
    if (this.type === Phase.MONTAGE) {
      this.ddf$ = this.ddfService.getDdf(this.numDoss).subscribe(
        res => {
          const dossier = res.content as DossierInfo;
          // this.initDossier(res.content);
          this.initMontage(res.content);
        },
        err => {
          if (this.mockService.isDev()) {
            this.initDossier(this.mock[0]);
            setTimeout(this.initDossierRatifie(this.mock[1]), 800);
          }
          this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
          console.log('erreur de récupération des infos', err);
        }
      );
    }
    if (this.type === Phase.PARC) {
      this.initParc();
    }
    if (this.type === Phase.DDF) {
      this.ddfService.getCommentaire(this.numDoss).subscribe(res => {
        const result = res.content as any;
        this.commentaireApporteur =
          result && result.commentaires && result.commentaires.length > 0
            ? result.commentaires[0].commentaire
            : (null as string);
        this.commentaireApporteurDossier = [this.buildCommentairePartenaire()];
      });
      this.ddf$ = this.ddfService.getDdf(this.numDoss).subscribe(
        res => {
          const dossier = res.content as DossierInfo;
          if (!dossier) {
            this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
            this.loaded = true;
            return;
          }
          this.initDossier(res.content);
          this.isPJUploadable =
            this.ddfData.statut.code === 'ETU' ||
            this.ddfData.statut.code === 'ANO';
          // this.authService.isPJDDFUploadable(this.get(this.get(this.ddfData.statut).sousStatutInfo).code);
          this.initCommentairesParSuiviDeDossier();
          /* if (
            this.ddfData.statut.libelle === this.replaceStatut('Ratification') ||
            this.ddfData.statut.libelle === this.replaceStatut('Brouillon')
          ) {
            // this.labelDossier = 'Informations générales';
            /* this.ratifservice.getRatificationList(this.numDoss).subscribe(
            result => {
              this.ratifications = result.content as RatificationInfo[];
              console.log('Ratification', res.content);
              this.ratificationsloaded = true;
            },
            err => {
              this.ratifications = null;
              console.log('Ratifications non remonté introuvable');
            }
          );*/
          this.ratifservice.getRatifications(this.numDoss).subscribe(
            result => {
              if (result.content) {
                this.initDossierRatifie(result.content);
              }
            },
            err => {
              this.dossierRatifie = null;
              console.log('Ratification introuvable');
            }
          );
          // }
        },
        err => {
          if (this.mockService.isDev()) {
            this.initDossier(this.mock[0]);
            setTimeout(this.initDossierRatifie(this.mock[1]), 800);
          }
          this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
          console.log('erreur de récupération des infos', err);
        }
      );
      this.pieces$ = this.ddfService.getPiecesDdf(this.numDoss).subscribe(
        res => {
          this.pieces = res.content;
          this.piecesJointe = this.buildPieces();
        },
        err => {
          if (this.mockService.isDev()) {
            /* this.dossierRatifie = this.mock[0];
             this.ddfData = this.mock[1];
             this.DossierRatifiable = false;
             this.ddfRetrived = true;*/
          }
          console.log('erreur de récupération des infos', err);
        }
      );
    }
  }

  initParcObs(res) {
    this.affaires = res as AffaireInfo;
    this.route.params.subscribe(params => {
      this.rachatId = params.rachatId;
      if (this.rachatId) {
        setTimeout(() => {
          this.currentTabulation = 1;
        }, 800);
      }
    });
    if (!this.affaires) {
      this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
      this.loaded = true;
      return;
    }
    const aff = this.affaires;
    this.dossierHeader = {
      dossierId: this.numDoss,
      raisonSocial: aff.client.raisonSociale,
      siren: aff.client.siren,
      //  produitFinancier: '??',
      duree: aff.duree,
      periodicite:
        aff.elements && aff.elements.length > 0
          ? aff.elements[0].periodicite.libelle
          : '',
      montant: aff.montantRachat,
      baseLocInit: aff.firstElement.baseLocInit,
      categorieAffaire: aff.categorieAffaire
      // loyer: '??',
    } as DossierHeader;
    this.setAffaireView();
    this.loaded = true;
  }
  initParc() {
    this.currentTabulation = 0;
    this.affaireService.getDossierById(this.numDoss).subscribe(
      result => {
        this.initParcObs(result.content);
      },
      err => {
        if (this.mockService.isDev()) {
          console.log('mockService etat de parc');
          this.initParcObs(this.mock[4]);
          this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
          /* this.dossierRatifie = this.mock[0];
       this.ddfData = this.mock[1];
       this.DossierRatifiable = false;
       this.ddfRetrived = true;*/
        }
      }
    );
    this.rachatService.getRachats(this.numDoss).subscribe(it => {
      if (it.content.rachats && it.content.rachats.length > 0) {
        this.rachats = it.content.rachats;
        this.route.params.subscribe(params => {
          this.rachatId = params.rachatId;
          if (this.rachatId) {
            setTimeout(() => {
              this.currentTabulation = 1;
            }, 800);
          }
        });
        if (!this.rachatId) {
          this.rachat = this.rachats[0];
        } else {
          this.rachat = this.rachats.find(
            rach => rach.referenceRachat === Number(this.rachatId)
          );
        }
      }
    });
    // this.setParcDates();
  }
  initMontage(res) {
    this.setMontageDates();
    this.transServ.get('SUIVI.FORM.PCS_MANQUANTES').subscribe(it => {
      this.setMontageColumnsDef();
    });
    this.loaded = true;

    this.ddfData = res as DossierInfo2;
    if (!this.ddfData) {
      this.open(this.transServ.instant('SUIVI.FORM.DOSSIER_ERROR'));
      this.loaded = true;
      return;
    }
    if (this.ddfData.statut) {
      this.ddfData.statut.libelle = this.replaceStatut(
        this.ddfData.statut.libelle
      );
    }
    this.dossierHeader = DossierHeaderBuilder.setDossier(this.ddfData);
    this.DossierRatifiable = false;
    this.ddfRetrived = true;
    // this.setView();

    this.selectedRatification = null;
    this.selectedContrat = null;
    this.currentTabulation = 0;
    /*
    this.setMontageColumnsDef();
    this.ddfService.getPiecesMontage(this.numDoss)
    .subscribe(
      results => {
        if (results.content) {
          if (results.content.manquantes) {
            this.listPiecesManquantes = results.content.manquantes as PieceMontageEntity[];
            console.log('piecesManquantes : ' + JSON.stringify(this.listePiecesManquantes));
          }
          if (results.content.enAttente) {
            this.listPiecesEnAttente = results.content.enAttente as PieceMontageEntity[];
            console.log('piecesenAttente : ' + JSON.stringify(this.listePiecesEnAttente));
          }
          if (results.content.incorrectes) {
            this.listPiecesIncorrectes = results.content.incorrectes as PieceMontageEntity[];
            console.log('piecesIncorrectes : ' + JSON.stringify(this.listPiecesIncorrectes));
          }




        }
      },
      err => {}
    );
    */
  }

  initCommentairesParSuiviDeDossier() {
    this.ddfService.getCommentairesParSuiviDeDossier(this.numDoss).subscribe(
      res => {
        let list;
        if (!this.isInterne) {
          list = res.content.commentaires.filter(
            p => p.messageExterne !== null
          );
        } else {
          list = res.content.commentaires;
        }
        this.commentairesDecisionCommerciale = list.sort((a, b) => {
          if (a.dateCreation < b.dateCreation) {
            return -1;
          } else {
            return 1;
          }
        });

        // console.log('liste des commentaire :' + this.commentairesDecisionCommerciale);
      },
      err => {
        if (this.mockService.isDev()) {
          this.commentairesDecisionCommerciale = this.mock[5];
        }
        console.log('erreur de récupération des infos', err);
      }
    );
  }

  clickButtonCommentaire() {
    if (this.buttonCommentaire) {
      this.buttonCommentaire = false;
    } else {
      this.buttonCommentaire = true;
    }
  }

  commentAdded(event) {
    // console.log('comment add : ' + this.buttonCommentaire);
    const myComment: string = event.comment;
    /*const externe: boolean = event.ext;*/
    const interne: boolean = event.int;
    const commentObjet = {
      message: myComment,
      interne: interne
      /*'externe': externe*/
    };
    // console.log('Send commentaire : ' +  commentObjet + ' ' + this.numDoss);
    this.ddfService
      .postCommentairesParSuiviDeDossier(commentObjet, this.numDoss)
      .subscribe(
        res => {
          this.initCommentairesParSuiviDeDossier();
        },
        err => {
          console.log('erreur envoi du commentaire', err);
        }
      );
  }

  setHistoriqueStatutCommercial() {
    const { historiqueStatutCommercial } = this.ddfData;
    this.historiqueStatutCommercial = historiqueStatutCommercial
      ? historiqueStatutCommercial
      : [];
    /* console.log('length statutCo : ' + this.historiqueStatutCommercial.length); */
    if (this.historiqueStatutCommercial.length > 0) {
      this.historiqueStatutCommercialValid = true;
    }
    this.historiqueStatutCommercialColumns = this.setHistoriqueStatutCommercialColumnsColumns();
  }

  setView() {
    if (this.ddfRetrived) {
      this.dossierContent = [
        this.buildInfosVendeur(),
        this.buildInformationsGenerale(),
        this.buildComplementFinancementAccord(),
        this.buildStatut(),
        this.buildDecisions(),
        this.buildCommentaire(),
        this.buildContrePartie()
      ];

      this.setHistoriqueStatutCommercial();

      this.transServ.get(' ').subscribe(it => {
        this.steps = [
          { name: this.transServ.instant('HOME.TABS.DDFS') },
          { name: this.transServ.instant('HOME.TABS.MONTAGE') },
          { name: this.transServ.instant('HOME.TABS.SUIVI') }
        ];
        this.columns = this.getDdfsColumnsDef();
        this.dossierColumns = this.getDossierColumnsDef();
      });
      this.loaded = true;
      this.currentTabulation = 0;
    }
  }
  setContratView() {
    if (this.ddfRetrived) {
      this.contratContent = this.getContratEditeContent();
      /*this.buildComplementFinancement(true) [
        this.buildInfosVendeur(true),
        this.buildSimulation(true),
        this.buildComplementFinancement(true),
        this.buildCalage(true),
        this.buildAutreMajoration(true),
        this.buildModeReglement(true),
        this.buildIdentificationVendeur(true),
        this.buildIdentificationClient(true),
        this.buildStatutRachat(true),
        this.buildPrestationAnnexe(true),
        this.buildMaterielPrincipal(true),
        this.buildGaranties(true)
      ];*/
      this.loaded = true;
    }
    this.setMaterielFinances();
    this.setHistoriqueDossier();
  }

  setMaterielFinances() {
    this.materielFinances = this.get(this.selectedContrat.materiels, true);
    this.materielColumns = this.setMaterielColumns();
    this.materielColumns.push({
      columnDef: 'Fournisseur',
      header: this.transServ.instant('SUIVI.TABLE.COLUMNS.FOURNISSEUR'),
      cell: (row: MaterielFinancementInfo) => this.get(row.fournisseur).nom
    } as TableColumnDefinitionModel);
  }

  setHistoriqueDossier() {
    this.histoDossier = this.selectedContrat.historiquesDossiers
      ? this.selectedContrat.historiquesDossiers
      : [];
    this.histoColumns = this.setHistoriqueDossierColumns();
  }

  setAffaireView() {
    this.transServ.get('  ').subscribe(it => {
      if (this.isInterne) {
        this.elementColumns = this.setElementColumns();
      } else {
        this.elementColumns = this.setElementExterneColumns();
      }
    });
    this.affairesContent = [
      this.buildInfoGeneraleAffaires(),
      this.buildClientAffaires(),
      this.buildInfosVendeurAffaires(),
      this.buildInfosApporteurAffaires()
      // this.buildElementAffaires()
    ];
    let i = 0;
    this.affaireElements = this.affaires.elements.map(el =>
      this.buildElementAffaire(el, ++i)
    );
    this.setParcDates(this.affaires.firstElement);
    this.loaded = true;
  }
  buildInfoGeneraleAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build('Informations générales', [
      this.set('Société de gestion', affaires.societeGestion),
      this.set('Mode de règlement', affaires.modeReglement.libelle),
      this.set("Catégorie d'affaires", affaires.categorieAffaire),
      this.set('Nom du vendeur', affaires.nomVendeur),
      this.set('Statut EKIP', affaires.statut.libelle),
      this.set(
        'Code offre',
        affaires.codeOffre
          ? affaires.codeOffre + ' - ' + affaires.libelleCodeOffre
          : ''
      ),
      this.set('Durée', affaires.duree, 'mois')
    ]);
  }
  buildClientAffaires(isContrat?): Dossier {
    const affaires = this.affaires.client;
    return this.build('Client', [
      this.set('Référence EKIP', affaires.referenceTiers),
      this.set('SIREN', affaires.siren),
      this.set('Raison sociale', affaires.raisonSociale)
    ]);
  }
  buildInfosApporteurAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build(
      'Partenaire',
      [
        this.set('Numéro du partenaire', affaires.numApporteur),
        this.set('Nom du partenaire', affaires.nomApporteur),
        this.set('Tiers racheteur', affaires.tiersRacheteur),
        this.set(
          "Date d'arrêt de la facturation",
          affaires.dateArretFacturation,
          { isDate: true }
        ),
        this.set(
          'Mode de règlement 1er loyer',
          affaires.modeReglementPremierLoyer
        )
      ],
      false,
      { hide: !this.isInterne }
    );
  }
  buildInfosVendeurAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build(
      'Vendeur',
      [
        this.set('Réseau du vendeur', affaires.codeReseau),
        this.set('Région interne Franfinance', affaires.codeRegionInt),
        this.set('Code district vendeur', affaires.codeDistrict),
        this.set('Secteur Franfinance', affaires.codeSecteur),
        this.set('Région externe Franfinance', affaires.codeRegionExt)
      ],
      false,
      { hide: !this.isInterne }
    );
  }
  buildElementAffaire(element: ElementInfo, index): Dossier {
    let datePublication: Dossier,
      dateLocation: Dossier,
      dateLocationFin: Dossier,
      dateLocationNext: Dossier,
      dateLocationFirst: Dossier;
    dateLocation = this.set(
      'Date de début de location',
      element.dateDebutLocation,
      { isDate: true }
    );
    dateLocationFin = this.set(
      'Date de fin de location',
      element.dateFinLocation,
      { isDate: true }
    );
    dateLocationNext = this.set(
      'Date de la prochaine échéance',
      element.dateProchaineEcheance,
      { isDate: true }
    );
    dateLocationFirst = this.set(
      'Date première échéance',
      element.datePremiereEcheance,
      { isDate: true, hide: !this.isInterne }
    );
    datePublication = this.set(
      'Date publication greffe',
      element.datePublicationGreffe,
      { isDate: true, hide: !this.isInterne }
    );
    const custom = Dossier.getEmptyDossier();
    custom.title = 'Biens';
    custom.custom = true;

    const dossier = this.build('Element n°' + index, [
      this.set(
        this.isInterne ? 'Référence externe' : 'Vos références',
        element.referenceApporteur
      ),
      this.set('Prestation LMAI', element.prestationLMAI),
      this.set("Période de l'affaire", element.periodicite.code),
      dateLocation,
      dateLocationFin,
      this.set('Nombre de loyers restants', element.nombreLoyersRestants),
      dateLocationNext,

      this.set('Loyer financier HT', element.loyerFinHT, '€ HT'),
      this.set(
        'Loyer prestation services',
        element.loyerPrestationServiceHT,
        '€ HT'
      ),
      this.set('Primes assurances', element.primeAssurances),
      this.set('Loyer global HT', element.loyerGlobal, '€ HT'),

      this.set('Montant de la base locative', element.baseLocInit, {
        suffix: '€ HT',
        hide: !this.isInterne
      }),
      this.set(
        "Taux de rendement interne de l'opération",
        element.tauxRendementInterne,
        { suffix: '%', hide: !this.isInterne }
      ),
      this.set("Taux nominal de l'opération", element.tauxNominal, {
        suffix: '%',
        hide: !this.isInterne
      }),
      this.set("TEG actuariel de l'opération", element.tegActuariel, {
        suffix: '%',
        hide: !this.isInterne
      }),
      this.set(
        'Taux de rendement interne actuariel',
        element.tauxRendementInterneActuariel,
        { suffix: '%', hide: !this.isInterne }
      ),
      this.set(
        "Taux de rendement interne de l'opération",
        element.tauxRendementInterne,
        { suffix: '%', hide: !this.isInterne }
      ),
      this.set('Montant VR', element.montantVR, {
        suffix: '€ HT',
        hide: !this.isInterne
      }),
      this.set('Montant VR client repreneur ', element.montantVRRepreneur, {
        suffix: '€ HT',
        hide: !this.isInterne
      }),
      this.set('VR client repreneur', element.pourcentVRClient, {
        hide: !this.isInterne
      }),
      this.set('VR client fournisseur', element.pourcentVRFournisseur, {
        hide: !this.isInterne
      }),
      this.set(
        'VR repreneur non fournisseur / non client',
        element.loyerFinHT,
        { hide: !this.isInterne }
      ),
      dateLocationFirst,
      datePublication,
      this.set(
        'Numéro fournisseur entretien',
        element.numeroFournisseurEntretien,
        { hide: !this.isInterne }
      ),
      this.set('Nom fournisseur entretien', element.nomFournisseurEntretien, {
        hide: !this.isInterne
      }),
      this.set('Code contrat prestation', element.codeContratPrestation, {
        hide: !this.isInterne
      }),
      this.set('Code contrat assurance', element.codeContratAssurance, {
        hide: !this.isInterne
      })
    ]);
    dossier.data = element.biens;
    dossier.list.push(custom);
    return dossier;
  }
  buildCalage(isContrat?) {
    let calage = this.selectedContrat.ratification.calage;
    calage = calage ? calage : {};
    return this.build('Autres majorations', [
      this.set('Calage', calage.dateFinancement),
      this.set('Nombre de jours', calage.nbJoursCalage)
    ]);
  }
  buildAutreMajoration(isContrat?) {
    const autreMajorations = isContrat
      ? this.selectedContrat.ratification.autreMajorations
      : this.selectedRatification.autreMajorations;
    const calage = isContrat ? this.selectedContrat.ratification.calage : null;
    const { topCalage, nbJoursCalage } = isContrat
      ? calage
        ? calage
        : { topCalage: '', nbJoursCalage: '' }
      : this.selectedRatification.calage
      ? this.selectedRatification.calage
      : { topCalage: '', nbJoursCalage: '' };

    return {
      value: null,
      title: 'Majorations',
      list: [
        {
          value: null,
          title: null,
          list: [
            this.set('Calage', true === topCalage ? 'Oui' : 'Non'),
            this.set('Nombre de jours', nbJoursCalage)
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          list: autreMajorations
            ? autreMajorations.map(it =>
                this.set(it.libelle, it.pourcentMajoration, '%')
              )
            : []

          // it.montantMajoration it.pourcentMontantMajoration
        } as Dossier
      ]
    } as Dossier;
  }
  buildStatutRachat(isContrat?) {
    let rachat = this.selectedContrat.ratification.rachat;
    rachat = rachat ? rachat : {};
    return this.build('Rachat', [
      this.set('Le montant global intègre', rachat.montantGlobal),
      this.set(
        'Avant échéance de',
        Global.mapTimestampToDate(Number(rachat.dateRachat))
      )
    ]);
  }
  buildGaranties(isContrat?): Dossier {
    const garanties = isContrat
      ? this.selectedContrat.ratification.garanties
      : this.selectedRatification.garanties;

    return {
      value: null,
      title: 'Garanties et conditions',
      list: [
        {
          value: null,
          title: null,
          list: garanties ? garanties.map(it => this.set('', it.libelle)) : []
        }
      ]
    } as Dossier;
  }
  buildInformationsGenerale(): Dossier {
    const dossierRatifie = this.ddfData;
    const { nom, prenom } = dossierRatifie.vendeur
      ? dossierRatifie.vendeur
      : { nom: '', prenom: '' };
    return {
      value: null,
      title: 'Demande de financement',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'SIREN',
              value: dossierRatifie.numeroSIREN,
              isNumber: true
            },
            {
              title: 'Montant',
              value: dossierRatifie.montant,
              isNumber: true,
              suffix: '€'
            },
            {
              title: 'Durée',
              value: dossierRatifie.duree,
              suffix: 'mois'
            },
            {
              title: 'Produit financier',
              value: dossierRatifie.produitFinancier
                ? dossierRatifie.produitFinancier.libelle
                : ''
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Date de saisie',
              value: dossierRatifie.dateSaisie,
              isDate: true
            },
            {
              title: 'Raison sociale',
              value: dossierRatifie.raisonSociale
            },
            /*
            {
              title: 'Média  de création du dossier',
              value: dossierRatifie.media
            },*/
            {
              title: 'Gestionnaire de saisie',
              value: dossierRatifie.donneesInternes
                ? dossierRatifie.donneesInternes.gestionnaireSaisie
                : '',
              hide: !this.isInterne
              // value: `${nom} ${prenom}`
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier,
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Matériel(s)',
              value: dossierRatifie.materiel
                ? dossierRatifie.materiel.libelle
                : ''
            },

            {
              title: 'Neuf',
              value:
                dossierRatifie.blocMateriel &&
                true === <boolean>(<any>dossierRatifie.blocMateriel.neuf)
                  ? 'Oui'
                  : dossierRatifie.blocMateriel &&
                    false === <boolean>(<any>dossierRatifie.blocMateriel.neuf)
                  ? 'Non'
                  : ''
            },
            {
              title: 'Annee de mise en service',
              value: dossierRatifie.blocMateriel
                ? dossierRatifie.blocMateriel.anneeMiseEnService
                : ''
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }
  buildBlocDDF(): Dossier {
    const dossierRatifie = this.ddfData;
    return {
      value: null,
      title: 'Informations sur la demande',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'N°dossier',
              value: dossierRatifie.id
            },
            {
              title: 'Produits financiers',
              value: dossierRatifie.produitFinancier
                ? dossierRatifie.produitFinancier.libelle
                : ''
            },
            {
              title: 'Montant',
              value: dossierRatifie.montant,
              isNumber: true
            },
            {
              title: 'Durée',
              value: dossierRatifie.duree
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Informations matériels',
          list: [
            {
              title: 'Matériel(s)',
              value: dossierRatifie.materiel
                ? dossierRatifie.materiel.libelle
                : ''
            },
            {
              title: 'Fournisseur(s)',
              value: null // dossierRatifie.fournisseurs
            },
            {
              title: 'Commentaire interne(s)',
              value: null, // dossierRatifie.fournisseurs
              hide: !this.isInterne
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }

  buildPlanFinancement(): Dossier {
    const ratifs = this.dossierRatifie;
    return {
      value: null,
      title: 'Plan de financement',
      list: [
        {
          value: null,
          title: 'Informations sur la demande',
          list: [
            {
              title: 'Montant',
              value: ratifs.id,
              isNumber: true
            },
            {
              title: 'Périodicité',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.periodicite.libelle
                  : ''
            },
            {
              title: 'Loyer Financier',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.loyerFinancierMajore
                  : ''
            },
            {
              title: 'Coefficient',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.loyerFinancierBareme
                  : ''
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Options de financement',
          list: [
            {
              title: 'Calage',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].calage
                  : ''
            },
            {
              title: 'Règlement',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.modeReglement
                      .libelle
                  : ''
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }

  buildInfosVendeur(isContrat?): Dossier {
    const ratifs = isContrat
      ? this.selectedContrat.vendeur
      : this.ddfData.vendeur;
    return {
      value: null,
      title: 'Identification du vendeur',
      list: [
        {
          value: null,
          list: [
            {
              title: 'Marché',
              value: ratifs.agence.apporteur.marche.libelle,
              hide: !this.isInterne
            },
            {
              title: 'Partenaire',
              value: ratifs.agence.apporteur.libelle,
              hide: !this.isInterne
            },
            {
              title: 'Agence',
              value: ratifs.agence.libelle
            },
            {
              title: 'Vendeur',
              value: ratifs.nom + ' ' + ratifs.prenom
            }
          ]
        } as Dossier
      ]
    };
  }

  buildStatut(): Dossier {
    const ratifs = this.ddfData;

    // console.log(JSON.stringify(this.ddfData));
    return {
      value: null,
      title: 'Statut',
      list: [
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Statut courant',
              value: ratifs.statut.libelle
            },
            {
              title: 'Date de statut',
              value: ratifs.statut.date,
              isDate: true
            },
            {
              title: 'Commentaire du statut',
              value: ratifs.statut.commentaire,
              hide: !this.isInterne
            },
            {
              title: 'Gestionnaire de statut',
              value: ratifs.donneesInternes.gestionnaireStatut,
              hide: !this.isInterne
            },
            {
              title: 'Commentaire interne',
              value: ratifs.donneesInternes.commentaireInterne,
              hide: !this.isInterne
            },
            {
              title: 'Statut commercial',
              value: ratifs.statutCommercial,
              hide: !this.isInterne
            },
            this.set('Fiche risque du client', 'cliquer ici', {
              hide: !this.isInterne,
              onclick: () => this.openFicheRisqueDuClient(this.ddfData.id)
            }),
            // tslint:disable-next-line:max-line-length
            this.set('Informations dirigeant', 'renseigner', {
              hide: !this.ddfData.topDirigeant,
              onclick: () => this.openTopDirigeant(this.ddfData.id)
            })
          ]
        } as Dossier,
        {
          title: 'Historique du statut commercial',
          value: null,
          custom: true,
          hide: !this.isInterne,
          list: []
        }
      ]
    };
  }

  openFicheRisqueDuClient(numDossier) {
    this.ddfService.getFicheRisqueDuClient(numDossier).subscribe(res => {
      const blob = new Blob([res.content], { type: 'application/pdf' });
      const filename = 'synthesePdf.pdf';
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, filename);
      } else {
        const objectUrl = URL.createObjectURL(blob);
        window.open(objectUrl);
      }
    });
    console.log('openFicheRisqueDuClient ' + numDossier);
  }

  openTopDirigeant(numDossier) {
    this.dialog.open(InfosDirigeantComponent, {
      data: { id: numDossier }
    });
  }

  openLinkParc(numEkip) {
    if (numEkip) {
      this.router.navigate(['dossier/parc_' + numEkip + '/suivi']);
    }
  }

  buildStatutRatification(isContrat?): Dossier {
    const ratifs = isContrat
      ? this.selectedContrat.ratification
      : this.selectedRatification;
    return {
      value: null,
      title: 'Statut',
      list: [
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Statut courant',
              value: this.transServ.instant(ratifs.statutRatification.libelle)
            },
            {
              title: 'Numéro dossier Franfinance',
              value: this.numEkip,
              hide: !(
                this.isInterne &&
                !this.authService.isDashParc() &&
                this.numEkip !== ''
              )
            },
            {
              title: 'Numéro dossier Franfinance',
              value: this.numEkip,
              hide: !(
                this.isInterne &&
                this.authService.isDashParc() &&
                this.numEkip !== ''
              ),
              onclick: () => this.openLinkParc(this.numEkip)
            },
            {
              title: 'Date du changement de statut',
              // value: Global.mapTimestampToDate(<number><any>ratifs.statut.date),
              value: ratifs.statutRatification.date,
              isDate: true
            },
            {
              title: 'Date du statut',
              value: ratifs.statut.date,
              isDate: true
            },
            {
              title: 'Commentaire du statut',
              value: ratifs.statutRatification.commentaire,
              hide: !this.isInterne
            },
            {
              title: 'Gestionnaire de statut',
              value: ratifs.statutRatification.gestionnaire
                ? ratifs.statutRatification.gestionnaire.prenomNom
                : '',
              hide: !this.isInterne
            },
            {
              title: 'Commentaire interne',
              value: ratifs.donneesInternes.commentaireInterne,
              hide: !this.isInterne
            }
          ]
        } as Dossier
      ]
    };
  }

  buildCommentaire(): Dossier {
    return {
      value: null,
      title: 'Décisions commerciales',
      list: [
        {
          value: null,
          title: 'Commentaires',
          custom: true,
          list: []
        }
      ]
    } as Dossier;
  }

  buildCommentairePartenaire(): Dossier {
    return {
      value: null,
      title: '',
      list: [
        {
          value: this.commentaireApporteur,
          title: null,
          custom: true,
          list: []
        }
      ]
    } as Dossier;
  }
  buildContrePartie(): Dossier {
    const ratifs = this.ddfData.blocContrepartie;
    return {
      value: null,
      title: 'ContrePartie(Données INSEE) ',
      hide: !this.isInterne,
      list: [
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Enseigne',
              value: ratifs.enseigne
            },
            {
              title: 'NAF',
              value: ratifs.codeNaf
                ? ratifs.codeNaf + ' (' + ratifs.libelleNaf + ')'
                : null
            },
            {
              title: 'Effectif',
              value: ratifs.effectif,
              isNumber: true
            },
            {
              title: `Adresse de l'établissement principal`,
              value: ratifs.adresseEtablissement
                ? ratifs.adresseEtablissement.join(', ')
                : null
            }
          ]
        } as Dossier,
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Forme juridique',
              value: ratifs.categorieJuridique
                ? ratifs.categorieJuridique + ' (' + ratifs.formeJuridique + ')'
                : null
            },
            {
              title: `Chiffre d'affaires`,
              value: ratifs.chiffreAffaires
            },
            {
              title: 'Cote BDF',
              value: ratifs.coteBDF
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }
  buildPieces() {
    const list = this.pieces;
    const type = [];
    const result = [];
    const bloc = list.map(it => {
      const item = this.buildPiece(it);
      if (type.indexOf(item.value) > -1) {
        const res = result.filter(ite => ite.value === item.value) as Dossier[];
        res[0].list = res[0].list.concat(item.list);
      } else {
        type.push(item.value);
        result.push(item);
      }
      return item;
    });
    return result;
  }
  buildPiece(item) {
    const list = [
      /* {
        title: 'id',
        value: item.oid
      },*/
      {
        title: '',
        value:
          item.nomDocument && item.nomDocument.indexOf('__') === -1
            ? item.nomDocument
            : item.nomDocument.split('__')[1]
      }
      /* {
        title: 'Type de document',
        value: item.typeDocument
      },
      {
        title: 'Status',
        value: item.status
      }*/
    ];
    const bloc = new Dossier('', list, item.typeDocument);
    return bloc;
  }

  buildSimulation(isContrat?): Dossier {
    const simulation = isContrat
      ? this.selectedContrat.ratification
      : this.selectedRatification;
    const financement =
      simulation && simulation.planFinancement
        ? simulation.planFinancement
        : {};
    const bareme = simulation && simulation.bareme ? simulation.bareme : {};
    if (isContrat) {
      return {
        value: null,
        title: 'Simulation',
        list: [
          {
            value: null,
            title: null,
            list: [
              this.set('Reference partenaire', simulation.referenceApporteur),
              this.set(
                'Produit commercial',
                simulation.produitCommercial.libelle
              ),
              this.set('Durée', simulation.duree),
              this.set('Autorisation restante', '??')
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Montant', simulation.montant),
              this.set('Loyer financier', financement.loyerFinancierMajore),
              this.set('Frais de montage', simulation.fraisDeMontage),
              this.set('Financement', simulation.prctFinancement, {suffix: '%'}),
              this.set('Clause indexation', financement.clauseIndexation)
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Commision partenaire', simulation.commissionApporteur),
              this.set('Dérogation', simulation.motifDerogation),
              this.set('Taux de TVA', financement.tauxTVA),
              this.set('Barème', simulation.bareme)
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Barème', simulation.commissionApporteur),
              this.set('Code barème origine', simulation.motifDerogation),
              Dossier.getEmptyDossier(),
              Dossier.getEmptyDossier()
            ]
          }
        ]
      } as Dossier;
    }
    return {
      value: null,
      title: 'Simulation',
      list: [
        {
          value: null,
          title: 'Données générales',
          list: [
            {
              title: this.isInterne ? 'Référence externe' : 'Vos références',
              value:
                simulation && simulation.referenceApporteur
                  ? simulation.referenceApporteur
                  : ''
            },
            {
              title: 'Produit commercial',
              // tslint:disable-next-line:max-line-length
              value:
                simulation &&
                simulation.produitCommercial &&
                simulation.produitCommercial.libelle
                  ? simulation.produitCommercial.libelle
                  : ''
            },
            {
              title: 'Montant',
              value: financement.montantFinancement,
              isNumber: true,
              suffix: '€'
            },
            {
              title: 'Durée',
              value: financement.duree,
              isNumber: true,
              suffix: 'mois'
            }
          ]
        } as Dossier,
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Frais de montage',
              value: simulation.montantFraisDeMontage
                ? simulation.montantFraisDeMontage.montant
                : '',
              suffix: '€'
            },
            this.set('Financement', simulation.prctFinancement, {suffix: '%'}),
            {
              title: 'Auteur',
              value:
                simulation && simulation.vendeurRatification
                  ? simulation.vendeurRatification.prenom +
                    ' ' +
                    simulation.vendeurRatification.nom
                  : ''
            },
            {
              title: 'Commentaire',
              value: ''
            },
            {
              title: 'Périodicité',
              value: financement.periodicite
                ? financement.periodicite.libelle
                : ''
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Échéancier',
          custom: true,
          list: []
        },
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Taux global',
              value: financement.taux,
              isNumber: true,
              suffix: '%',
              hide: !this.isInterne
            },
            {
              title: 'Taux de refinancement',
              value: financement.tauxRefinancement,
              suffix: '%',
              hide: !this.isInterne
            },
            {
              title: 'Taux de marge',
              value: financement.tauxMarge,
              suffix: '%',
              hide: !this.isInterne
            },
            {
              title: 'Periodicité du taux',
              value: financement.periodiciteTaux
                ? financement.periodiciteTaux.libelle
                : '',
              hide: !this.isInterne
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Terme',
              value:
                financement && financement.terme
                  ? financement.terme.libelle
                  : null
            },
            {
              title: 'Mode amortissement',
              value:
                financement && financement.modeAmortissement
                  ? financement.modeAmortissement.libelle
                  : null
            },
            {
              title: 'Taux T.V.A.',
              value: financement.tauxTVA,
              isNumber: true,
              suffix: '%'
            },
            {
              title: 'Commission partenaire',
              value: simulation && simulation.commissionApporteur,
              suffix: '%',
              hide: !this.isInterne
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          hide: !this.isInterne,
          list: [
            {
              title: 'Code barème',
              value: bareme.code,
              hide: !this.isInterne
            },

            {
              title: 'Spread',
              value: bareme.libelleSpread,
              hide: !this.isInterne
            },
            {
              title: 'Derogation',
              value:
                simulation && <boolean>(<any>simulation.topDerogation) === true
                  ? 'Oui'
                  : '',
              hide: !this.isInterne
              // value: simulation.motifDerogation
            },
            {
              title: 'Origine dérogation',
              value:
                simulation && simulation.motifDerogation
                  ? simulation.motifDerogation.libelle
                  : '',
              hide: !this.isInterne
            }
          ]
        } as Dossier
      ]
    };
  }
  initContrat(res) {
    // this.selectedRatification = null;
    this.selectedContrat = res as ContratInfo;
    if (this.selectedRatification.statut) {
      this.selectedRatification.statut.libelle = this.replaceStatut(
        this.selectedRatification.statut.libelle
      );
    }
    if (this.selectedRatification.statutRatification) {
      this.selectedRatification.statutRatification.libelle = this.replaceStatut(
        this.selectedRatification.statutRatification.libelle
      );
    }
    /* Comment by Tojo 22/11/2018
   this.setDossierDatesContrat();
   this.memory.contrat = this.selectedContrat;
   this.setContratView();
*/
    this.currentTabulation = 0;
    this.selectedIndexStepper = 2;
    this.dossierLoading = false;
  }
  initRatification(res) {
    this.selectedRatification = res;
    this.dossierRatifie.ratifications.forEach(rat => {
      if (rat.chrono === this.selectedRatification.chrono) {
        rat = this.selectedRatification;
      }
    });
    this.selectedContrat = null;
    this.currentTabulation = 0;
    this.selectedIndexStepper = 1;
    this.dossierLoading = false;
    /* Comment by Tojo 22/11/2018
    this.memory.contrat = null;
    this.setRatificationView();
    */
  }

  initRatificationSelected(e: RatificationInfo) {
    this.selectedRatification = e;
    this.memory.ratification = e;
    this.dossierLoading = true;
    this.numEkip = '';

    // Tojo, le 06/12/2018 : Je recupère le numéro EKIP avant de récuperer la ratification.
    if (this.isInterne) {
      this.ratifservice
        .getContrat({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.selectedContrat = resultat.content as ContratInfo;
            this.ratifservice
              .getEkipnum({
                dossierId: this.numDoss,
                chronoRatif: this.selectedRatification.chrono,
                chronoContrat: this.selectedContrat.chrono
              })
              .subscribe(
                resultat2 => {
                  const res = <any>resultat2.content;
                  this.numEkip = res.numeroEKIP;
                  console.log(
                    'numero EKIP ' +
                      this.selectedRatification.chrono +
                      '/' +
                      this.selectedContrat.chrono +
                      ' : ' +
                      this.numEkip
                  );
                  this.ratificationSelected(e);
                },
                err => {
                  this.numEkip = '';
                  // this.numEkip = '001329896-00';
                  if (this.mockService.isDev()) {
                    console.log('serviceMock');
                  }
                  console.error('Numéro EKIP introuvable');
                  this.ratificationSelected(e);
                }
              );
          },
          err => {
            this.numEkip = '';
            if (this.mockService.isDev()) {
              console.log('mock service');
              this.initContrat(this.mock[3]);
            }
            console.error('Contrat introuvable');
            this.ratificationSelected(e);
          }
        );
    } else {
      this.ratificationSelected(e);
    }
  }

  ratificationSelected(e: RatificationInfo) {
    this.selectedRatification = e;
    this.memory.ratification = e;
    this.listDossierStepper = [
      new DossierStepper(),
      new DossierStepper(),
      new DossierStepper()
    ];
    console.log('e.statutRatification.code ' + e.statutRatification.code);
    if (
      e.statutRatification.code === 'RATIF_CO' ||
      e.statutRatification.code === 'MONT_ENC'
    ) {
      this.ratifservice
        .getRatification({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.selectedRatification = resultat.content;
            this.setAccordStepper();
            this.setRatificationStepper();
            // this.initRatification(resultat.content);
          },
          err => {
            if (this.mockService.isDev()) {
              console.log('serviceMock');
              this.initRatification(this.mock[3]);
            }
            console.error('detail ratif  introuvable');
          }
        );
      this.ratifservice
        .getContrat({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.initContrat(resultat.content);
            this.setContratStepper();
            //  this.getNumEkipStatut();
          },
          err => {
            if (this.mockService.isDev()) {
              console.log('mock service');
              this.initContrat(this.mock[3]);
            }
            console.error('contrat introuvable');
          }
        );
    } else {
      this.ratifservice
        .getRatification({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.initRatification(resultat.content);
            this.setAccordStepper();
            this.setRatificationStepper();
            //  this.getNumEkipStatut();
          },
          err => {
            if (this.mockService.isDev()) {
              console.log('serviceMock');
              this.initRatification(this.mock[3]);
            }
            console.error('detail ratif  introuvable');
          }
        );
    }
    /* this.setRatificationView();
     this.currentTabulation = 1;*/
  }

  setRatificationView() {
    this.setPalierRatification();
    this.setMaterielRatification();
    this.contratContent = [
      this.buildInfosVendeur(),
      this.buildSimulation(),
      this.buildIdentificationClient(),
      this.buildStatutRatification(),
      // this.buildStatut(),
      this.buildMaterielFinances(),
      this.buildComplementFinancement(),
      this.buildAutreMajoration(),
      this.buildModeReglement(),
      this.buildPrestationAnnexe(),
      this.buildGaranties()
    ];
    this.currentTabulation = 1;
    this.setDossierDatesRatification();
    this.dossierLoading = false;
  }

  setPalierRatification() {
    const { paliers } = this.selectedRatification.planFinancement;
    this.paliers = paliers ? paliers : [];
    this.palierColumns = this.setPalierColumns();
  }

  setMaterielRatification() {
    this.materielFinances = this.selectedRatification.materielsFinancement
      ? this.selectedRatification.materielsFinancement
      : [];
    this.materielColumns = this.setMaterielColumns();
  }

  setPalierColumns() {
    return [
      {
        columnDef: 'Rang du palier',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.RANG'),
        cell: (row: PalierInfo) => row.indice
      },
      {
        columnDef: `Nombre d'échéances`,
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.ECHEANCE'),
        cell: (row: PalierInfo) => row.nbEcheances
      },
      {
        columnDef: 'Periodicité',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.PERIODE'),
        cell: (row: PalierInfo) => row.periodicite.libelle
      },
      {
        columnDef: 'loyer (€)',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.LOYER'),
        cell: (row: PalierInfo) => this.formatNumber.transform(row.loyer)
      }
    ] as TableColumnDefinitionModel[];
  }

  setElementExterneColumns() {
    return [
      {
        columnDef: 'designation',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DESIGNATION'),
        cell: (row: BienInfo) => row.designation
      },
      {
        columnDef: `Serial`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.SERIALNUMBER'),
        cell: (row: BienInfo) => row.numeroSerie
      }
    ] as TableColumnDefinitionModel[];
  }

  setElementColumns() {
    return [
      {
        columnDef: 'designation',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DESIGNATION'),
        tooltip: 'hasTooltip',
        cell: (row: BienInfo) => row.designation
      },
      {
        columnDef: `Serial`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.SERIALNUMBER'),
        cell: (row: BienInfo) => row.numeroSerie
      },
      {
        columnDef: 'id',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.IDNUMBER'),
        cell: (row: BienInfo) => row.immobilisation
      },
      {
        columnDef: 'Montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: BienInfo) => this.formatNumber.transform(row.montant)
      },
      {
        columnDef: 'Num fournisseur',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NUMFOURNISSEUR'),
        cell: (row: BienInfo) => row.numeroFournisseur
      },
      {
        columnDef: 'Nom fournisseur',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NOMFOURNISSEUR'),
        tooltip: 'hasTooltip',
        cell: (row: BienInfo) => row.nomFournisseur
      },
      {
        columnDef: 'Taux Amorti',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.AMORTISSEMENT'),
        cell: (row: BienInfo) => row.typeAmortissement
      }
    ] as TableColumnDefinitionModel[];
  }
  setMaterielColumns() {
    return [
      {
        columnDef: 'Nb',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB'),
        cell: (row: MaterielFinancementInfo) => row.nbMateriels
      },
      {
        columnDef: 'Désignation',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DESIGNATION'),
        tooltip: 'hasTooltip',
        cell: (row: MaterielFinancementInfo) => row.designation
      },
      {
        columnDef: `Type`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TYPE'),
        cell: (row: MaterielFinancementInfo) => row.type
      },
      {
        columnDef: `Marque`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MARQUE'),
        cell: (row: MaterielFinancementInfo) => row.marque
      },
      {
        columnDef: 'Numéro de série',
        tooltip: 'hasTooltip',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.SERIALNUMBER'),
        cell: (row: MaterielFinancementInfo) => row.numeroSerie
      },
      {
        columnDef: 'État',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.ETAT'),
        cell: (row: MaterielFinancementInfo) =>
          row.materielNeuf ? 'Neuf' : 'Occasion'
      },
      {
        columnDef: 'Montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: MaterielFinancementInfo | MaterielContratInfo) =>
          this.formatNumber.transform(
            (<MaterielContratInfo>row).montantHT
              ? this.get((<MaterielContratInfo>row).montantHT).montant
              : this.get(row.montant).montant
          )
      },
      {
        columnDef: 'Taux TVA',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TAUX'),
        cell: (row: MaterielFinancementInfo) =>
          this.formatNumber.transform(row.tauxTva)
      },
      {
        columnDef: 'Année',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.ANNEE_MISE_EN_SERVICE'
        ),
        cell: (row: MaterielFinancementInfo) => row.anneeMiseEnService
      }
    ] as TableColumnDefinitionModel[];
  }

  setHistoriqueDossierColumns() {
    return [
      {
        columnDef: 'Date',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE'),
        cell: (row: HistoEditionContratInfo) => row.date,
        date: true,
        time: true
      },
      {
        columnDef: 'Action',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.ACTION'),
        cell: (row: HistoEditionContratInfo) => row.action
      },
      {
        columnDef: `Gestionnaire`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.GESTIONNAIRE'),
        tooltip: true,
        cell: (row: HistoEditionContratInfo) =>
          this.get(row.gestionnaire).nomPrenom
      },
      {
        columnDef: `Version`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.VERSION'),
        cell: (row: HistoEditionContratInfo) => row.chrono
      },
      {
        columnDef: `Emmetteur`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.EMMETTEUR'),
        tooltip: true,
        cell: (row: HistoEditionContratInfo) =>
          this.get(this.get(row.emmetteur).user).nomPrenom
      },
      {
        columnDef: `Destinataires`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DESTINATAIRES'),
        cell: (row: HistoEditionContratInfo) =>
          this.get(row.destinataires, true).join()
      }
    ] as TableColumnDefinitionModel[];
  }

  setHistoriqueStatutCommercialColumnsColumns() {
    return [
      {
        columnDef: 'Date',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE'),
        cell: (row: HistoriqueStatutCommercialInfo) =>
          row.statutCommercial.infoMAJ.date,
        date: true,
        time: true
      },
      {
        columnDef: 'Statut',

        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUT'),
        tooltip: 'hasTooltip',
        cell: (row: HistoriqueStatutCommercialInfo) =>
          row.statutCommercial.statut.libelle
      },
      {
        columnDef: `Gestionnaire`,
        forbiddenScreens: ['xs'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.GESTIONNAIRE'),
        cell: (row: HistoriqueStatutCommercialInfo) =>
          row.statutCommercial.infoMAJ.user.nomPrenom
      }
    ] as TableColumnDefinitionModel[];
  }

  buildComplementFinancement(isContrat?): Dossier {
    const { montantPremierLoyerMajore, montantVR } = isContrat
      ? this.selectedContrat.ratification.planFinancement
      : this.selectedRatification.planFinancement;

    const { tauxVR, tauxPremierLoyerMajore } = isContrat
      ? this.get(this.selectedContrat.ratification.planFinancement)
      : this.get(this.selectedRatification.planFinancement);

    return {
      value: null,
      title: 'Complément du plan financier',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Premier loyer majoré',
              value: tauxPremierLoyerMajore,
              // value: montantPremierLoyerMajore
              suffix: '%'
            },
            {
              title: 'Valeur résiduelle',
              value: tauxVR,
              // value: montantVR
              suffix: '%'
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }

  buildComplementFinancementAccord(): Dossier {
    const { tauxVR, premierLoyerMajore } = this.get(
      this.ddfData.blocPlanFinancement
    );

    return {
      value: null,
      title: 'Complément du plan financier ',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Premier loyer majoré',
              value: premierLoyerMajore,
              // value: montantPremierLoyerMajore
              suffix: '%'
            },
            {
              title: 'Valeur résiduelle',
              value: tauxVR,
              // value: montantVR
              suffix: '%'
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }

  buildMajorations(): Dossier {
    /*
    const { topCalage, dateFinancement, nbJoursCalage, nbMoisCalage } = this.selectedRatification.calage;

    const list: Dossier[] = [];
    if (this.selectedRatification.autreMajorations) {
      this.selectedRatification.autreMajorations.forEach(
        autremajoration => {
          list.push(this.set(autremajoration.libelle, autremajoration.pourcentMajoration + ' %'));
        }
      );
      }
*/
    return {
      value: null,
      title: 'Majorations',
      list: [
        /*
        {
          title: 'Mode amortissement',
          value: montantVR
        }*/
      ]
    } as Dossier;
  }
  buildModeReglement(isContrat?): Dossier {
    const { modeReglement } = isContrat
      ? this.selectedContrat.ratification.planFinancement
      : this.selectedRatification.planFinancement;
    return {
      value: null,
      title: 'Règlement',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Mode de règlement',
              value: modeReglement ? modeReglement.libelle : null
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildDecisions(isContrat?): Dossier {
    const { decision } = this.ddfData;
    return {
      value: null,
      title: 'Décision',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Dernière décision',
              value: decision ? decision.decision + ' ' + decision.avis : null
            },
            {
              title: 'Commentaire',
              value: decision ? decision.messageClient : ''
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildPrestationAnnexe(isContrat?): Dossier {
    const {
      loyerToutInclus,
      loyerFinancierBareme,
      loyerFinancierMajore
    } = isContrat
      ? this.selectedContrat.ratification.planFinancement
      : this.selectedRatification.planFinancement;

    let list: Dossier[] = [];

    if (isContrat) {
      if (this.selectedContrat.ratification.prestations) {
        list = this.selectedContrat.ratification.prestations.map(it =>
          this.set(it.libelle, it.pourcentMajoration, '% du montant')
        );
        list.push(this.set('Loyer financier barème', loyerFinancierBareme));
        list.push(this.set('Loyer financier majoré', loyerFinancierMajore));
        list.push(this.set('Loyer total', loyerToutInclus, '€ HT'));
      }
    } else {
      if (this.selectedRatification.prestations) {
        list = this.selectedRatification.prestations.map(it =>
          this.set(it.libelle, it.pourcentMajoration, '% du montant')
        );
        list.push(this.set('Loyer total', loyerToutInclus, '€ HT'));
      }
    }
    return {
      value: null,
      title: 'Prestations annexes, assurance (par période)',
      list: [
        {
          value: null,
          title: null,
          list: list
        }
      ]
    } as Dossier;
  }
  buildIdentificationVendeur(isContrat?): Dossier {
    const vendeur = this.selectedContrat.vendeur;
    return {
      value: null,
      title: 'Identification du vendeur',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Partenaire',
              value: vendeur.agence.apporteur.libelle,
              hide: !this.isInterne
            },
            {
              title: 'Agence',
              value: vendeur.agence.libelle,
              hide: !this.isInterne
            },
            {
              title: 'Nom',
              value: vendeur.nom
            },
            {
              title: 'Prenom',
              value: vendeur.prenom
            }
          ]
        },
        {
          value: null,
          title: null,
          list: [
            this.set('Mail', vendeur.mail),
            this.set('Téléphone', vendeur.telephone),
            this.set('Fax', vendeur.fax),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildElementFinancier() {
    let elFi = this.selectedContrat.elementFinancier;
    elFi = elFi ? elFi : {};
    const prodFi = this.selectedContrat.produitCommercial
      ? this.selectedContrat.produitCommercial.produitFinancier
      : {};
    const dossier = this.build('Element financier', [
      this.set('Produit financier', this.get(elFi.natureCode)),
      this.set('Montant', elFi.montant, '€ HT'),
      this.set('Durée', elFi.duree, 'mois'),
      this.set('Terme', elFi.terme),
      this.set('Périodicité', elFi.periodicite),
      this.set('Type de plan', elFi.modeAmortissement),
      this.set('Date du 1er loyer', elFi.datePremierLoyer, { isDate: true }),
      this.set("Option d'achat (montant)", elFi.montantOptionAchat, '€ HT'),
      this.set("Option d'achat (Taux)", elFi.tauxOptionAchat, '% du montant')
    ]);
    return dossier;
  }
  get(val, isArray?) {
    const def = isArray ? [] : {};
    return val ? val : def;
  }
  buildClient() {
    const client = this.get(this.selectedContrat.client) as ClientInfo;
    const eta = this.get(
      this.selectedContrat.etablissementClient
    ) as EtablissementClientInfo;
    const add = <AdresseCompleteInfo>this.get(eta.adresseComplete);
    const dirigeant = this.get(eta.dirigeant) as PersonneInfo;
    const rep = this.get(eta.representantClient) as RepresentantClientInfo;
    const dossier = this.build('Client', null, [
      this.bloc('Siège social du client', [
        this.set('Numéro SIREN', Number(client.siren)),
        this.set(
          'Raison sociale',
          client.raisonSociale ? client.raisonSociale : client.nom
        ),
        this.set("Complément d'adresse", add.complementAdresse),
        this.set('Adresse', add.adresse),
        this.set('Code postal', add.codePostal),
        this.set('Ville', add.ville),
        this.set('Numéro de téléphone', eta.numeroTelephone),
        this.set('Forme juridique', eta.formeJuridique),
        this.set('NAF', eta.codeNaf + ' ' + eta.libelleNaf),
        this.set("Date de début d'activité", eta.dateDebutActivite, {
          isDate: true
        }),
        this.set("Chiffre d'affaire", eta.chiffreAffaire),
        this.set('Effectif', eta.effectif),
        this.set('Fonds de commerce', eta.fondsCommerce),
        this.set('Loyer', eta.loyer)
      ]),
      this.bloc('Dirigeant', [
        // this.set('Civilité', dirigeant.civilite),
        // this.set('Nom', dirigeant.nom + (dirigeant.nomJeuneFille) ? `(${dirigeant.nomJeuneFille}` : ''),
        this.set('Nom', dirigeant.nom),
        this.set('Nom de jeune fille', dirigeant.nomJeuneFille),
        this.set('Prénom', dirigeant.prenom),
        this.set('Date de naissance', dirigeant.dateNaissance, {
          isDate: true
        }),
        this.set('Lieu de naissance', dirigeant.lieuNaissance),
        this.set('Situation familiale', dirigeant.situationFamiliale)
      ]),
      this.bloc('Représentant du client', [
        this.set('Civilité', rep.civilite),
        //  this.set('Nom', (rep.nom ? rep.nom : '')  + (rep.nomJeuneFille) ? ` (${rep.nomJeuneFille}` : ''),
        this.set('Nom', rep.nom),
        // this.set('Nom de jeune fille', rep.nomJeuneFille),
        this.set('Prénom', rep.prenom),
        this.set('Qualité', rep.qualite),
        this.set('Ville', rep.ville),
        this.set('Téléphone', rep.numeroTelephone),
        this.set('Comptable assignataire', rep.comptableAssignataire),
        this.set('Ordonnateur', rep.ordonnateur)
      ])
    ]);
    return dossier;
  }
  buildInstallation() {
    const livraison = this.get(this.selectedContrat.livraison) as LivraisonInfo;
    const ins = this.get(livraison.adresse) as AdresseCompleteInfo;
    const dossier = this.build('Installation', [
      this.set("Complément d'adresse", ins.complementAdresse),
      this.set('Adresse', ins.adresse),
      this.set('Code postal', ins.codePostal),
      this.set('Ville', ins.ville),
      this.set(
        'Date prévisionnelle de livraison',
        livraison.datePrevisionnelle,
        { isDate: true }
      )
    ]);
    return dossier;
  }
  buildFacturation() {
    const facturation = this.get(
      this.selectedContrat.facturation
    ) as FacturationInfo;
    const add = this.get(
      facturation.adresseCompleteFacturation
    ) as AdresseCompleteInfo;
    const bnk = this.get(facturation.banque) as BanqueInfo;
    const adrbnk = this.get(bnk.adresseComplete) as AdresseCompleteInfo;
    const rib = this.get(facturation.rib) as RibInfo;

    let domiciliationBloc: Dossier;
    if (rib.bic && rib.iban) {
      domiciliationBloc = this.bloc('Domiciliation', [
        this.set('Nom de la banque', bnk.nomBanque),
        this.set("Nom de l'agence de la banque", bnk.nomAgenceBanque),
        this.set("Complément d'adresse", adrbnk.complementAdresse),
        this.set('Adresse', adrbnk.adresse),
        this.set('Code postal', adrbnk.codePostal),
        this.set('Ville', adrbnk.ville),
        this.set('Personne à joindre', facturation.nomPersonneAJoindre),
        this.set('Téléphone', facturation.numeroTelephonePersonneAJoindre),
        this.set('Compte IBAN', rib.iban),
        this.set('BIC', rib.bic)
      ]);
    } else {
      domiciliationBloc = this.bloc('Domiciliation', [
        this.set('Nom de la banque', bnk.nomBanque),
        this.set("Nom de l'agence de la banque", bnk.nomAgenceBanque),
        this.set("Complément d'adresse", adrbnk.complementAdresse),
        this.set('Adresse', adrbnk.adresse),
        this.set('Code postal', adrbnk.codePostal),
        this.set('Ville', adrbnk.ville),
        this.set('Personne à joindre', facturation.nomPersonneAJoindre),
        this.set('Téléphone', facturation.numeroTelephonePersonneAJoindre),
        this.set('Code banque', rib.codeBanque),
        this.set('Code guichet', rib.codeGuichet),
        this.set('N° compte', rib.numeroCompte),
        this.set('Clé R.I.B.', rib.cleRib)
      ]);
    }

    const dossier = this.build('Facturation', null, [
      this.bloc('', [
        this.set("Complément d'adresse", add.complementAdresse),
        this.set('Adresse', add.adresse),
        this.set('Code postal', add.codePostal),
        this.set('Ville', add.ville)
      ]),
      domiciliationBloc
    ]);
    return dossier;
  }
  buildPrestationAnnexeContrat() {
    const obs = this.selectedContrat.observationsParticulieres;
    // tslint:disable-next-line:max-line-length
    const prest = [
      ...this.get(this.selectedContrat.prestationsContrat, true),
      ...this.get(this.selectedContrat.prestationsRatification, true)
    ] as PrestationInfo[];
    return this.build('Prestations annexes, assurance (par période)', null, [
      this.bloc(
        '',
        prest.map(it =>
          this.set(it.libelle, it.pourcentMontantMajoration, '% du montant')
        )
      ),
      this.bloc('Observations particulières', [this.set('', obs)])
    ]);
  }
  buildIdentificationClient(isContrat?): Dossier {
    const commentaire = isContrat
      ? this.selectedContrat.ratification.donneesInternes.commentaireInterne
      : this.selectedRatification.donneesInternes.commentaireInterne;

    const { siren, nom } = isContrat
      ? this.selectedContrat.ratification.client
      : this.selectedRatification.client
      ? this.selectedRatification.client
      : { siren: null, nom: null };
    return {
      value: null,
      title: 'Identification du client',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Numero SIREN',
              value: siren,
              isNumber: true
            },
            {
              title: 'Nom',
              value: nom
            },
            {
              title: 'Commentaire',
              value: commentaire
            },
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildHistoDossier() {
    return this.build('Historique du dossier', null, [
      this.set(null, null, { custom: true })
    ]);
  }
  buildMaterielFinances(): Dossier {
    return {
      value: null,
      title: 'Matériels financés',
      list: [
        {
          value: null,
          title: null,
          custom: true
          // list: this.selectedRatification.materielsFinancement.map(it => this.set(it.designation, it.anneeMiseEnService))
        }
      ]
    } as Dossier;
  }
  buildMaterielPrincipal(isContrat?): Dossier {
    const materiels = this.selectedContrat.materiels;
    return this.build(
      'Matériel principal ( Neuf )',
      materiels.map(it => this.set(it.designation, it.anneeMiseEnService))
    );
  }
  dossierSelected() {
    this.selectedRatification = null;
    this.selectedContrat = null;
    this.setView();
    this.currentTabulation = 0;
  }
  set(title, value, suffix?): Dossier {
    return Dossier.set(title, value, suffix) as Dossier;
  }
  /*
  build(title, list, multi?, custom?) {
    return {
      value: null,
      title: title,
      list: (multi) ? multi : [
        {
          value: null,
          title: null,
          list: list
        }
      ]
    } as Dossier;
  }*/
  build(title, list, multi?, custom?) {
    return Dossier.build(title, list, multi, custom) as Dossier;
  }
  bloc(title, list) {
    return {
      value: null,
      title: title,
      list: list
    } as Dossier;
  }
  setDossierDatesRatification() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(
      new Date(this.dossierRatifie.dateSaisie),
      'Accord'
    );
    date2 = TemporalFreezeItem.setcurrentStep(
      new Date(this.selectedRatification.dateCreation),
      'Accord détaillé'
    );
    date3 = TemporalFreezeItem.setEnd(
      new Date(
        2 * Number(this.selectedRatification.dateCreation) -
          Number(this.dossierRatifie.dateSaisie)
      ),
      'Contrat'
    );
    this.dossierDates = [date1, date2, date3];
  }
  setDossierDatesContrat() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(
      new Date(this.ddfData.dateSaisie),
      'Accord'
    );
    date2 = TemporalFreezeItem.setStart(
      new Date(this.selectedRatification.dateCreation),
      'Accord détaillé'
    );
    // tslint:disable-next-line:max-line-length
    const my = (<HistoEditionContratInfo[]>(
      this.get(this.selectedContrat.historiquesDossiers, true)
    )).find(it => it.action === 'Contrat édité');
    if (my && my.date) {
      date3 = TemporalFreezeItem.setcurrentStep(
        new Date(Number(my.date)),
        'Contrat'
      );
    } else {
      date3 = TemporalFreezeItem.setcurrentStep(
        new Date(Number(this.selectedContrat.dateCreation)),
        'Contrat'
      );
    }
    this.dossierDates = [date1, date2, date3];
  }
  setMontageDates() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem,
      date4: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(new Date(2018, 2, 12), 'reçu');
    date2 = TemporalFreezeItem.setcurrentStep(
      new Date(2018, 3, 14),
      'En traitement'
    );
    date3 = TemporalFreezeItem.setEnd(new Date(2018, 4, 24), 'Anomalies');
    date4 = TemporalFreezeItem.setEnd(new Date(2018, 5, 28), 'Payés');
    this.montageFreezeDates = [date1, date2, date3, date4];
  }
  setParcDates(el) {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem,
      date4: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(
      new Date(el.dateDebutLocation),
      'Début de location'
    );
    date2 = TemporalFreezeItem.setEnd(
      new Date(el.datePremiereEcheance),
      'Première échéance'
    );
    date3 = TemporalFreezeItem.setcurrentStep(
      new Date(el.dateProchaineEcheance),
      'Prochaine échéance'
    );
    date4 = TemporalFreezeItem.setEnd(
      new Date(el.dateFinLocation),
      'Fin de location'
    );
    this.parcFreezeDates = [date1, date2, date3, date4].filter(it => it);
  }

  getContratEditeContent() {
    return [
      this.buildInfosVendeur(true),
      this.buildElementFinancier(),
      this.buildClient(),
      this.buildInstallation(),
      this.buildFacturation(),
      this.buildPrestationAnnexeContrat(),
      this.buildMaterielFinances(),
      this.buildHistoDossier()
      // this.buildComplementFinancement()
    ];
  }

  freezeEventClicked(e: TemporalFreezeItem) {
    if (this.memory.contrat && e.label === 'Contrat') {
      this.contratContent = this.getContratEditeContent(); /* [
        this.buildInfosVendeur(true),
        this.buildSimulation(true),
        this.buildComplementFinancement(true),
        this.buildCalage(true),
        this.buildAutreMajoration(true),
        this.buildModeReglement(true),
        this.buildIdentificationVendeur(true),
        this.buildIdentificationClient(true),
        this.buildStatutRachat(true),
        this.buildPrestationAnnexe(true),
        this.buildMaterielPrincipal(true),
        this.buildGaranties(true)
      ];*/
      /* [
        this.buildInfosVendeur(true),
        this.buildElementFinancier(),
        this.buildClient(),
        this.buildInstallation(),
        this.buildFacturation(),
        this.buildPrestationAnnexe(true),
        this.buildMaterielFinances(true),
        this.buildHistoDossier()
      ];*/
    }
    if (this.memory.ratification && e.label === 'Accord détaillé') {
      this.setPalierRatification();
      this.setMaterielRatification();
      this.contratContent = [
        this.buildInfosVendeur(),
        this.buildSimulation(),
        this.buildIdentificationClient(),
        this.buildStatutRatification(),
        //  this.buildStatut(),
        this.buildMaterielFinances(),
        this.buildComplementFinancement(),
        this.buildAutreMajoration(),
        this.buildModeReglement(),
        this.buildPrestationAnnexe(),
        this.buildGaranties()
      ];
    }
    if (e.label === 'Accord') {
      this.setHistoriqueStatutCommercial();
      this.contratContent = [
        this.buildInfosVendeur(),
        this.buildInformationsGenerale(),
        this.buildStatut(),
        this.buildDecisions(),
        this.buildContrePartie()
      ];
    }
  }

  setAccordStepper() {
    this.setHistoriqueStatutCommercial();
    this.listDossierStepper[0].contratContent = [
      this.buildInfosVendeur(),
      this.buildInformationsGenerale(),
      this.buildComplementFinancementAccord(),
      this.buildStatut(),
      this.buildDecisions(),
      this.buildContrePartie()
    ] as Dossier[];
    this.listDossierStepper[0].title = this.transServ.instant('STEPPER.ACCORD');
    this.listDossierStepper[0].date = Global.mapTimestampToDate(<number>(
      (<any>this.ddfData.dateSaisie)
    ));
    this.listDossierStepper[0].active = true;
  }

  setRatificationStepper() {
    this.setPalierRatification();
    this.setMaterielRatification();
    this.listDossierStepper[1].contratContent = [
      this.buildInfosVendeur(),
      this.buildSimulation(),
      this.buildIdentificationClient(),
      this.buildStatutRatification(),
      // this.buildStatut(),
      this.buildMaterielFinances(),
      this.buildComplementFinancement(),
      this.buildAutreMajoration(),
      this.buildModeReglement(),
      this.buildPrestationAnnexe(),
      this.buildGaranties()
    ] as Dossier[];
    this.listDossierStepper[1].title = this.transServ.instant(
      'STEPPER.ACCORD_DETAILLE'
    );
    this.listDossierStepper[1].date = Global.mapTimestampToDate(<number>(
      (<any>this.selectedRatification.dateCreation)
    ));
    this.listDossierStepper[1].active = true;
  }

  setContratStepper() {
    this.setMaterielFinances();
    this.setHistoriqueDossier();
    this.listDossierStepper[2].contratContent = [
      this.buildInfosVendeur(true),
      this.buildElementFinancier(),
      this.buildClient(),
      this.buildInstallation(),
      this.buildFacturation(),
      this.buildPrestationAnnexeContrat(),
      this.buildMaterielFinances(),
      this.buildHistoDossier()
    ] as Dossier[];
    this.listDossierStepper[2].title = this.transServ.instant(
      'STEPPER.CONTRAT'
    );
    const my = (<HistoEditionContratInfo[]>(
      this.get(this.selectedContrat.historiquesDossiers, true)
    )).find(it => it.action === 'Contrat édité');
    if (my && my.date) {
      this.listDossierStepper[2].date = Global.mapTimestampToDate(<number>(
        (<any>my.date)
      ));
    } else {
      this.listDossierStepper[2].date = Global.mapTimestampToDate(<number>(
        (<any>this.selectedContrat.dateCreation)
      ));
    }
    this.listDossierStepper[2].active = true;
  }
  DDFSendPJ() {
    this.pjLoading = true;
    this.ddfService.sendPiecesDdf(this.numDoss, this.PJadded).subscribe(
      res => {
        this.pieces = [...this.pieces, ...this.get(res.content).pieces];
        this.piecesJointe = this.buildPieces();
        this.uploader.uploader.queue = [];
        this.pjLoading = false;
      },
      err => {
        this.snackBar.open(this.transServ.instant('SUIVI.FORM.PJ_ERROR'));
        this.pjLoading = false;
      }
    );
  }

  redirectToCreateRachat() {
    this.router.navigate(['rachat/demande/' + this.numDoss]);
  }

  browseFileSuccess(event) {
    this.browseFileLength = event.dateFilesLength;
    console.log(this.browseFileLength);
  }

  clickButtonActions() {
    this.openWaitDialogActions();
  }

  openWaitDialogActions(): void {
    if (this.type === Phase.DDF) {
      console.log('openWaitDialogActions DDF');
      this.ddf$ = this.ddfService
        .getStatusCommerciauxAutorises(this.numDoss)
        .subscribe(
          res => {
            const statutCommercialList = res.content as StatutCommercialAutoriseInfo[];
            console.log(JSON.stringify(statutCommercialList));
            const dialogRef = this.dialog.open(DossierWaitdialogComponent, {
              width: '700px',
              data: {
                type: 'changementStatutCommercial',
                statutCommercialList: statutCommercialList,
                statutCommercialCurrent: this.ddfData.statutCommercial,
                statutCommercialNewOid: null,
                numeroDossier: this.numDoss
              }
            });
            dialogRef.afterClosed().subscribe(result => {
              if (result && result.statutCommercialNewOid) {
                console.log('closeWaitDialogActions : submit');
                this.ddfService
                  .setStatusCommerciauxAutorises(this.numDoss, {
                    oidStatusCommercial: <number>result.statutCommercialNewOid
                  })
                  .subscribe(
                    res => {
                      console.log(
                        'setStatusCommerciauxAutorises OK : ' +
                          this.numDoss +
                          '/' +
                          result.statutCommercialNewOid
                      );
                      // on recharge la page
                      this.getDossierInfo();
                      this.openSnack('',
                        this.transServ.instant(
                          'SUIVI.WAITDIALOG.CHANGEMENT_STATUT_COMMERCIAL.SNACK.OK'
                        ), 5000
                      );
                    },
                    err => {
                      console.log(
                        'setStatusCommerciauxAutorises ERROR : ' +
                          this.numDoss +
                          '/' +
                          result.statutCommercialNewOid
                      );
                      this.openSnack('',
                        this.transServ.instant(
                          'SUIVI.WAITDIALOG.CHANGEMENT_STATUT_COMMERCIAL.SNACK.ERROR'
                        ), 5000
                      );
                    }
                  );

                //  this.ddf$ = this.ddfService.getStatusCommerciauxAutorises(this.numDoss).subscribe(
              } else {
                console.log('closeWaitDialogActions : cancel');
              }
            });
          },
          err => {
            console.log(
              'GetStatusCommerciauxAutorises erreur de récupération des infos',
              err
            );
          }
        );
    }
  }
  open(msg) {
    this.openSnack('Error:', msg, 5000);
  }
  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
}
