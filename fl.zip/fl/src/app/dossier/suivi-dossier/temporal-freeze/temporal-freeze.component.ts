import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ViewChildren,
  QueryList,
  AfterViewInit,
  Input,
  AfterViewChecked,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChange,
  SimpleChanges
} from '@angular/core';
import { last } from '@angular/router/src/utils/collection';
import Global from '../../../models/global-functions';

export class TemporalFreezeItem {
  date: Date;
  draggable?: boolean;
  icon?: string;
  label?: string;
  pourcent?: number;
  style?: any;
  hideDate?: boolean;
  isCurrentStep?: boolean;
  isDone?: boolean;
  data?: any;
  selected?: boolean;
  index: number;
  onhover?: (any) => {};

  constructor(date, lbl?, isCurrent?) {
    this.date = date;
    this.label = lbl;
    this.isCurrentStep = isCurrent;
  }
  static setStart(date, lbl?) {
    return new TemporalFreezeItem(date, lbl);
  }
  static setEnd(date, lbl?) {
    return new TemporalFreezeItem(date, lbl);
  }
  static setcurrentStep(date, lbl?) {
    return new TemporalFreezeItem(date, lbl, true);
  }
}
@Component({
  selector: 'app-temporal-freeze',
  templateUrl: './temporal-freeze.component.html',
  styleUrls: ['./temporal-freeze.component.scss']
})
export class TemporalFreezeComponent
  implements OnInit, AfterViewChecked, OnChanges {
  tools = Global;
  currentStepDate: Date;
  @Input()
  alreadySorted: boolean;
  @Input()
  items: TemporalFreezeItem[];
  @Input()
  standardized: boolean;
  @Output()
  itemClicked = new EventEmitter<TemporalFreezeItem>();
  bandWidth: number;
  @ViewChild('ref')
  lineOver: ElementRef;
  @ViewChildren('stepperLbl')
  lbls: QueryList<ElementRef>;
  constructor() {}
  ngAfterViewChecked() {
    this.lbls.map(r => {
      this.centerLabels(r);
    });
  }
  ngOnChanges(change: SimpleChanges) {
    if (change['items'] && change['items'].currentValue) {
      this.ngOnInit();
    }
  }
  ngOnInit() {
    if (this.items && this.items.length > 0) {
      this.setBandWith();
      this.computeDate();
    }
  }
  sortTempItem(item1, item2) {
    return item1.date.getTime() - item2.date.getTime();
  }
  setBandWith() {
    if (!this.alreadySorted) {
      this.items.sort(this.sortTempItem);
    }
    this.bandWidth =
      this.items[this.items.length - 1].date.getTime() -
      this.items[0].date.getTime();
  }
  computeDate() {
    let index = 0;
    this.items.map((it, i ) => {
      it.index = i;
      it.pourcent = this.standardized
        ? (index * 100) / (this.items.length - 1)
        : ((it.date.getTime() - this.items[0].date.getTime()) * 100) /
          this.bandWidth;
      index++;
      if (!it.style) {
        it.style = {};
      }
      if (it.isCurrentStep) {
        this.currentStepDate = it.date;
        this.lineOver.nativeElement.style.width = it.pourcent + '%';
      }
      it.style.left = it.pourcent + '%';
    });
    if (this.currentStepDate) {
      this.items.map(it => {
        if (it.date.getTime() <= this.currentStepDate.getTime()) {
          it.isDone = true;
        }
      });
    }
    /* let lastPourcent = null;
     this.items.forEach(it => {
       if (lastPourcent && it.pourcent - lastPourcent < 15) {
         it.pourcent += 15;
       }
       lastPourcent = it.pourcent;
     });*/
  }
  centerLabels(el: ElementRef) {
    el.nativeElement.style.left = `-${el.nativeElement.clientWidth / 2}px `;
  }
  itemGotClicked(e: TemporalFreezeItem) {
    this.itemClicked.emit(e);
    this.items.forEach(it => {
      if (it.index === e.index) {
        it.selected = true;
      } else {
        it.selected = false;
      }
    });


  }
}
