import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemporalFreezeComponent } from './temporal-freeze.component';

describe('TemporalFreezeComponent', () => {
  let component: TemporalFreezeComponent;
  let fixture: ComponentFixture<TemporalFreezeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemporalFreezeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemporalFreezeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
