import { Component, OnInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DossierInfo } from '../../models/dossier-info';

@Component({
  selector: 'app-details-financier',
  templateUrl: './details-financier.component.html',
  styleUrls: ['./details-financier.component.scss']
})
export class DetailsFinancierComponent implements OnInit {
  @Input() dossier: DossierInfo;

  public value = '';
  public showPlanF = true;
  public hideOptionsF = true;
  public hideAssurF = true;
  public coefficient = '';
  public periodiciteList: string[];
  public reglementList: string[];
  BaremeList = [
    { code: '332', id: 167, apporteur: null, libelle: 'Accord Cosme 1' },
    { code: '332', id: 168, apporteur: null, libelle: 'Accord Cosme 2' }
  ];

  assuranceList = [
    { code: '332', id: 167, apporteur: null, libelle: 'Assuarnce N1' },
    { code: '332', id: 168, apporteur: null, libelle: 'Assuarnce N2' }
  ];

  constructor(private translateService: TranslateService) {
    this.periodiciteList = [
      this.translateService.instant('DOSSIER.DETAILF.PLANF.OPTIONS.MENSUEL'),
      this.translateService.instant(
        'DOSSIER.DETAILF.PLANF.OPTIONS.TRIMESTRIEL'
      ),
      this.translateService.instant('DOSSIER.DETAILF.PLANF.OPTIONS.SEMESTRIEL'),
      this.translateService.instant('DOSSIER.DETAILF.PLANF.OPTIONS.ANNUEL')
    ];

    this.reglementList = [
      this.translateService.instant('DOSSIER.DETAILF.OPTIONSF.REGL.OPT1'),
      this.translateService.instant('DOSSIER.DETAILF.OPTIONSF.REGL.OPT2'),
      this.translateService.instant('DOSSIER.DETAILF.OPTIONSF.REGL.OPT3')
    ];
  }

  ngOnInit() {}
  public togglePlanF() {
    if (this.showPlanF) {
      this.showPlanF = false;
    } else {
      this.showPlanF = true;
    }
  }

  public toggleOptionsF() {
    if (!this.hideOptionsF) {
      this.hideOptionsF = true;
    } else {
      this.hideOptionsF = false;
    }
  }
  public toggleAssuranceF() {
    if (!this.hideAssurF) {
      this.hideAssurF = true;
    } else {
      this.hideAssurF = false;
    }
  }
}
