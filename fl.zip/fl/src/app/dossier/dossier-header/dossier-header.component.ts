import { Component, OnInit, Input } from '@angular/core';
import { DossierInfo } from '../../models/ddf';
import { DossierRatifieInfo } from '../../models/ddf';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
export class DossierHeader {
  dossierId: number;
  raisonSocial: string;
  siren: string;
  produitFinancier: string;
  nom: string;
  prenom: string;
  materiel: string;
  duree: number;
  periodicite: string;
  montant: number;
  loyer: string;
  baseLocInit: number;
  categorieAffaire: string;
}
export enum Phase {
  DDF = 'ddf',
  MONTAGE = 'mont',
  PARC = 'parc'
}
export class DossierHeaderBuilder {
  static setDossier(dos: DossierInfo | DossierRatifieInfo) {
    const _this = new DossierHeader();
    _this.dossierId = dos.id;
    _this.raisonSocial = dos.raisonSociale;
    _this.siren = dos.numeroSIREN;
    _this.produitFinancier = dos.produitFinancier.libelle;
    _this.nom = dos.vendeur.nom;
    _this.prenom = dos.vendeur.prenom;
    _this.materiel = dos.materiel ? dos.materiel.libelle : '';
    _this.duree = dos.duree;
    _this.montant = dos.montant;
    return _this;
  }
  /* static setDossierRatifie(dos: DossierRatifieInfo) {
    const _this = new DossierHeader();
    _this.dossierId = dos.id;
    _this.raisonSocial = dos.raisonSociale;
    _this.siren = dos.numeroSIREN;
    _this. produitFinancier = dos.produitFinancier.libelle;
    _this. nom = dos.vendeur.nom;
    _this. prenom = dos.vendeur.prenom;
    _this. materiel = dos.materiel.libelle;
    _this.duree = dos.duree;
   //  _this. periodicite = dos.;
    _this.montant = dos.montant;
   //  _this.loyer = dos.;
  }*/
}
@Component({
  selector: 'app-dossier-header',
  templateUrl: './dossier-header.component.html',
  styleUrls: ['./dossier-header.component.scss']
})

export class DossierHeaderComponent implements OnInit {
  @Input()
  data: DossierHeader;
  @Input()
  type: any;
  typeEnum: Phase;
  formatNumber = new AmountFormatter();
  constructor() {}
  ngOnInit() {
  }
}
