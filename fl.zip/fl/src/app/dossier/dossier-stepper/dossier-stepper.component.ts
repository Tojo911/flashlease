import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, AfterViewInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Dossier } from '../dossier-bloc/dossier-bloc.component';
import { CdkStep, StepperSelectionEvent } from '@angular/cdk/stepper';
import { TableColumnDefinitionModel } from '../../models/table-column-definition-model';
import { TranslateService } from '@ngx-translate/core';
import * as func from '../../models/global-functions';
import {
  MaterielFinancementInfo,
  PalierInfo,
  HistoriqueStatutCommercialInfo,
  HistoEditionContratInfo
} from '../../models/ddf';

export class DossierStepper {
  contratContent: Dossier[];
  date: string;
  active: boolean;
  title: string;
  constructor() {
    this.title = '';
    this.contratContent = [];
    this.date = '0';
    this.active = false;
  }
}

@Component({
  selector: 'app-dossier-stepper',
  templateUrl: './dossier-stepper.component.html',
  styleUrls: ['./dossier-stepper.component.scss']
})
export class DossierStepperComponent implements OnInit {
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  @Input()
  listDossierStepper: DossierStepper[];
  @Input()
  selectedIndex: number;
  @Input()
  palierColumns: TableColumnDefinitionModel[];
  @Input()
  materielColumns: TableColumnDefinitionModel[];
  @Input()
  histoColumns: TableColumnDefinitionModel[];
  @Input()
  historiqueStatutCommercialColumns: TableColumnDefinitionModel[];
  @Input()
  paliers: PalierInfo[];
  @Input()
  materielFinances: MaterielFinancementInfo[];
  @Input()
  histoDossier: HistoEditionContratInfo[];
  @Input()
  historiqueStatutCommercial: HistoriqueStatutCommercialInfo[];
  @Input()
  historiqueStatutCommercialValid: boolean;
  @Input()
  complement;

  @Input()
linear: boolean;
@Input()
selected: CdkStep;

  nbColumns = 4;
  constructor(private _formBuilder: FormBuilder, public translate: TranslateService) {}

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

  public selectionChanged(event?: StepperSelectionEvent): void {
  /*  console.log('stepper.selectedIndex: ' + this.selectedIndex
       + '; event.selectedIndex: ' + event.selectedIndex); */
/*
    if (event.selectedIndex === 0) {
     return;
    }
*/
    this.selectedIndex = event.selectedIndex;
  }
  public goto(index: number): void {
  /*  console.log('stepper.selectedIndex: ' + this.selectedIndex
        + '; goto index: ' + index); */
/*
    if (index === 0) {
      return;
    }
*/
    this.selectedIndex = index;
  }
/*
  getCompletedStatut(i: string) {
    if (i === this.selectedIndex) {


    }

  }
*/

}

