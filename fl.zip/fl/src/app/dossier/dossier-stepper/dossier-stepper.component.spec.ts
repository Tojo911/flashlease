import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierStepperComponent } from './dossier-stepper.component';

describe('DossierStepperComponent', () => {
  let component: DossierStepperComponent;
  let fixture: ComponentFixture<DossierStepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierStepperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
