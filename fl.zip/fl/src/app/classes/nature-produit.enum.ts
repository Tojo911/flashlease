export enum NatureProduitEnum {
  LF = 'Location',
  CB = 'Crédit Bail',
  CC = 'Crédit Affecté',
  CN = 'Crédit non Affecté'
}
