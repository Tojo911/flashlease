import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelGeneratorComponent } from './model-generator.component';

describe('ModelGeneratorComponent', () => {
  let component: ModelGeneratorComponent;
  let fixture: ComponentFixture<ModelGeneratorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelGeneratorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
