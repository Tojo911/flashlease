export class CatalogueInfo {
  code: string;
  id: number;
  apporteur: any; // Map<string, any>; Fix it later
  libelle: string;

  constructor(response: any) {
    this.code = response.code;
    this.id = response.id;
    this.apporteur = null;
    this.libelle = response.libelle;
  }
}
