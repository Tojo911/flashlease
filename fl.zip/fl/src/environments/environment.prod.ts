export const environment = {
  production: true,
  env: 'prod',
  version: require('../../package.json').version,
  URL_BACKEND: '',
  SECURITY_DOMAIN: 'FAEFRT',
  i18n: '/flashlease/assets/i18n/'
};
